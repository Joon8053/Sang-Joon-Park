﻿using Bosch.PRAESENSA.OpenInterface;
using Newtonsoft.Json;
using RHBform;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Dynamic;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;
using static RHBform.RHBbutton;
using static RHBLibrary.AppCommnucation.clsAinout;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace NCO_App
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }


        private void FromAdd(Form frm, Panel pBase)
        {
            frm.TopLevel = false;
            frm.TopMost = true;
            frm.Parent = this;
            pBase.Controls.Add(frm);
            frm.Show();
        }


        frmBroadcast FormBroadcast;
        frmNCO FormNCO;
        frmSchedule FormSchedule;
        frmSetting FormSetting;
        public OpenInterfaceNetClient[] m_client = new OpenInterfaceNetClient[3];
        private void frmMain_Load(object sender, EventArgs e)
        {
            fromBase frm = new fromBase(this, panel_head, btn_close, btn_mini, label_t, pictureBox_logo);
            this.SetStyle(ControlStyles.DoubleBuffer, true);
            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            this.SetStyle(ControlStyles.UserPaint, true);
            this.Location = new Point(0, 0);
            mainDataLoad();
            for (int i = 0; i < 5; i++)
            {
                defCalls[i] = new CallDefine();
                defBGMs[i] = new BgmDefine();
            }
            BGMDataLoad();
            CallDataLoad();
            NCO_DataLoad();
            NetDevLoad();
            RHBLibrary.Tools.Folder.Create("preset");
            RHBLibrary.Tools.Folder.Create("schedule");
            RHBLibrary.Tools.Folder.Create("config");
            pictureBox_bg.Dock = DockStyle.Fill;
            FormBroadcast = new frmBroadcast(this);
            FormNCO = new frmNCO(this);
            FormSchedule = new frmSchedule();
            FormSetting = new frmSetting(this);

            FromAdd(FormBroadcast, panel_base);
            FromAdd(FormNCO, panel_base);
            FromAdd(FormSchedule, panel_base);
            FromAdd(FormSetting, panel_base);
            PageCahge(1);
            timer_rTime.Enabled = true;
            timer_start.Enabled = true;
            startNetCheck();
        }

        List<clsPing> devPing = new List<clsPing>();

        private void startNetCheck()
        {
            if (devPing.Count > 0)
            {
                foreach (clsPing pinger in devPing)
                {
                    pinger.Dispose();
                }
                devPing.Clear();
            }
            for(int i=0;i<netDevice.Name.Count;i++)
            {
                clsPing tmp = new clsPing(netDevice.IPaddr[i], netDevice.PingTime, i);
                tmp.OnStatus += NetDevice_OnStatus;
                tmp.OnError += NetDevice_OnError;
                devPing.Add(tmp);
            }
        }

        private void NetDevice_OnError(string obj,int id)
        {
           // throw new NotImplementedException();
        }
        public bool AppEnd = false;
        private void NetDevice_OnStatus(bool mode,int id)
        {
            Invoke(new Action(() =>
            {
                if (AppEnd == false)
                {
                    try
                    {
                        if (FormBroadcast != null)
                            FormBroadcast.netDeviceStatus(mode, id);
                    }
                    catch
                    {

                    }
                }
            }));
        }

        private void Startup()
        {
            m_client[0] = new OpenInterfaceNetClient();
            m_client[1] = new OpenInterfaceNetClient();
            m_client[2] = new OpenInterfaceNetClient();

            m_client[0].ConnectionBroken += FrmMain_ConnectionBroken;
            m_client[0].DiagEventNotification += FrmMain_DiagEventNotification;
            m_client[0].BgmRoutingChanged += FrmMain_BgmRoutingChanged;

            m_client[0].CallStateChanged += FrmMain_CallStateChanged;
            m_client[0].ResourceStateChanged += FrmMain_ResourceStateChanged;

            m_client[1].ConnectionBroken += FrmMain_ConnectionBroken2;
            m_client[1].DiagEventNotification += FrmMain_DiagEventNotification2;
            m_client[1].BgmRoutingChanged += FrmMain_BgmRoutingChanged2;
            m_client[1].CallStateChanged += FrmMain_CallStateChanged2;
            m_client[1].ResourceStateChanged += FrmMain_ResourceStateChanged2;

            m_client[2].ConnectionBroken += FrmMain_ConnectionBroken3;
            m_client[2].DiagEventNotification += FrmMain_DiagEventNotification3;
            m_client[2].BgmRoutingChanged += FrmMain_BgmRoutingChanged3;
            m_client[2].CallStateChanged += FrmMain_CallStateChanged3;
            m_client[2].ResourceStateChanged += FrmMain_ResourceStateChanged3;
            Thread[] th = new Thread[3];

            for (int i = 0; i < 3; i++)
            {
                th[i] = new Thread(new ParameterizedThreadStart(NCO_connect));
                th[i].Start(i + 1);
            }

        }


        public void AddLog(string msg,Color cl)
        {
            if (AppEnd == false)
            {
                Invoke(new Action(() =>
                {
                    debug.Add_dataTime(msg, cl);
                }));
            }
        }

        bool[] netReConnet = { false, false, false };
        private void NCO_connect(object obj)
        {
            int no = Convert.ToInt16(obj);
            no = no - 1;

            TOIErrorCode ec = m_client[no].Connect(NcoSite.NCO[no].ip, NcoSite.NCO[no].ID, NcoSite.NCO[no].password, false);
            // ture는 보안포트 9403, false는 비보안 9401포트 //
            if (ec == TOIErrorCode.OIERROR_OK)
            {
                netReConnet[no] = false;
                FormBroadcast.disConnect(no, true);
                string ss = string.Format("Connected to: {0}", NcoSite.NCO[no].ip);
                AddLog(ss, Color.Yellow);
                ZoneListAsk(no);
                Thread.Sleep(100);
                BGMListAsk(no);
                Thread.Sleep(100);
                MessageList(no);
                Thread.Sleep(100);
                scFault(no);
            }
            else
            {
                string ss = string.Format("Failed to connect: {0}", ec);
                AddLog(ss, Color.Pink);
                FormBroadcast.disConnect(no, false);
                netReConnet[no] = true;
            }
        }

        public List<string>[] BGMlist = new List<string>[3]{
            new List<string>(),
            new List<string>(),
            new List<string>()
        };
        public List<string>[] ZONElist = new List<string>[3]{
            new List<string>(),
            new List<string>(),
            new List<string>()
        };
        public List<string>[] Messagelist = new List<string>[3]{
            new List<string>(),
            new List<string>(),
            new List<string>()
        };
        private void scFault(int id)
        {

            rcvFault[id] = false;  //30초 후부터 동작 기존 에러 무시
            System.Timers.Timer timer = new System.Timers.Timer(30000);    // 30초 뒤에 동작하는 타이머 생성
            if(id == 0)
                timer.Elapsed += OnTimedEvent;    // 타이머 이벤트 핸들러 등록
            else if(id == 1)
                timer.Elapsed += OnTimedEvent1;
            else if (id == 2)
                timer.Elapsed += OnTimedEvent2;
            timer.AutoReset = false;    // 타이머 실행 후 한 번만 동작
            timer.Start();    // 타이머 실행

            // 타이머 이벤트 핸들러


            TOIErrorCode ec = m_client[id].SetSubscriptionEvents(true, TOIDiagEventGroup.OIDEG_FAULTEVENTGROUP);
            string ss = "\r\n" + id.ToString() + "Fault Error subscribe\r";
            AddLog(ss, Color.Lime);
            if (ec != TOIErrorCode.OIERROR_OK)
            {
                ss = string.Format("Failed to (un)subscribe to/from fault events: {0}", ec);
                AddLog(ss, Color.White);
            }
        }

        bool[] rcvFault = { false, false, false };
        void OnTimedEvent(object sender, ElapsedEventArgs e)
        {
            rcvFault[0] = true;
        }
        void OnTimedEvent1(object sender, ElapsedEventArgs e)
        {
            rcvFault[1] = true;
        }
        void OnTimedEvent2(object sender, ElapsedEventArgs e)
        {
            rcvFault[2] = true;
        }

        private void ZoneListAsk(int id)
        {
            string zoneGroupName = string.Empty; // 빈 문자열로 모든 존의 이름을 가져옴
            TOIErrorCode ec = m_client[id].GetZoneNames(zoneGroupName, out List<string> names);
            if (ec == TOIErrorCode.OIERROR_OK)
            {
                foreach (string name in names)
                {
                    Console.WriteLine(name);
                }
                // 받은 정보를 텍스트 박스에 표시
                string ss = "\r\n" + id.ToString() + "-------Zone list 요청\r";
                ss += string.Join(Environment.NewLine, names);
                AddLog(ss, Color.Lime);
                ZONElist[id].Clear();
                ZONElist[id] = names;
                // 자동으로 응답 값을 전송
                bool subscribe = true; // 구독 설정
                TOIErrorCode subscriptionEc = m_client[id].SetSubscriptionResources(subscribe, names);
                if (subscriptionEc == TOIErrorCode.OIERROR_OK)
                {
                    Console.WriteLine("Successfully set subscription for resources.");
                }
                else
                {
                    Console.WriteLine("Failed to set subscription for resources: {0}", subscriptionEc);
                }
            }
            else
            {
                Console.WriteLine("Failed to get zone names: {0}", ec);
            }
        }

        private  void BGMListAsk(int id)
        {
            TOIErrorCode ec = m_client[id].GetBgmChannelNames(out List<string> names);
            if (ec == TOIErrorCode.OIERROR_OK)
            {
                foreach (string name in names)
                {
                    Console.WriteLine(name);
                }
                // 받은 정보를 텍스트 박스에 표시
                //txt_MessageNames.Text = string.Join(Environment.NewLine, names);
                string ss = "\r\n" + id.ToString()+ "-------BGM list 요청\r";
                ss += string.Join(Environment.NewLine, names);
                AddLog(ss, Color.Silver);
                BGMlist[id].Clear();
                BGMlist[id] = names;
                // 자동으로 응답 값을 전송
                bool subscribe = true; // 구독 설정
                foreach (string channelName in names)
                {
                    TOIErrorCode subscriptionEc = m_client[id].SetSubscriptionBgmRouting(subscribe, channelName);
                    if (subscriptionEc == TOIErrorCode.OIERROR_OK)
                    {
                        Console.WriteLine("Successfully set subscription for BGM channel: {0}", channelName);
                    }
                    else
                    {
                        Console.WriteLine("Failed to set subscription for BGM channel: {0}, Error: {1}", channelName, subscriptionEc);
                    }
                }
            }
            else
            {
                Console.WriteLine("Failed to get BGM channel names: {0}", ec);
            }
        }

        public void SC_BGMlist(int id,bool mode)
        {

            foreach (string channelName in BGMlist[id])
            {
                TOIErrorCode subscriptionEc = m_client[id].SetSubscriptionBgmRouting(mode, channelName);
                if (subscriptionEc == TOIErrorCode.OIERROR_OK)
                {
                    Console.WriteLine("Successfully set subscription for BGM channel: {0}", channelName);
                }
                else
                {
                    Console.WriteLine("Failed to set subscription for BGM channel: {0}, Error: {1}", channelName, subscriptionEc);
                }
            }
        }

        private void MessageList(int id)
        {
            TOIErrorCode ec = m_client[id].GetMessageNames(out List<string> names);
            if (ec == TOIErrorCode.OIERROR_OK)
            {
                foreach (string name in names)
                {
                    Console.WriteLine(name);
                }
                // 받은 정보를 텍스트 박스에 표시
                //txt_MessageNames.Text = string.Join(Environment.NewLine, names);
                string ss = "\r\n" + id.ToString() + "-------Message list 요청\r";
                ss += string.Join(Environment.NewLine, names);
                AddLog(ss, Color.Silver);
                Messagelist[id].Clear();
                Messagelist[id] = names;

            }
            else
            {
                Console.WriteLine("Failed to get Message names: {0}", ec);
            }
        }


        #region NCO Event
        private void FrmMain_ConnectionBroken(object sender, EventArgs e)
        {
            mFrmMain_ConnectionBroken(e, 0);
        }
        private void FrmMain_ConnectionBroken2(object sender, EventArgs e)
        {
            mFrmMain_ConnectionBroken(e, 1);
        }
        private void FrmMain_ConnectionBroken3(object sender, EventArgs e)
        {
            mFrmMain_ConnectionBroken(e, 2);
        }
        private void FrmMain_ResourceStateChanged(object sender, OIResourceStateEventArgs e)
        {
            mFrmMain_ResourceStateChanged(e, 0);
        }

        private void FrmMain_CallStateChanged(object sender, OICallStateChangedEventArgs e)
        {
            mFrmMain_CallStateChanged(e, 0);
        }

        private void FrmMain_BgmRoutingChanged(object sender, OIBgmRoutingChangedEventArgs e)
        {
            mFrmMain_BgmRoutingChanged(e, 0);
        }

        private void FrmMain_DiagEventNotification(object sender, OIDiagEventEventArgs e)
        {
            mFrmMain_DiagEventNotification(e, 0);
        }

        private void FrmMain_ResourceStateChanged2(object sender, OIResourceStateEventArgs e)
        {
            mFrmMain_ResourceStateChanged(e, 1);
        }

        private void FrmMain_CallStateChanged2(object sender, OICallStateChangedEventArgs e)
        {
            mFrmMain_CallStateChanged(e, 1);
        }

        private void FrmMain_BgmRoutingChanged2(object sender, OIBgmRoutingChangedEventArgs e)
        {
            mFrmMain_BgmRoutingChanged(e, 1);
        }

        private void FrmMain_DiagEventNotification2(object sender, OIDiagEventEventArgs e)
        {
            mFrmMain_DiagEventNotification(e, 1);
        }

        private void FrmMain_ResourceStateChanged3(object sender, OIResourceStateEventArgs e)
        {
            mFrmMain_ResourceStateChanged(e, 2);
        }

        private void FrmMain_CallStateChanged3(object sender, OICallStateChangedEventArgs e)
        {
            mFrmMain_CallStateChanged(e, 2);
        }

        private void FrmMain_BgmRoutingChanged3(object sender, OIBgmRoutingChangedEventArgs e)
        {
            mFrmMain_BgmRoutingChanged(e, 2);
        }

        private void FrmMain_DiagEventNotification3(object sender, OIDiagEventEventArgs e)
        {
            mFrmMain_DiagEventNotification(e, 2);
        }
        #endregion

        private void mFrmMain_ConnectionBroken(EventArgs e, int id)
        {
            FormBroadcast.disConnect(id, false);
            netReConnet[id] = true;
        }
        private void mFrmMain_ResourceStateChanged(OIResourceStateEventArgs e,int id)
        {
            Invoke(new Action(() =>
            {
                if ((FormBroadcast != null) && (e.Resources.Count > 0))
                    FormBroadcast.rcvUpdateZone(id, Convert.ToInt32(e.Priority), e.Resources, "");
                if((Convert.ToInt32(e.Priority)>239)&&(Convert.ToInt32(e.Priority)<251))
                {
                    // fire event..
                    frmAlrams dlg = new frmAlrams();
                    dlg.Show();
                    dlg.TopMost = true;
                    dlg.setTitle("화재 발생");
                    // get zone.
                    string result1 = string.Join(", ", e.Resources);
                    dlg.ADD_Text(result1, Color.Lime);
                    FormBroadcast.upadteFire(id, true);
                }
            }));
            string ss = id.ToString() + "-----------Call change\r";
            ss +="Priority = " + e.Priority.ToString()+"\r";
            ss +="Call ID = " + e.CallId.ToString() + "\r";
            string result = string.Join(", ", e.Resources);
            ss += "Zone = " + result + "\r";
            if(e.Priority==65535)
                AddLog(ss, Color.Yellow);
            else
                AddLog(ss, Color.White);
        }

        private void mFrmMain_CallStateChanged(OICallStateChangedEventArgs e, int id)
        {
            //throw new NotImplementedException();
        }

        private void mFrmMain_BgmRoutingChanged(OIBgmRoutingChangedEventArgs e, int id)
        {
            Invoke(new Action(() =>
            {
                if ((FormBroadcast != null) && (e.Routing.Count > 0))
                {
                    if(e.Added)
                        FormBroadcast.rcvUpdateZone(id, 0, e.Routing, e.Channel);
                    else
                        FormBroadcast.rcvUpdateZone(id, 65535, e.Routing, e.Channel);
                }
            }));

            /*
            Add_Log("BGM change");
            Add_Log("Channel = " + e.Channel.ToString());
            string result = string.Join(", ", e.Routing);
            Add_Log("Zone = " + result);
            */
            string ss = id.ToString() + "-----------BGM change\r";
            ss += e.Added.ToString() + "\r";
            ss += "channel = " + e.Channel.ToString() + "\r";
            string result = string.Join(", ", e.Routing);
            ss += "Zone = " + result + "\r";
            AddLog(ss, Color.White);
        }

        private void mFrmMain_DiagEventNotification(OIDiagEventEventArgs e, int id)
        {
            try
            {
                if (e.Event != null)
                {
                    string ss = string.Format("EventId = {0}, action = {1}, event = {2}\r", e.Event.EventId, e.ActionType, e.Event.ToString());
                    ss = "(ID" + id.ToString()+") " + ss;
                    if(id==0)
                        AddLog(ss, Color.Pink);
                    else
                        AddLog(ss, Color.Lime);
                    if (rcvFault[id])
                    {
                        // fire event..
                        Invoke(new Action(() =>
                        {
                            frmAlrams dlg = new frmAlrams();
                            dlg.Show();
                            dlg.TopMost = true;
                            dlg.setTitle("장애 발생");
                            // get zone.
                            dlg.ADD_Text(ss, Color.Lime);
                            FormBroadcast.upadteFault(id, true);
                        }));
                    }

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        public class CallDefine
        {
            public string Name = "Call";
            public string Priority = "0";
            public string StartChime = "";
            public string Message = "";
            public string AudioInput = "";
            public string EndChime = "";
            public string Repeat = "0";
            public Color cl = Color.White;
        }

        public class BgmDefine
        {
            public string Name = "BGM";
            public string NCObgm = "";
            public Color cl = Color.White;
        }

        public CallDefine[] defCalls = new CallDefine[5];
        public BgmDefine[] defBGMs = new BgmDefine[5];

        public class NCO_ZONE
        {
            public string GroupTitle = "";
            public string[] ZoneName = new string[5];
            public string[] NcoZone = new string[5];
            public int Nco_No = 1;

        }

        public class defineNco
        {
            public string ip="127.0.0.1";
            public string Name = "NCO";
            public string ID="admin";
            public string password="admin";
        }

        public class ZoneList
        {
            public defineNco[] NCO = new defineNco[4];
            public string[] ZoneTitle = new string[4];
            public List<NCO_ZONE>[] ncoZone = new List<NCO_ZONE>[4] {
                new List<NCO_ZONE>(),
                new List<NCO_ZONE>(),
                new List<NCO_ZONE>(),
                new List<NCO_ZONE>()
            };
            public ZoneList()
            {
                for (int i = 0; i < NCO.Length; i++)
                    NCO[i] = new defineNco();
                for (int i = 0; i < ZoneTitle.Length; i++)
                    ZoneTitle[i] = "Site " + (i + 1).ToString();
            }
        }

        public ZoneList NcoSite = new ZoneList();
        public List<NCO_ZONE> tmp_Zone;
        public List<string>[] NCO_rcvZoneList = new List<string>[3] {
            new List<string>(),
            new List<string>(),
            new List<string>()
        };

        public void NCO_DataLoad()
        {
            string file = AppDomain.CurrentDomain.BaseDirectory + "\\config\\ncoSite.cfg";
            if (File.Exists(file) == true)
            {
                using (StreamReader reader = File.OpenText(file))
                {
                    string ss = reader.ReadToEnd();
                    try
                    {
                        ZoneList tmp = JsonConvert.DeserializeObject<ZoneList>(ss);
                        NcoSite = tmp;
                    }
                    catch
                    {

                    }
                }
            }
        }

        public void NCO_DataSave()
        {
            string jdata = JsonConvert.SerializeObject(NcoSite);
            using (StreamWriter writer = File.CreateText("\\config\\ncoSite.cfg"))
            {
                writer.WriteLine(jdata);
            }
            FormBroadcast.UpdateZone();
        }

        public class NET_Device
        {
            public int PingTime=3;
            public List<string> IPaddr = new List<string>();
            public List<string> Name = new List<string>();
            public void Remove(int no)
            {
                if (Name.Count > no)
                {
                    IPaddr.RemoveAt(no);
                    Name.RemoveAt(no);
                }
            }
            public void AddData(string ip,string name)
            {
                IPaddr.Add(ip);
                Name.Add(name);
            }
        }
        public NET_Device netDevice = new NET_Device();

        public class MAIN_VAR
        {
            public string musicFolder = "";
        }

        public MAIN_VAR mainVar = new MAIN_VAR();

        public void mainDataLoad()
        {
            string file = AppDomain.CurrentDomain.BaseDirectory + "\\config\\main.cfg";
            if (File.Exists(file) == true)
            {
                using (StreamReader reader = File.OpenText(file))
                {
                    string ss = reader.ReadToEnd();
                    try
                    {
                        MAIN_VAR tmp = JsonConvert.DeserializeObject<MAIN_VAR>(ss);
                        mainVar = tmp;
                    }
                    catch
                    {

                    }
                }
            }
        }

        public void mainDataSave()
        {
            string jdata = JsonConvert.SerializeObject(mainVar);
            using (StreamWriter writer = File.CreateText("\\config\\main.cfg"))
            {
                writer.WriteLine(jdata);
            }
        }
        public void NetDevLoad()
        {
            string file = AppDomain.CurrentDomain.BaseDirectory + "\\config\\devNet.cfg";
            if (File.Exists(file) == true)
            {
                using (StreamReader reader = File.OpenText(file))
                {
                    string ss = reader.ReadToEnd();
                    try
                    {
                        NET_Device tmp = JsonConvert.DeserializeObject<NET_Device>(ss);
                        netDevice = tmp;
                    }
                    catch
                    {

                    }
                }
            }
        }


        public void NetDevSave()
        {
            string jdata = JsonConvert.SerializeObject(netDevice);
            using (StreamWriter writer = File.CreateText("\\config\\devNet.cfg"))
            {
                writer.WriteLine(jdata);
            }
            FormBroadcast.UpdateNetBtn();
            startNetCheck();
        }

        public void BGMDataLoad()
        {
            string file = AppDomain.CurrentDomain.BaseDirectory + "\\config\\bgm.cfg";
            if (File.Exists(file) == true)
            {
                using (StreamReader reader = File.OpenText(file))
                {
                    string ss = reader.ReadToEnd();
                    try
                    {
                        BgmDefine[] tmp = JsonConvert.DeserializeObject<BgmDefine[]>(ss);
                        defBGMs = tmp;
                    }
                    catch
                    {

                    }
                }
            }
        }


        public void BGMDataSave()
        {
            string jdata = JsonConvert.SerializeObject(defBGMs);
            using (StreamWriter writer = File.CreateText("\\config\\bgm.cfg"))
            {
                writer.WriteLine(jdata);
            }
            FormBroadcast.UpdateButtons();
        }

        public void CallDataLoad()
        {
            string file = AppDomain.CurrentDomain.BaseDirectory + "\\config\\call.cfg";
            if (File.Exists(file) == true)
            {
                using (StreamReader reader = File.OpenText(file))
                {
                    string ss = reader.ReadToEnd();
                    try
                    {
                        CallDefine [] tmp = JsonConvert.DeserializeObject<CallDefine[]>(ss);
                        defCalls = tmp;
                    }
                    catch
                    {

                    }
                }
            }
        }

        public void CallDataSave()
        {
            string jdata = JsonConvert.SerializeObject(defCalls);
            using (StreamWriter writer = File.CreateText("\\config\\call.cfg"))
            {
                writer.WriteLine(jdata);
            }
            FormBroadcast.UpdateButtons();
        }


        private void PageCahge(int no)
        {
            if (no == 1)
            {
                btn_menu1.setON = true;
                FormBroadcast.BringToFront();
            }
            else
            {
                btn_menu1.setON = false;
            }

            if (no == 2)
            {
                btn_menu2.setON = true;
                FormSchedule.BringToFront();
            }
            else
            {
                btn_menu2.setON = false;
            }

            if (no == 3)
            {
                btn_menu3.setON = true;
                FormSetting.BringToFront();
                CallDataLoad();
                BGMDataLoad();
            }
            else
            {
                btn_menu3.setON = false;
            }

            if (no == 4)
            {
                btn_menu4.setON = true;
                FormNCO.BringToFront();
            }
            else
            {
                btn_menu4.setON = false;
            }
        }

        private void btn_menu1_Click(object sender, EventArgs e)
        {
            int btn = Convert.ToInt16(((Control)sender).Tag);
            PageCahge(btn);
        }

        private void pictureBox_bg_Click(object sender, EventArgs e)
        {
            pictureBox_bg.Visible = false;
        }

        private void timer_rTime_Tick(object sender, EventArgs e)
        {
            // 현재 시간 가져오기
            DateTime currentTime = DateTime.Now;

            // 오전/오후 구분
            string amPm = currentTime.Hour < 12 ? "오전" : "오후";

            // 12시간 포맷으로 변경
            int hour = currentTime.Hour % 12;
            if (hour == 0) hour = 12;

            // 분:초 포맷으로 출력
            string timeFormat = $"{amPm} {hour:00}:{currentTime.Minute:00}:{currentTime.Second:00}";
            label_time.Text = timeFormat;

            // 년-월-일 포맷으로 출력
            string dateFormat = currentTime.ToString("yyyy-MM-dd");

            DayOfWeek dayOfWeek = currentTime.DayOfWeek;
            int dayOfWeekIndex = (int)dayOfWeek;

            string[] koreanDaysOfWeek = { "일", "월", "화", "수", "목", "금", "토" };

            label_date.Text = $"{dateFormat}({koreanDaysOfWeek[dayOfWeekIndex]})";

        }

        public string[] reqZones()
        {
            string[] zones = { "", "", "" };

            return zones;
        }

        private void timer_start_Tick(object sender, EventArgs e)
        {
            timer_start.Enabled = false;
            Startup();
        }


        FrmDebug debug = new FrmDebug();
        private void button1_Click(object sender, EventArgs e)
        {
            debug.Visible = !debug.Visible;
        }


        uint[] Call_ID = { 0, 0, 0 };
        private void NCO_CallCreate(int no,string Zone,int CallNo)
        {
            if (Zone.Length > 0)
            {
                uint callId = 0;
                List<string> routing = Zone.Split(new char[] { ',' }).ToList();
                List<string> messages = defCalls[CallNo].Message.Split(new char[] { ',' }).ToList();
                TOIErrorCode ec = m_client[no].CreateCallEx2(routing, Convert.ToUInt32(defCalls[CallNo].Priority), TOICallOutputHandling.OICOH_PARTIAL, TOICallStackingMode.OICSM_WAIT_FOR_ALL, 0,
                                defCalls[CallNo].StartChime, defCalls[CallNo].EndChime, false, "", messages, Convert.ToUInt32(defCalls[CallNo].Repeat), TOICallTiming.OICTM_IMMEDIATE, "", 0, 0, 0, 0, out callId);
                if (ec == TOIErrorCode.OIERROR_OK)
                {
                    Call_ID[no] = callId;
                    AddLog(no.ToString() + " call id 생성 = " + callId.ToString(), Color.Silver);
                    //Add_Message("call id 생성 = " + callId.ToString());
                }
                else
                {
                    Call_ID[no] = 0;
                    AddLog(no.ToString() + " cFailed to create call", Color.Silver);
                }
            }
            else
                Call_ID[no] = 0;
        }


        private void NCO_Call()
        {
            for (int i = 0; i < 3; i++)
            {
                if (Call_ID[i] > 0)
                {
                    uint callId = Call_ID[i];
                    TOIErrorCode ec = m_client[i].StartCreatedCall(callId);
                    if (ec != TOIErrorCode.OIERROR_OK)
                    {
                        AddLog(i.ToString()+" Failed to start call", Color.Silver);
                    }
                }
            }
        }


        public  void NCO_CallEnd()
        {
            for (int i = 0; i < 3; i++)
            {
                if (Call_ID[i] > 0)
                {
                    uint callId = Call_ID[i];
                    TOIErrorCode ec = m_client[i].AbortCall(callId);
                    if (ec != TOIErrorCode.OIERROR_OK)
                    {
                        AddLog(i.ToString() + " ailed to abort call", Color.Silver);
                    }
                    Call_ID[i] = 0;
                }
            }
        }


        public void callCreate(string[] Zone,int callNo)
        {
            for (int i = 0; i < 3; i++)
                NCO_CallCreate(i, Zone[i], callNo);
            Thread.Sleep(100);
            for (int i = 0; i < 3; i++)
                NCO_Call();
        }
        private void ncoAddBGM(int no,string Zone, int bgmNo)
        {
            if (Zone.Length > 0)
            {
                string channel = defBGMs[bgmNo].NCObgm;
                List<string> resources = Zone.Split(new char[] { ',' }).ToList();

                TOIErrorCode ec = m_client[no].AddBgmRouting(channel, resources);
                if (ec == TOIErrorCode.OIERROR_OK)
                {
                    string ss = string.Join(Environment.NewLine, no.ToString() + " Successfully added BGM routing.");
                    AddLog(ss, Color.Silver);
                }
                else
                {
                    string ss = string.Join(Environment.NewLine, no.ToString() + " Failed to add BGM routing: {0}", ec);
                    AddLog(ss, Color.Silver);
                }
            }
        }

        public void AddBGM(string[] Zone, int bgmNo)
        {
            for (int i = 0; i < 3; i++)
                ncoAddBGM(i, Zone[i], bgmNo);
        }
        private void ncoRemoveBGM(int no, string Zone, int bgmNo)
        {
            if (Zone.Length > 0)
            {
                string channel = defBGMs[bgmNo].NCObgm;
                if (channel.Length == 0) return;
                List<string> resources = Zone.Split(new char[] { ',' }).ToList();
                TOIErrorCode ec = m_client[no].RemoveBgmRouting(channel, resources);
                if (ec == TOIErrorCode.OIERROR_OK)
                {
                    string ss = string.Join(Environment.NewLine, no.ToString() + " Successfully added BGM routing.");
                    AddLog(ss, Color.Silver);
                }
                else
                {
                    string ss = string.Join(Environment.NewLine, no.ToString() + " Failed to add BGM routing: {0}", ec);
                    AddLog(ss, Color.Silver);
                }
            }
        }

        public void RemoveBGM(string[] Zone, int bgmNo)
        {
            for (int i = 0; i < 3; i++)
                ncoRemoveBGM(i, Zone[i], bgmNo);
        }

        private void timer_Reconnect_Tick(object sender, EventArgs e)
        {
            Thread[] th = new Thread[3];
  
            for (int i = 0; i < netReConnet.Length; i++)
            {
                if (netReConnet[i])
                {
                    th[i] = new Thread(new ParameterizedThreadStart(NCO_connect));
                    netReConnet[i] = false;
                    th[i].Start(i+1);
                }
            }
        }

        private void btn_fireClear_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("화재를 복구 하시겠습니까?", "사용자 확인", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                for (int i = 0; i < 3; i++)
                {
                    EMask(i);
                    Thread.Sleep(100);
                    EMreset(i);
                    FormBroadcast.upadteFire(i, false);
                }
            }
        }

        private void btn_FaultClear_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("장애를 복구 하시겠습니까?", "사용자 확인", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                for(int i=0; i < 3; i++)
                {
                    FaultAsk(i);
                    Thread.Sleep(100);
                    FaultReset(i);
                    FormBroadcast.upadteFault(i, false);
                }
            }
        }


        private void EMask(int id)
        {
            TOIErrorCode ec = m_client[id].AckEvacAlarm();
            if (ec != TOIErrorCode.OIERROR_OK)
            {
                AddLog(id.ToString()+" Failed to acknowledge evac alarm", Color.Silver);
            }

        }
        private void EMreset(int id)
        {
            TOIErrorCode ec = m_client[id].ResetEvacAlarmEx(true /*bAbortEvacCalls*/);
            if (ec != TOIErrorCode.OIERROR_OK)
            {
                AddLog(id.ToString() + " Failed to reset evac alarm", Color.Silver);
            }

        }

        private void FaultAsk(int id)
        {
            TOIErrorCode ec = m_client[id].AckAllFaults();
            if (ec != TOIErrorCode.OIERROR_OK)
            {
                string ss = string.Format("Failed to acknowledge all faults: {0}", ec);
                AddLog(id.ToString() + ss, Color.Silver);
            }

        }

        private void FaultReset(int id)
        {
            TOIErrorCode ec = m_client[id].ResetAllFaults();
            if (ec != TOIErrorCode.OIERROR_OK)
            {
                string ss = string.Format("Failed to reset all faults: {0}", ec);
                AddLog(id.ToString() + ss, Color.Silver);
            }
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            AppEnd = true;
            if (devPing.Count > 0)
            {
                foreach (clsPing pinger in devPing)
                {
                    pinger.Dispose();
                }
                devPing.Clear();
            }
        }
    }
}
