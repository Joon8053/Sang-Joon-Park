﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace NCO_App
{
    public class clsPing : IDisposable
    {
        Ping pingSender = new Ping();

        public event Action<bool,int> OnStatus;
        public event Action<string,int> OnError;
        string ipAddr="127.0.0.1";
        int sTime;
        private bool isRunning;
        public int ID;
        Thread th;
        public clsPing(string ipaddr, int tsec,int id)
        {
            ipAddr = ipaddr;
            sTime = tsec * 1000;
            ID = id;
            isRunning = true;
            th = new Thread(CheckPing);
            th.IsBackground = true;
            th.Start();
        }

        private void CheckPing()
        {
            bool flg = false;
            while (isRunning)
            {
                try
                {
                    PingReply reply = pingSender.Send(ipAddr);

                    if (reply.Status == IPStatus.Success)
                    {
                        // 핑 정보 출력
                        /*
                        Console.WriteLine("주소: {0}", reply.Address.ToString());
                        Console.WriteLine("라운드 트립 시간: {0} ms", reply.RoundtripTime);
                        Console.WriteLine("시간 To Live (TTL): {0}", reply.Options.Ttl);
                        Console.WriteLine("프래그먼트를 보낼 수 있는가? : {0}", reply.Options.DontFragment);
                        Console.WriteLine("버퍼 크기: {0}", reply.Buffer.Length);
                        */
                        flg = true;
                    }
                    else
                    {
                        OnError?.Invoke (ipAddr+ " 핑을 보낼 수 없습니다. 에러: " + reply.Status.ToString(),ID);
                    }
                }
                catch (Exception ex)
                {
                    OnError?.Invoke(ipAddr + " 핑을 보낼 수 없습니다. 에러: " +ex.ToString(),ID);
                }
                OnStatus?.Invoke(flg,ID);
                Thread.Sleep(sTime);
            }

        }
        public void Dispose()
        {
            isRunning = false;
            if (!th.Join(500)) // 3000 밀리초(3초) 동안 기다립니다.
            {
                th.Abort(); // 쓰레드가 시간 내에 종료되지 않는다면 강제로 종료합니다.
            }
        }
    }
}
