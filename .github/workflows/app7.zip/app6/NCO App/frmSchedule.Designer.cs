﻿namespace NCO_App
{
    partial class frmSchedule
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSchedule));
            this.convert_sc = new System.Windows.Forms.Button();
            this.sc_edit = new System.Windows.Forms.DataGridView();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sc_save = new System.Windows.Forms.Button();
            this.sc_del = new System.Windows.Forms.Button();
            this.sc_add = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_nextMonth = new System.Windows.Forms.Button();
            this.btn_preMonth = new System.Windows.Forms.Button();
            this.btn_home = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.customCalendar1 = new exCalendar.CustomCalendar();
            ((System.ComponentModel.ISupportInitialize)(this.sc_edit)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // convert_sc
            // 
            this.convert_sc.ForeColor = System.Drawing.Color.Black;
            this.convert_sc.Location = new System.Drawing.Point(1670, 404);
            this.convert_sc.Name = "convert_sc";
            this.convert_sc.Size = new System.Drawing.Size(113, 40);
            this.convert_sc.TabIndex = 21;
            this.convert_sc.Text = "변환";
            this.convert_sc.UseVisualStyleBackColor = true;
            this.convert_sc.Visible = false;
            // 
            // sc_edit
            // 
            this.sc_edit.BackgroundColor = System.Drawing.Color.Gainsboro;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.sc_edit.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.sc_edit.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.sc_edit.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column15,
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column11,
            this.Column12,
            this.Column13,
            this.Column14,
            this.Column17});
            this.sc_edit.GridColor = System.Drawing.SystemColors.ActiveCaption;
            this.sc_edit.Location = new System.Drawing.Point(1577, 650);
            this.sc_edit.Name = "sc_edit";
            this.sc_edit.RowTemplate.Height = 23;
            this.sc_edit.Size = new System.Drawing.Size(309, 285);
            this.sc_edit.TabIndex = 20;
            // 
            // Column15
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column15.DefaultCellStyle = dataGridViewCellStyle2;
            this.Column15.HeaderText = "이름";
            this.Column15.Name = "Column15";
            this.Column15.Width = 150;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "일";
            this.Column1.Name = "Column1";
            this.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Column1.Width = 30;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "월";
            this.Column2.Name = "Column2";
            this.Column2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Column2.Width = 30;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "화";
            this.Column3.Name = "Column3";
            this.Column3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Column3.Width = 30;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "수";
            this.Column4.Name = "Column4";
            this.Column4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Column4.Width = 30;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "목";
            this.Column5.Name = "Column5";
            this.Column5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Column5.Width = 30;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "금";
            this.Column6.Name = "Column6";
            this.Column6.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Column6.Width = 30;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "토";
            this.Column7.Name = "Column7";
            this.Column7.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Column7.Width = 30;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "주중";
            this.Column8.Name = "Column8";
            this.Column8.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Column8.Width = 60;
            // 
            // Column9
            // 
            this.Column9.HeaderText = "전체";
            this.Column9.Name = "Column9";
            this.Column9.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Column9.Width = 60;
            // 
            // Column10
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column10.DefaultCellStyle = dataGridViewCellStyle3;
            this.Column10.HeaderText = "시작시간";
            this.Column10.Name = "Column10";
            this.Column10.Width = 120;
            // 
            // Column11
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column11.DefaultCellStyle = dataGridViewCellStyle4;
            this.Column11.HeaderText = "종료시간";
            this.Column11.Name = "Column11";
            this.Column11.Width = 120;
            // 
            // Column12
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column12.DefaultCellStyle = dataGridViewCellStyle5;
            this.Column12.HeaderText = "선택된 입력";
            this.Column12.Name = "Column12";
            this.Column12.ReadOnly = true;
            this.Column12.Width = 120;
            // 
            // Column13
            // 
            this.Column13.HeaderText = "GROUP1";
            this.Column13.Name = "Column13";
            this.Column13.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // Column14
            // 
            this.Column14.HeaderText = "Preset";
            this.Column14.Name = "Column14";
            this.Column14.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column14.Width = 50;
            // 
            // Column17
            // 
            this.Column17.HeaderText = "Input";
            this.Column17.Name = "Column17";
            this.Column17.Width = 50;
            // 
            // sc_save
            // 
            this.sc_save.ForeColor = System.Drawing.Color.Black;
            this.sc_save.Location = new System.Drawing.Point(1632, 324);
            this.sc_save.Name = "sc_save";
            this.sc_save.Size = new System.Drawing.Size(170, 50);
            this.sc_save.TabIndex = 19;
            this.sc_save.Text = "저장";
            this.sc_save.UseVisualStyleBackColor = true;
            // 
            // sc_del
            // 
            this.sc_del.ForeColor = System.Drawing.Color.Black;
            this.sc_del.Location = new System.Drawing.Point(1632, 268);
            this.sc_del.Name = "sc_del";
            this.sc_del.Size = new System.Drawing.Size(170, 50);
            this.sc_del.TabIndex = 18;
            this.sc_del.Text = "일정 삭제/바로 저장";
            this.sc_del.UseVisualStyleBackColor = true;
            // 
            // sc_add
            // 
            this.sc_add.ForeColor = System.Drawing.Color.Black;
            this.sc_add.Location = new System.Drawing.Point(1623, 212);
            this.sc_add.Name = "sc_add";
            this.sc_add.Size = new System.Drawing.Size(170, 50);
            this.sc_add.TabIndex = 17;
            this.sc_add.Text = "일정 추가";
            this.sc_add.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(1619, 59);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(116, 19);
            this.label4.TabIndex = 16;
            this.label4.Text = "스케쥴 편집";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.panel1.Controls.Add(this.button1);
            this.panel1.Location = new System.Drawing.Point(27, 660);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1404, 275);
            this.panel1.TabIndex = 24;
            // 
            // btn_nextMonth
            // 
            this.btn_nextMonth.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_nextMonth.BackColor = System.Drawing.Color.Silver;
            this.btn_nextMonth.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_nextMonth.ForeColor = System.Drawing.Color.Black;
            this.btn_nextMonth.Location = new System.Drawing.Point(1324, 28);
            this.btn_nextMonth.Name = "btn_nextMonth";
            this.btn_nextMonth.Size = new System.Drawing.Size(97, 50);
            this.btn_nextMonth.TabIndex = 25;
            this.btn_nextMonth.Text = "다음달 ->";
            this.btn_nextMonth.UseVisualStyleBackColor = false;
            this.btn_nextMonth.Click += new System.EventHandler(this.btn_nextMonth_Click);
            // 
            // btn_preMonth
            // 
            this.btn_preMonth.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_preMonth.BackColor = System.Drawing.Color.Silver;
            this.btn_preMonth.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_preMonth.ForeColor = System.Drawing.Color.Black;
            this.btn_preMonth.Location = new System.Drawing.Point(36, 28);
            this.btn_preMonth.Name = "btn_preMonth";
            this.btn_preMonth.Size = new System.Drawing.Size(97, 50);
            this.btn_preMonth.TabIndex = 26;
            this.btn_preMonth.Text = "<- 이전달";
            this.btn_preMonth.UseVisualStyleBackColor = false;
            this.btn_preMonth.Click += new System.EventHandler(this.btn_preMonth_Click);
            // 
            // btn_home
            // 
            this.btn_home.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_home.BackColor = System.Drawing.Color.Silver;
            this.btn_home.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_home.ForeColor = System.Drawing.Color.Black;
            this.btn_home.Location = new System.Drawing.Point(139, 28);
            this.btn_home.Name = "btn_home";
            this.btn_home.Size = new System.Drawing.Size(97, 50);
            this.btn_home.TabIndex = 27;
            this.btn_home.Text = "현재 날짜";
            this.btn_home.UseVisualStyleBackColor = false;
            this.btn_home.Click += new System.EventHandler(this.btn_home_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(132, 28);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // customCalendar1
            // 
            this.customCalendar1.dutyFontSize = 0F;
            this.customCalendar1.Location = new System.Drawing.Point(27, 25);
            this.customCalendar1.MenuStrip = null;
            this.customCalendar1.Name = "customCalendar1";
            this.customCalendar1.schedulerFontSize = 0F;
            this.customCalendar1.SelectedDate = new System.DateTime(2023, 7, 1, 0, 0, 0, 0);
            this.customCalendar1.Size = new System.Drawing.Size(1404, 629);
            this.customCalendar1.TabIndex = 23;
            this.customCalendar1.UserGrade = ((long)(0));
            this.customCalendar1.UserName = null;
            this.customCalendar1.Click += new System.EventHandler(this.customCalendar1_Click);
            this.customCalendar1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.customCalendar1_MouseDown);
            // 
            // frmSchedule
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1920, 947);
            this.Controls.Add(this.btn_home);
            this.Controls.Add(this.btn_preMonth);
            this.Controls.Add(this.btn_nextMonth);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.customCalendar1);
            this.Controls.Add(this.convert_sc);
            this.Controls.Add(this.sc_edit);
            this.Controls.Add(this.sc_save);
            this.Controls.Add(this.sc_del);
            this.Controls.Add(this.sc_add);
            this.Controls.Add(this.label4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmSchedule";
            this.Text = "frmSchedule";
            this.Load += new System.EventHandler(this.frmSchedule_Load);
            ((System.ComponentModel.ISupportInitialize)(this.sc_edit)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button convert_sc;
        private System.Windows.Forms.DataGridView sc_edit;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column2;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column3;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column4;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column5;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column6;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column7;
        private System.Windows.Forms.DataGridViewButtonColumn Column8;
        private System.Windows.Forms.DataGridViewButtonColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewButtonColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.Button sc_save;
        private System.Windows.Forms.Button sc_del;
        private System.Windows.Forms.Button sc_add;
        private System.Windows.Forms.Label label4;
        private exCalendar.CustomCalendar customCalendar1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_nextMonth;
        private System.Windows.Forms.Button btn_preMonth;
        private System.Windows.Forms.Button btn_home;
        private System.Windows.Forms.Button button1;
    }
}