﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NCO_App
{
    public partial class usrNCOst : UserControl
    {
        public usrNCOst()
        {
            InitializeComponent();
            setOline = false;
            setFault = false;
            setFire = false;
        }

        public bool setOline
        {
            set
            {
                if (value)
                {
                    label_online.Text = "Online";
                    label_online.BackColor = Color.Lime;
                }
                else
                {
                    label_online.Text = "Offline";
                    label_online.BackColor = Color.Red;
                }
            }
        }
        public string setTitle
        {
            set
            {
                label_name.Text = value;
            }
        }
        public bool setFault
        {
            set
            {
                if (value)
                {
                    label_fault.BackColor = Color.Red;
                }
                else
                {
                    label_fault.BackColor = Color.Lime;
                }
            }
        }

        public bool setFire
        {
            set
            {
                if (value)
                {
                    label_fire.BackColor = Color.Red;
                }
                else
                {
                    label_fire.BackColor = Color.Lime;
                }
            }
        }

    }
}
