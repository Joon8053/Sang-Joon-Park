﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NCO_App
{
    public partial class usrZone : Button
    {
        StringFormat sformat;
        Font sffont;
        Source source_DP, source_HDMI, source_DVI, statusSync, label_error, plugDVI, plugHDMI, plugDP, statusPower, Title;
        public usrZone()
        {
            InitializeComponent();
            this.Size = new Size(160, 58);
            // 문자열 정렬
            sformat = new StringFormat();
            // 수평정렬
            sformat.Alignment = StringAlignment.Center;
            // 수직정렬
            sformat.LineAlignment = StringAlignment.Center;
            int sfFontSize = 10;

            sffont = new System.Drawing.Font("맑은 고딕", sfFontSize, FontStyle.Regular);
            plugDP = new Source("x");
            plugDVI = new Source("x");
            plugHDMI = new Source("x");
            Title = new Source("Monitor");
            Title.BackColor = Color.Black;
        }
        // this.Refresh();
        int width1 = 70, width2 = 25, height = 34;
        public Color txtColor = Color.Black;
        private void DrawRect(PaintEventArgs pevent, int no, Color cl, string ss, Color tColor)
        {
            Pen p = new Pen(Color.White, 1);
            Rectangle rec = new Rectangle(0, no * height, width1, height);
            pevent.Graphics.FillRectangle(new SolidBrush(cl), rec);
            pevent.Graphics.DrawRectangle(p, rec);
            pevent.Graphics.DrawString(ss, sffont, new SolidBrush(tColor), rec, sformat);
        }
        private void DrawRect2(PaintEventArgs pevent, int no, Color cl, string ss, Color tColor)
        {
            Pen p = new Pen(Color.White, 1);
            Rectangle rec = new Rectangle(width1, no * height, width2, height);
            pevent.Graphics.FillRectangle(new SolidBrush(cl), rec);
            pevent.Graphics.DrawRectangle(p, rec);
            pevent.Graphics.DrawString(ss, sffont, new SolidBrush(tColor), rec, sformat);
        }

        private void Senddraw(PaintEventArgs pevent, int no, Source scr, int mode)
        {
            if (mode == 1)
                DrawRect(pevent, no, scr.BackColor, scr.Text, txtColor);
            else
                DrawRect2(pevent, no, scr.BackColor, scr.Text, txtColor);
        }
        private void Senddraw2(PaintEventArgs pevent, int no, Source scr, int mode)
        {
            if (mode == 1)
                DrawRect(pevent, no, scr.BackColor, scr.Text, Color.White);
            else
                DrawRect2(pevent, no, scr.BackColor, scr.Text, Color.White);
        }
        protected override void OnPaint(PaintEventArgs pevent)
        {
            base.OnPaint(pevent);
            Senddraw2(pevent, 0, Title, 1);
            Senddraw(pevent, 0, label_error, 2);
            Senddraw(pevent, 2, source_DVI, 1);
            Senddraw(pevent, 2, plugDVI, 2);

            Senddraw(pevent, 1, source_HDMI, 1);
            Senddraw(pevent, 1, plugHDMI, 2);
            /*
            if (sub_input == 1)
            {
                Senddraw(pevent, 1, source_HDMI, 1);
                Senddraw(pevent, 1, plugHDMI, 2);
            }
            else
            {
                Senddraw(pevent, 1, source_DP, 1);
                Senddraw(pevent, 1, plugDP, 2);
            }
            */
            Senddraw(pevent, 3, statusPower, 1);
            Senddraw(pevent, 3, statusSync, 2);
        }


        class Source
        {
            public Color BackColor = Color.DimGray;
            public string Text;
            public Source(string ss)
            {
                Text = ss;
            }
        }


        public enum InputSource { None, DVI, HDMI, DP }

        Color selectColor = Color.DarkSeaGreen, unSelectColor = Color.DimGray;
        public int ID = 0;
        public void setSource(int id, InputSource source)
        {
            if (id == ID)
            {
                if (source == InputSource.DVI)
                {
                    source_DP.BackColor = unSelectColor;
                    source_HDMI.BackColor = unSelectColor;
                    source_DVI.BackColor = selectColor;
                }
                else if (source == InputSource.HDMI)
                {
                    source_DVI.BackColor = unSelectColor;
                    source_DP.BackColor = unSelectColor;
                    source_HDMI.BackColor = selectColor;
                }
                else if (source == InputSource.DP)
                {
                    source_DVI.BackColor = unSelectColor;
                    source_HDMI.BackColor = unSelectColor;
                    source_DP.BackColor = selectColor;
                }
                else
                {
                    source_DP.BackColor = unSelectColor;
                    source_HDMI.BackColor = unSelectColor;
                    source_DVI.BackColor = unSelectColor;
                }
                this.Refresh();
            }
        }

        public int send_cnt = 0;
        public void sendPacket(int id)
        {
            if (id == ID)
            {
                statusSync.BackColor = Color.Lime;
                statusSync.Text = "S";
                send_cnt++;
                label_error.Text = send_cnt.ToString();
                if (send_cnt > 10) label_error.BackColor = Color.Red;
                else label_error.BackColor = unSelectColor;
                this.Refresh();
            }
        }


        public void ReceivePacket(int id)
        {
            if (id == ID)
            {
                statusSync.BackColor = Color.Lime;
                statusSync.Text = "R";
                if (send_cnt > 0)
                    send_cnt--;
                label_error.Text = send_cnt.ToString();
                this.Refresh();
            }
        }


        public void setCount(int id)
        {
            if (id == ID)
            {
                send_cnt = 0;
                label_error.Text = send_cnt.ToString();
                this.Refresh();
            }
        }





        bool DVIplug, HDMIplug;
        public bool PlugErr()
        {
            return (DVIplug & HDMIplug); // and
        }

        Color plug_Yes = Color.Lime, plug_No = Color.Red;
        public void plugInDVI(int id, bool mode)
        {
            if (id == ID)
            {
                DVIplug = mode;
                if (mode)
                {
                    plugDVI.BackColor = plug_Yes;
                    plugDVI.Text = "P";
                }
                else
                {
                    plugDVI.BackColor = plug_No;
                    plugDVI.Text = "x";
                }
                this.Refresh();
            }
        }
        int sub_input = 0;
        public void plugInHDMI(int id, bool mode)
        {
            if (id == ID)
            {
                HDMIplug = mode;
                if (mode)
                {
                    plugHDMI.BackColor = plug_Yes;
                    plugHDMI.Text = "P";
                    sub_input = 1;
                }
                else
                {
                    plugHDMI.BackColor = plug_No;
                    plugHDMI.Text = "x";
                }
                this.Refresh();
            }
        }
        public void plugInDP(int id, bool mode)
        {
            if (id == ID)
            {
                if (mode)
                {
                    plugDP.BackColor = plug_Yes;
                    plugDP.Text = "P";
                    sub_input = 2;
                }
                else
                {
                    plugDP.BackColor = plug_No;
                    plugDP.Text = "x";
                }
                this.Refresh();
            }
        }

        const int bitDVI = 0x10;
        const int bitHDMI = 0x02;
        const int bitDP = 0x01;


        public void setOrionPlug(int id, int data)
        {
            if (id == ID)
            {
                if ((data & bitDVI) > 0)
                {
                    plugInDVI(id, true);
                }
                else
                {
                    plugInDVI(id, false);
                }
                if ((data & bitHDMI) > 0)
                {
                    plugInHDMI(id, true);
                }
                else
                {
                    plugInHDMI(id, false);
                }
                if ((data & bitDP) > 0)
                {
                    plugInDP(id, true);
                }
                else
                {
                    plugInDP(id, false);
                }
                this.Refresh();
            }
        }
        const int inDVI = 0x10;
        const int inHDMI = 0x20;
        const int inDP = 0x30;
        public int mSource = 0;
        public void setOrionInput(int id, int data)
        {
            if (id == ID)
            {
                mSource = 0;
                if (data == inDVI)
                {
                    setSource(id, InputSource.DVI);
                    mSource = 2;
                }
                else if (data == inHDMI)
                {
                    setSource(id, InputSource.HDMI);
                    mSource = 1;
                }
                else if (data == inDP)
                    setSource(id, InputSource.DP);
                else
                    setSource(id, InputSource.None);
                this.Refresh();
            }
        }

        public void setPower(int id, bool value)
        {
            if (id == ID)
            {
                if (value)
                {
                    statusPower.BackColor = Color.DarkSeaGreen;
                }
                else
                {
                    statusPower.BackColor = Color.DimGray;
                }
                this.Refresh();
            }
        }

        [Category("사용자 정의 항목"), Description("Title")]
        public string txtTitle
        {
            get { return Title.Text; }
            set
            {
                Title.Text = value;
                this.Refresh();
            }
        }


    }
}

