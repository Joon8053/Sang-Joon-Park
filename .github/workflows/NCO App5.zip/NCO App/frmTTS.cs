﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NCO_App
{
    public partial class frmTTS : Form
    {
        public frmTTS()
        {
            InitializeComponent();
        }

        private void frmTTS_Load(object sender, EventArgs e)
        {
            if (Debugger.IsAttached == false)
            {
                PTTS_Initialize();

                comboBoxSpeed.SelectedIndex = 1;  // 보통=100을 기본값으로 설정

                int uRETN;
                string textBoxPTTS_PATH = "C:\\Program Files (x86)\\HCILAB\\PowerTTS-S\\PowerTTS_M_DB\\KO_KR";  // Path를 고정
                if ((uRETN = PTTS_LoadEngine(PTTS_KO_KR, textBoxPTTS_PATH, 0)) < 0)
                {
                    //listBoxPTTS_LIST.Items.Add("TTS Engine Loading Error! : " + uRETN);
                    MessageBox.Show("TTS엔진 초기화 에러/점검 하세요");
                }
                //listBoxPTTS_LIST.Items.Add("Open Engine : " + PTTS_KO_KR);
            }
        }

        private const int WM_USER = 0x0400;
        private const int PTTS_PLAY_START = 1;
        private const int PTTS_PLAY_END = 4;
        private const int PTTS_KO_KR = 0;
        private const int PTTS_EN_US = 0;
        private const int PTTS_ZH_CN = 0;
        private const int PTTS_JA_JP = 0;


        /* -- PowerTTS.dll 파일 로드 및 함수 정의--*/
        [DllImport("PowerTTS_M.dll")]
        public static extern int PTTS_Initialize();
        [DllImport("PowerTTS_M.dll")]
        public static extern void PTTS_UnInitialize();
        [DllImport("PowerTTS_M.dll")]
        public static extern int PTTS_LoadEngine(int Language, string DbDir, int bLoadInMemory);
        [DllImport("PowerTTS_M.dll")]
        public static extern void PTTS_UnLoadEngine(int Language);
        [DllImport("PowerTTS_M.dll")]
        public static extern int PTTS_PlayTTS(IntPtr hUsrWnd, uint uUsrMsg, string TextBuf, string tagString, int Language, int SpeakerID);
        [DllImport("PowerTTS_M.dll")]
        public static extern int PTTS_TextToFile(int Language, int SpeakerID, int Format, int Encoding, int SamplingRate,
                      string TextBuf, string OutFileName, string tagString, string UserDictFileName);

        [DllImport("PowerTTS_M.dll")]
        public static extern int PTTS_StopTTS();
        /* ---------------------------------------*/

        /* -- 이벤트 처리 함수 --*/



        private void Form1_Load(object sender, EventArgs e)
        {

        }

        /* -- 합성 엔진 초기화 작업 --*/


        /* -- 합성 엔진 종료 작업 --*/


        /* -- 이벤트 처리 함수 --*/
        protected override void WndProc(ref Message m)
        {
            switch (m.Msg)
            {
                case WM_USER:
                    switch ((int)m.WParam)
                    {
                        case PTTS_PLAY_START:
                            //	listBoxPTTS_LIST.Items.Add("PTTS_PlayTTS(PTTS_PLAY_START)");
                            break;
                        case PTTS_PLAY_END:
                            //	listBoxPTTS_LIST.Items.Add("PTTS_PlayTTS(PTTS_PLAY_END)");
                            break;
                    }
                    break;
            }
            base.WndProc(ref m);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            PTTS_UnInitialize();
        }



        private void buttonPTTS_PLAY_Click(object sender, EventArgs e)
        {
            int uRETN = 0;
            int speed = 100; // Default speed
            if (comboBoxSpeed.SelectedIndex == -1)
                comboBoxSpeed.SelectedIndex = 1;
            switch (comboBoxSpeed.SelectedIndex)
            {
                case 0: // 느리게=80
                    speed = 80;
                    break;
                case 1: // 보통=100
                    speed = 100;
                    break;
                case 2: // 빠르게=120
                    speed = 120;
                    break;
                case 3: // 2배 빠르게=200
                    speed = 200;
                    break;
            }

            string tagString = string.Format("<speed=\"{0}\"></speed><pitch=\"100\"></pitch><volume=\"100\"></volume>", speed);

            // comboBoxPTTS_PLAY.Select edIndex가 항상 0이므로, 아래와 같이 변경합니다:
            uRETN = PTTS_PlayTTS(this.Handle, WM_USER, " <effect=\"eff_ex1\">" + textBoxPTTS_TEXT.Text + "<effect=\"eff_ex3\">", tagString, PTTS_KO_KR, 0);

            if (uRETN < 0)
            {
                //listBoxPTTS_LIST.Items.Add("PTTS_PlayTTS Error! : " + uRETN);
                return;
            }
        }

        private void buttonPTTS_STOP_Click(object sender, EventArgs e)
        {
            PTTS_StopTTS();
        }


        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Text File|*.txt";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                File.WriteAllText(saveFileDialog.FileName, textBoxPTTS_TEXT.Text);
            }
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Text File|*.txt";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                textBoxPTTS_TEXT.Text = File.ReadAllText(openFileDialog.FileName);
            }
        }

        private void btn_SaveAndMakeFile_Click(object sender, EventArgs e)
        {
            SaveFileDialog1.Filter = "wav파일|*.wav";

            if (SaveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string saveFile = SaveFileDialog1.FileName;

                if (!string.IsNullOrEmpty(saveFile))
                {
                    int uRETN = 0;
                    int speed = 100; // Default speed
                    switch (comboBoxSpeed.SelectedIndex)
                    {
                        case 0: // 느리게=80
                            speed = 80;
                            break;
                        case 1: // 보통=100
                            speed = 100;
                            break;
                        case 2: // 빠르게=120
                            speed = 120;
                            break;
                        case 3: // 2배 빠르게=200
                            speed = 200;
                            break;
                    }

                    string tagString = string.Format("<speed=\"{0}\"></speed><pitch=\"100\"></pitch><volume=\"100\"></volume>", speed);

                    uRETN = PTTS_TextToFile(PTTS_KO_KR, 0, 0, 0, 16000, " <effect=\"eff_ex1\">" + textBoxPTTS_TEXT.Text + "<effect=\"eff_ex3\">", saveFile, tagString, null);

                    if (uRETN < 0)
                    {
                        // listBoxPTTS_LIST.Items.Add("PTTS_TextToFile Error! : " + uRETN);
                        return;
                    }
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
