﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NCO_App
{
    public partial class frmZone : Form
    {
        frmMain app;

        public frmZone(frmMain main)
        {
            InitializeComponent();
            app = main;
        }

        public void setTitle(string title)
        {
            btn_title.Text = title;
        }
        public frmZone()
        {
            InitializeComponent();
        }
        private void frmZone_Load(object sender, EventArgs e)
        {
            this.Location = new Point(0, 0);
        }

        bool flgEdit = false;
        public void enEdit()
        {
            flgEdit = true;
        }
        class NCOgroup
        {
            public Button GrBtn = new Button();
            public UsrNCO1[] ZoneBtn = new UsrNCO1[5];
            public bool enEdit1 = false;
            public NCOgroup()
            {
                for (int i = 0; i < ZoneBtn.Length; i++)
                {
                    ZoneBtn[i] = new UsrNCO1();
                    ZoneBtn[i].Visible = true;
                }
            }
            public void SetLocatioin(int Row, Form pBase)
            {
                int xGap = 4;
                int yGap = 4;
                int xStart = 4;
                int yStatr = 40;

                pBase.Controls.Add(GrBtn);
                GrBtn.Size = new Size(160, 40);
                GrBtn.FlatStyle = FlatStyle.Flat;
                GrBtn.FlatAppearance.BorderSize = 1;
                GrBtn.FlatAppearance.BorderColor = Color.White;
                GrBtn.FlatAppearance.MouseOverBackColor = Color.Silver;
                GrBtn.FlatAppearance.MouseDownBackColor = Color.OliveDrab;
                GrBtn.BackColor = Color.Yellow;
                GrBtn.Location = new Point(xStart, yStatr + yGap * Row + (Row * GrBtn.Size.Height));
                GrBtn.Tag = Row;
                for (int i = 0; i < ZoneBtn.Length; i++)
                {
                    pBase.Controls.Add(ZoneBtn[i]);
                    ZoneBtn[i].Size = GrBtn.Size;
                    ZoneBtn[i].Location = new Point(xStart + xGap * (i + 1) + (GrBtn.Size.Width * (i + 1)), GrBtn.Location.Y);
                }
                pBase.Height = 90 + yGap * Row + (Row * GrBtn.Size.Height);
            }

            public void SetLocatioin(int Row, Form pBase,frmMain.NCO_ZONE zone)
            {
                int xGap = 4;
                int yGap = 4;
                int xStart = 4;
                int yStatr = 40;

                pBase.Controls.Add(GrBtn);
                GrBtn.Size = new Size(160, 40);
                GrBtn.FlatStyle = FlatStyle.Flat;
                GrBtn.FlatAppearance.BorderSize = 1;
                GrBtn.FlatAppearance.BorderColor = Color.White;
                GrBtn.FlatAppearance.MouseOverBackColor = Color.Silver;
                GrBtn.FlatAppearance.MouseDownBackColor = Color.OliveDrab;
                GrBtn.BackColor = Color.Yellow;
                GrBtn.Text = zone.GroupTitle;
                GrBtn.Location = new Point(xStart, yStatr + yGap * Row + (Row * GrBtn.Size.Height));
                GrBtn.Tag = Row;
                for (int i = 0; i < ZoneBtn.Length; i++)
                {
                    pBase.Controls.Add(ZoneBtn[i]);
                    ZoneBtn[i].Size = GrBtn.Size;
                    ZoneBtn[i].Location = new Point(xStart + xGap * (i + 1) + (GrBtn.Size.Width * (i + 1)), GrBtn.Location.Y);
                    if (enEdit1)
                        ZoneBtn[i].setTitle(zone.NcoZone[i] + "/" + zone.ZoneName[i]);
                    else
                    {
                        ZoneBtn[i].setTitle(zone.ZoneName[i]);
                        if (zone.ZoneName[i] == "")
                            ZoneBtn[i].Visible = false;
                        else
                            ZoneBtn[i].Visible = true;
                    }
                    ZoneBtn[i].BackColor = Color.White;
                }
                pBase.Height = 90 + yGap * Row + (Row * GrBtn.Size.Height);
            }
            public void Update(frmMain.NCO_ZONE zone)
            {
                GrBtn.Text = zone.GroupTitle;
                for (int i = 0; i < ZoneBtn.Length; i++)
                {
                    if (enEdit1)
                        ZoneBtn[i].setTitle(zone.NcoZone[i] + "/" + zone.ZoneName[i]);
                    else
                        ZoneBtn[i].setTitle(zone.ZoneName[i]);
                }
            }
            public void AllMode(bool mode)
            {
                for (int i = 0; i < ZoneBtn.Length; i++)
                {
                    ZoneBtn[i].setMode(mode);
                }
            }

            public void ZoneBtnUpdate(bool[] en)
            {
                for (int i = 0; i < ZoneBtn.Length; i++)
                {
                    ZoneBtn[i].setMode(en[i]);
                }
            }
        }

 

        public class selButtons
        {
            public bool[] check = new bool[5];
            public selButtons(bool[] data)
            {
                check = data;
            }
        }




        public List<selButtons> enButton = new List<selButtons>();
        public List<selButtons> SeletBtnList() ///preset..
        {
            enButton.Clear();
            for(int i=0;i< GroupBtn.Count;i++)
            {
                enButton.Add(new selButtons( NcoBtn[i].ZoneBtn.Take(5).Select(zone => zone.flgMode).ToArray()));
            }
            return enButton;
        }
        public void updateSelect(List<selButtons> en)
        {
            for (int i = 0; i < en.Count; i++)
            {
                NcoBtn[i].ZoneBtnUpdate(en[i].check);
            }
        }

        public void reqNcoZone(ref string[] zones)
        {
            if (NcoBtn.Count > 0)
            {
                for (int i = 0; i < NcoBtn.Count; i++)
                {
                    int no = app.NcoSite.ncoZone[selectSite][i].Nco_No;
                    for (int j = 0; j < 5; j++)
                    {
                        if (NcoBtn[i].ZoneBtn[j].flgMode)
                        {
                            zones[no] += app.NcoSite.ncoZone[selectSite][i].NcoZone[j] + ",";
                        }
                    }
                }
            }
        }

        public void UpdateZone(int NoNCO, int Priority, List<string> sZone,Color cl)
        {
            for (int i = 0; i < app.NcoSite.ncoZone[selectSite].Count; i++)
            {
                if(app.NcoSite.ncoZone[selectSite][i].Nco_No ==NoNCO)  // NCO가 맞을때
                {
                    foreach (string ss in sZone)
                    {
                        for (int j = 0; j < 5; j++)
                        {
                            if (app.NcoSite.ncoZone[selectSite][i].NcoZone[j] == ss)
                            {
                                NcoBtn[i].ZoneBtn[j].setColor(cl);
                                if (Priority == 65535) // off
                                {
                                    NcoBtn[i].ZoneBtn[j].setLevel("-");
                                }
                                else if (Priority == 0) // BGM
                                    NcoBtn[i].ZoneBtn[j].setLevel("");
                                else                   // Call
                                    NcoBtn[i].ZoneBtn[j].setLevel(Priority.ToString());
                            }
                        }
                    }
                }
                
            }
        }

        List<Button> GroupBtn = new List<Button>();
        List<UsrNCO1> ZoneBtn = new List<UsrNCO1>();

        List<NCOgroup> NcoBtn = new List<NCOgroup>();

        private void btn_title_Click(object sender, EventArgs e)
        {
            bool flg = true;
            for (int i = 0; i < NcoBtn.Count; i++)
            {
                bool tmp = NcoBtn[i].ZoneBtn.All(zone => zone.flgMode);
                if (tmp == false)
                {
                    flg = false;
                    break;
                }
            }
            for (int i = 0; i < NcoBtn.Count; i++)
            {
                NcoBtn[i].AllMode(!flg);
            }
        }

        public void AllOnOff(bool mode)
        {
            for (int i = 0; i < NcoBtn.Count; i++)
            {
                NcoBtn[i].AllMode(mode);
            }
        }
        int groupCnt = 0;
        public void AddGroup()
        {
            NCOgroup tmp = new NCOgroup();
            tmp.GrBtn.Click += GrBtn_Click;
            tmp.enEdit1 = flgEdit;
            if (app.tmp_Zone.Count >= groupCnt)
            {
                NcoBtn.Add(tmp);
                NcoBtn[groupCnt].SetLocatioin(groupCnt, this);
                groupCnt++;
            }
            else
            {
                MessageBox.Show("추가된 라인을 설정후 추가가 가능합니다.");
            }
        }

        public void AddGroup(int no, frmMain.NCO_ZONE zone)
        {
            NCOgroup tmp = new NCOgroup();
            tmp.GrBtn.Click += GrBtn_Click;
            tmp.enEdit1 = flgEdit;
            NcoBtn.Add(tmp);
            NcoBtn[groupCnt].SetLocatioin(groupCnt, this, zone);
            groupCnt++;
        }


        private void GrBtn_Click(object sender, EventArgs e)
        {
            int btn = Convert.ToInt16(((Control)sender).Tag);
            if (flgEdit)
            {     
                if (app.tmp_Zone.Count>btn)
                {
                    frmZoneAdd dlg = new frmZoneAdd(app, btn, app.tmp_Zone[btn]);
                    dlg.Update += Dlg_Update;
                    dlg.ShowDialog();
                }
                else
                {
                    frmZoneAdd dlg = new frmZoneAdd(app, btn, null);
                    dlg.Update += Dlg_Update;
                    dlg.ShowDialog();
                }
            }
            else
            {
                // 전체를 확인해서 선택안된것이 있다면 전체 선택, 전체 선택되어 있다면 선택 취소.
                NcoBtn[btn].AllMode(!NcoBtn[btn].ZoneBtn.All(zone => zone.flgMode));

               // NcoBtn[btn].AllMode(!checkMode(btn));
            }
        }

        private void Dlg_Update(frmMain.NCO_ZONE obj, int no)
        {
            if (app.tmp_Zone.Count > 0)
            {
                if (app.tmp_Zone.Count > no)
                {
                    app.tmp_Zone[no] = obj;
                    NcoBtn[no].Update(obj);
                }
                else
                {
                    app.tmp_Zone.Add(obj);
                    NcoBtn[app.tmp_Zone.Count-1].Update(obj);
                }
            }
            else
            {
                app.tmp_Zone.Add(obj);
                NcoBtn[0].Update(obj);
            }
        }

        public void EaseGrup()
        {
            if (groupCnt > 0)
            {
                groupCnt--;
                Erase_Button(NcoBtn[groupCnt]);
                if (app.tmp_Zone.Count>groupCnt)
                    app.tmp_Zone.RemoveAt(groupCnt);
                NcoBtn.RemoveAt(groupCnt);
            }
        }

        

        private void Erase_Button(NCOgroup gr)
        {
            int xGap = 4;
            int yGap = 4;
            int xStart = 4;
            int yStatr = 40;
            if (gr != null)
            {
                this.Controls.Remove(gr.GrBtn);
                for (int i = 0; i < 5; i++)
                {
                    this.Controls.Remove(gr.ZoneBtn[i]);
                }
            }
            this.Height = yGap * NcoBtn.Count + (NcoBtn.Count * yStatr);
        }


        private void Erase_All()
        {
            while (groupCnt > 0)
            {
                groupCnt--;
                Erase_Button(NcoBtn[groupCnt]);
                NcoBtn.RemoveAt(groupCnt);
            }
        }

        int selectSite = 0;
        public void LoadData(int no)
        {
            Erase_All();
            selectSite = no;
            btn_title.Text = app.NcoSite.ZoneTitle[no];
            app.tmp_Zone = new List<frmMain.NCO_ZONE>();
            if ((app.NcoSite != null)&&(app.NcoSite.ncoZone[selectSite]!=null))
            {
                for (int i = 0; i < app.NcoSite.ncoZone[selectSite].Count; i++)
                {
                    AddGroup(i, app.NcoSite.ncoZone[selectSite][i]);
                }
                app.tmp_Zone = app.NcoSite.ncoZone[selectSite];
            }
        }
    }
}
