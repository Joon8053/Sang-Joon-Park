﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NCO_App
{
    public partial class UsrNCO1 : UserControl
    {
        public UsrNCO1()
        {
            InitializeComponent();
            label_zone.Click += Label_zone_Click;
        }

        private void Label_zone_Click(object sender, EventArgs e)
        {
            flgMode = !flgMode;
            setMode(flgMode);
        }

        public void setColor(Color cl)
        {
            label_level.BackColor = cl;
        }
        public void setLevel(string level)
        {
            label_level.Text = level;
        }
        public void setTitle(string ss)
        {
            label_zone.Text = ss;
        }

        public Color OnColor = Color.Lime;
        public Color OffColor = Color.White;
        public bool flgMode = false;
        public void setMode(bool mode)
        {
            flgMode = mode;
            if (mode)
                label_zone.BackColor = OnColor;
            else
                label_zone.BackColor = OffColor;
        }
       
    }
}
