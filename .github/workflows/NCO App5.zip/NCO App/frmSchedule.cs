﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NCO_App
{
    public partial class frmSchedule : Form
    {
        public frmSchedule()
        {
            InitializeComponent();
        }

        bool flg_change = false;
        private void btn_nextMonth_Click(object sender, EventArgs e)
        {
            flg_change = true;
            customCalendar1.goToNextMonth();
        }

        private void btn_preMonth_Click(object sender, EventArgs e)
        {
            flg_change = true;
            customCalendar1.goToPreMonth();
        }

        private void btn_home_Click(object sender, EventArgs e)
        {
            flg_change = true;
            customCalendar1.goToToday();
        }

        private void customCalendar1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(customCalendar1.SelectedDate.ToString());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] no = {5,6 };
            string[] ss = { "aa\rcc\rgg", "bb" };
            DateTime[] dt = { DateTime.Now, DateTime.Now };
            customCalendar1.schedulerFontSize = 10;
            customCalendar1.SetSchedual(no, ss, DateTime.Now);
            
        }

        private void customCalendar1_MouseDown(object sender, MouseEventArgs e)
        {
            MessageBox.Show(customCalendar1.SelectedDate.ToString());
        }

        private void frmSchedule_Load(object sender, EventArgs e)
        {
            customCalendar1.onDayClick += CustomCalendar1_onDayClick;
        }

        private void CustomCalendar1_onDayClick(DateTime dt)
        {
            if (flg_change == false)
            {
                DateTime today = DateTime.Now.Date;
                if (dt >= today)
                {
                    MessageBox.Show(dt.ToString());
                }
                
            }
            flg_change = false;

        }
    }
}
