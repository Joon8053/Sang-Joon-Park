﻿using RHBform;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NCO_App
{
    public partial class frmZoneAdd : Form
    {

        frmMain app;
        int zoneId;
        TextBox[] setNCOzone = new TextBox[5];
        TextBox[] tBox;
        ComboBox[] cbox;
        public frmZoneAdd(frmMain main,int no, frmMain.NCO_ZONE zone)
        {
            InitializeComponent();
            app = main;
            zoneId = no;
            cbox = new ComboBox[] { comboBox_zone1, comboBox_zone2, comboBox_zone3, comboBox_zone4, comboBox_zone5 };
            tBox = new TextBox[] { textBox_zone1, textBox_zone2, textBox_zone3, textBox_zone4, textBox_zone5 };
            comboBox_nco.Items.Add(app.NcoSite.NCO[0].Name);
            comboBox_nco.Items.Add(app.NcoSite.NCO[1].Name);
            comboBox_nco.Items.Add(app.NcoSite.NCO[2].Name);
            comboBox_nco.SelectedIndex = 0;
            update_zone();
            if (zone != null)
            {
                comboBox_nco.SelectedIndex = zone.Nco_No;
                textBox_title.Text = zone.GroupTitle;

                if (app.NCO_rcvZoneList[zone.Nco_No].Count > 0)
                {
                    comboBox_zone1.Items.Add(zone.NcoZone[0]); comboBox_zone1.SelectedIndex = 0;
                    comboBox_zone2.Items.Add(zone.NcoZone[1]); comboBox_zone2.SelectedIndex = 0;
                    comboBox_zone3.Items.Add(zone.NcoZone[2]); comboBox_zone3.SelectedIndex = 0;
                    comboBox_zone4.Items.Add(zone.NcoZone[3]); comboBox_zone4.SelectedIndex = 0;
                    comboBox_zone5.Items.Add(zone.NcoZone[4]); comboBox_zone5.SelectedIndex = 0;
                }
                else
                {
                    for (int i = 0; i < 5; i++)
                    {
                        setNCOzone[i] = new TextBox();
                        this.Controls.Add(setNCOzone[i]);
                        cbox[i].Visible = false;
                        setNCOzone[i].Location = cbox[i].Location;
                        setNCOzone[i].Size = cbox[i].Size;
                        setNCOzone[i].Text = zone.NcoZone[i];
                    }
                }
                for (int i = 0; i < 5; i++)
                {
                    tBox[i].Text = zone.ZoneName[i];
                }
            }
            else
            {
                for (int i = 0; i < 5; i++)
                {
                    setNCOzone[i] = new TextBox();
                    this.Controls.Add(setNCOzone[i]);
                    cbox[i].Visible = false;
                    setNCOzone[i].Location = cbox[i].Location;
                    setNCOzone[i].Size = cbox[i].Size;
                }
            }
            comboBox_nco.SelectedIndexChanged += ComboBox_nco_SelectedIndexChanged;
        }

        private void update_zone()
        {

            textBox_zoneList.Text = string.Join(Environment.NewLine, app.ZONElist[comboBox_nco.SelectedIndex]);

        }

        private void ComboBox_nco_SelectedIndexChanged(object sender, EventArgs e)
        {
            int no = comboBox_nco.SelectedIndex;
            if (app.NCO_rcvZoneList[no].Count > 0)
            {
                for (int i = 0; i < 5; i++)
                {
                    cbox[i].Items.Clear();
                }

                foreach (string ss in app.NCO_rcvZoneList[no])
                {
                    for (int i = 0; i < 5; i++)
                    {
                        cbox[i].Items.Add(ss);
                    }
                }
            }
        }

        public frmZoneAdd()
        {
            InitializeComponent();
        }

        private void frmZoneAdd_Load(object sender, EventArgs e)
        {
            fromBase frm = new fromBase(this, panel_head, btn_close, label_title);
            label_title.Text += " " + zoneId.ToString();

        }

        private void btn_cancle_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public event Action<frmMain.NCO_ZONE,int> Update;
        private void btn_save_Click(object sender, EventArgs e)
        {
            frmMain.NCO_ZONE tmp = new frmMain.NCO_ZONE();
            try
            {
                tmp.Nco_No = comboBox_nco.SelectedIndex;
                tmp.GroupTitle = textBox_title.Text;
                for (int i = 0; i < 5; i++)
                {
                    if (comboBox_zone1.Visible == true)
                        tmp.NcoZone[i] = cbox[i].SelectedItem.ToString();
                    else
                        tmp.NcoZone[i] = setNCOzone[i].Text;
                    tmp.ZoneName[i] = tBox[i].Text;
                }
                Update?.Invoke(tmp, zoneId);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            this.Close();
        }

        private void comboBox_nco_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            update_zone();
        }
    }
}
