﻿using Newtonsoft.Json;
using RHBLibrary.Tools;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Authentication.ExtendedProtection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static NCO_App.frmMain;
using static RHBLibrary.schedule.clsScheduleDevice;
using static System.Windows.Forms.AxHost;


namespace NCO_App
{
    public partial class frmSCadd : Form
    {
        frmMain app;
        DateTime setDate;
        int EditNo =0;
        bool Edit_Week;
        public frmSCadd(frmMain main, bool day, int no, DateTime dt)
        {
            InitializeComponent();
            app = main;
            _width = this.Width;
            _height = this.Height;
            this.MinimumSize = new Size(_width, _height);
            this.MaximumSize = new Size(_width, _height);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.Resize += Form1_Resize;
            gr_msc.Text = "주간 스케쥴 등록";
            Array.ForEach(app.defBGMs, bgm => combo_BGM.Items.Add(bgm.Name));
            combo_BGM.SelectedIndex = 0;
            check_Auto.Checked = true;
            Edit_Week = day;
            if (day == false)
            {
                /*
                for(int i=0;i<app.defBGMs.Length;i++) 
                {
                    combo_BGM.Items.Add(app.defBGMs[i].Name);
                }
                */

                gr_msc.Text = "일자별 스케쥴 등록";
                gr_day.Visible = false;
                txt_date.Text = dt.ToString("yyyy-MM-dd");
                setDate = dt;

                if (no > 0)
                {
                    EditNo = no;
                    // edit mode...
                    // load file.
                }
            }
            CheckDays = new CheckBox[] { checkBox1, checkBox2, checkBox3, checkBox4, checkBox5, checkBox6, checkBox7 };

            // load file
            LoadFile();
            if (no > 0)
            {
                if (localSC.Count > EditNo)
                {
                    EditNo = no;
                    clsMonthScadule tmp = localSC[no];
                    //기존갑 표시.
                    if (Edit_Week)
                    {
                        for (int i = 0; i < tmp.EnWeek.Length; i++)
                        {
                            CheckDays[i].Checked = tmp.EnWeek[i];
                        }
                    }

                    txt_name.Text =tmp.Name ;
                    check_Auto.Checked =tmp.Auto;
                    btn_startTime.Text = tmp.getStartTime();
                    if (check_Auto.Checked == false)
                    {
                        txt_Endtime.Text = tmp.getEndtTime();
                    }
                    btn_musicFile.Text = tmp.getMusicFile();
                    combo_BGM.SelectedIndex = tmp.input;


                    for (int i = 0; i < FormZone.Length; i++)
                    {
                        if (tmp.Zone.Count > 0)
                        {
                            List<bool> stmp = tmp.Zone[i].ToList();
                            FormZone[i].updateSelect(stmp);
                        }
                    }
                }
                else
                    EditNo = 0; // index 없슴 에러. 수정작업
            }
        }
        CheckBox[] CheckDays;
        List<clsMonthScadule> localSC = new List<clsMonthScadule>();
        private void LoadFile()
        {
            string file = Application.StartupPath + "\\schedule\\"+ setDate.ToString("yyyy-MM");
            if(Edit_Week)
                file = Application.StartupPath + "\\schedule\\week";
            if (File.Exists(file) == true)
            {
                using (StreamReader reader = File.OpenText(file))
                {
                    string ss = reader.ReadToEnd();
                    try
                    {
                        localSC = JsonConvert.DeserializeObject< List<clsMonthScadule>> (ss);
                    }
                    catch
                    {

                    }
                }
            }
        }


        public void SaveFile(List<clsMonthScadule> mSC)
        {
            string file = Application.StartupPath + "\\schedule\\" + setDate.ToString("yyyy-MM");
            if (Edit_Week)
                file = Application.StartupPath + "\\schedule\\week";
            string jdata = JsonConvert.SerializeObject(mSC);

            using (StreamWriter writer = File.CreateText(file))
            {
                writer.WriteLine(jdata);
            }
            app.UpdateWeekSC();
            this.Close();
        }

        private int _width;
        private int _height;

        private void Form1_Resize(object sender, EventArgs e)
        {
            this.Width = _width;
            this.Height = _height;
        }

        private void FromAdd(Form frm, Panel pBase, int width, int height)
        {
            frm.TopLevel = false;
            frm.TopMost = true;
            frm.Parent = this;
            pBase.Controls.Add(frm);
            frm.Width = width;
            frm.Show();
            frm.Location = new Point(0, height);
        }

        frmZone[] FormZone = new frmZone[4];

        private void frmSCadd_Load(object sender, EventArgs e)
        {
            FormZone[0] = new frmZone(app);
            FromAdd(FormZone[0], panel_zone, 990, 0);
            FormZone[0].LoadData(0);
            FormZone[1] = new frmZone(app);
            FromAdd(FormZone[1], panel_zone, 990, FormZone[0].Size.Height + FormZone[0].Location.Y);
            FormZone[1].LoadData(1);
            FormZone[2] = new frmZone(app);
            FromAdd(FormZone[2], panel_zone, 990, FormZone[1].Size.Height + FormZone[1].Location.Y);
            FormZone[2].LoadData(2);
            FormZone[3] = new frmZone(app);
            FromAdd(FormZone[3], panel_zone, 990, FormZone[2].Size.Height + FormZone[2].Location.Y);
            FormZone[3].LoadData(3);
;
            Preset_Visible();
           // sc_edit.AllowUserToAddRows = false;          //데이타 그리드뷰 마지막 빈줄 삭제
        }


        private void Clear_Button()
        {
            if ((preSet != null) && (preSet.Count > 0))
            {
                for (int i = 0; i < preSet.Count; i++)
                {
                    this.panel_preset.Controls.Remove(preSet[i]);
                }
                preSet.Clear();
            }
        }

        List<Button> preSet = new List<Button>();
        List<String> presetName = new List<String>();

        private void grMode()
        {

            CreateBtn ButtonPos;
            ButtonPos = new CreateBtn(170, 35, 10, 10);
            ButtonPos.ArrayX = 1;
            ButtonPos.GapX = 6;
            ButtonPos.GapY = 10;

            Clear_Button();
            int maxBtn = presetName.Count;
            if (maxBtn > 0)
            {
                Button[] btn_sMode = new Button[maxBtn];
                for (int cnt = 0; cnt < maxBtn; cnt++)
                {
                    btn_sMode[cnt] = new Button();
                    Button Btn = btn_sMode[cnt];
                    Btn.Click += new System.EventHandler(this.bntPrest_Click);
                    panel_preset.Controls.Add(Btn);

                    Btn.FlatStyle = FlatStyle.Flat;
                    Btn.FlatAppearance.BorderSize = 1;
                    Btn.FlatAppearance.BorderColor = Color.White;
                    Btn.FlatAppearance.MouseDownBackColor = Color.Lime;

                    Btn.Visible = true;
                    Btn.ForeColor = Color.Black;
                    Btn.BackColor = Color.White;
                    Btn.Font = new Font("GulimChe", 11F, FontStyle.Regular);
                    Btn.Size = new Size(ButtonPos.Width, ButtonPos.Height);
                    ButtonPos.Cul_pos(cnt + 1);
                    Btn.Location = new Point(ButtonPos.PosX, ButtonPos.PosY);
                    Btn.Tag = cnt;
                    Btn.Text = presetName[cnt];
                    preSet.Add(Btn);
                }
            }
        }


        // Preset Button visible
        private void Preset_Visible()
        {
            presetName.Clear();
            string file_path = Application.StartupPath + "\\Preset\\";
            foreach (string file in Directory.GetFiles(file_path))
            {
                string ss = file_path;
                string s = file.Replace(ss, "");
                if (file.IndexOf(".pre") > 0)
                {
                    s = s.Replace(".pre", "");
                    presetName.Add(s);
                }
            }
            grMode();
        }

        private void bntPrest_Click(object sender, EventArgs e)
        {
            int btn = Convert.ToInt16(((Control)sender).Tag);
            string name = preSet[btn].Text;
            string ss = Application.StartupPath + "\\Preset\\" + name + ".pre";
            PresetGo(ss);
        }

        private void PresetGo(string file)
        {
            if (File.Exists(file) == true)
            {
                using (StreamReader reader = File.OpenText(file))
                {
                    string sData = reader.ReadToEnd();
                    try
                    {
                        List<bool[]> tmp = JsonConvert.DeserializeObject<List<bool[]>>(sData);

                        for (int i = 0; i < FormZone.Length; i++)
                        {
                            if (tmp.Count > 0)
                            {
                                List<bool> stmp = tmp[i].ToList();
                                FormZone[i].updateSelect(stmp);
                            }
                        }
                    }
                    catch
                    {
                    }
                }
            }
        }

        private void btn_Allon_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < FormZone.Length; i++)
            {
                FormZone[i].AllOnOff(true);
            }
        }

        private void btn_Alloff_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < FormZone.Length; i++)
            {
                FormZone[i].AllOnOff(false);
            }
        }

       





        private void btn_startTime_Click(object sender, EventArgs e)
        {
            if(check_Auto.Checked)
            {
                frmTimeSetting dlg = new frmTimeSetting(true);
                dlg.OnUpdate += Dlg_OnUpdate_start;
                dlg.Show();
            }
            else
            {
                frmTimeSetting dlg = new frmTimeSetting(false);
                dlg.OnUpdate += Dlg_OnUpdate;
                dlg.Show();
            }
        }

        private void Dlg_OnUpdate(DateTime stime, DateTime etime)
        {
            btn_startTime.Text = stime.ToString("HH:mm:ss");
            txt_Endtime.Text = etime.ToString("HH:mm:ss");
        }
        private void Dlg_OnUpdate_start(DateTime stime, DateTime etime)
        {
            btn_startTime.Text = stime.ToString("HH:mm:ss");
            txt_Endtime.Text = stime.ToString("HH:mm:ss");
        }

        //동일 시간대 chkeck..
        private bool CheckTime(clsMonthScadule tmp)
        {
            bool flg_check=false;
            foreach (clsMonthScadule tt in localSC)
            {
                if ((Edit_Week==false)&&(tt.Day == tmp.Day))
                {
                    flg_check = true;
                }
                else if (Edit_Week)
                {
                    flg_check = true;
                }
                if (flg_check)
                {
                    if (tt.startTime == tmp.startTime) return true;  //동일한 경우
                    if (tt.Auto == false)
                    {
                        if ((tt.startTime < tmp.startTime) && (tt.endTime > tmp.startTime)) return true; // 사이에 낀경우
                        if (tt.endTime == tmp.startTime) return true; // 종료 시간과 동일
                        if (tmp.Auto == false)
                        {
                            if (tt.startTime == tmp.endTime) return true; // 종료 시간과 동일
                        }
                    }
                }
                flg_check = false;
            }

            return false;
        }
        List<string> musicList = new List<string>();
        private void btn_save2_Click(object sender, EventArgs e)
        {

            clsMonthScadule tmp = new clsMonthScadule();
            
            if (Edit_Week)
            {
                for(int i=0;i<tmp.EnWeek.Length;i++)
                {
                    tmp.EnWeek[i] = CheckDays[i].Checked;
                }
                bool result = !tmp.EnWeek.Any(val => val == true);
                if(result)
                {
                    MessageBox.Show("요일이 선택 되지 않았습니다.");
                    return;
                }

            }
            else
            {
                tmp.Day = setDate.Day;
            }
            
            if (txt_name.Text != "")
                tmp.Name = txt_name.Text;
            else
            {
                MessageBox.Show("이름이 설정 되지 않았습니다.");
                return;
            }
            tmp.Auto = check_Auto.Checked;
            tmp.setStartTime(btn_startTime.Text);
            if (check_Auto.Checked == false)
            {
                tmp.setEndTime(txt_Endtime.Text);
                // 동일한지 점검.
            }
            if((check_Auto.Checked)&&(musicList.Count==0))
            {
                MessageBox.Show("자동 종료는 음원 파일이 있어야 합니다.");
                return;
            }
            tmp.MusicFile = musicList;

            tmp.input = combo_BGM.SelectedIndex;
            List<bool[]> preseZone = new List<bool[]>();
            for (int i = 0; i < FormZone.Length; i++)
            {
                preseZone.Add(FormZone[i].getSelect().ToArray());
            }
            tmp.Zone = preseZone;

            if (CheckTime(tmp) == false)
            {
                if (EditNo > 0)
                    localSC[EditNo] = tmp;
                else
                    localSC.Add(tmp);

                // SORT.
                if (Edit_Week)
                {
                    localSC.Sort((s1, s2) => s1.startTime.CompareTo(s2.startTime));
                }
                else
                {
                    // tmp 리스트를 Day 기준으로 오름차순 정렬합니다.
                    localSC.Sort((a, b) => a.Day.CompareTo(b.Day));
                    // Day 값이 같은 경우 StartTime 기준으로 오름차순 정렬합니다.
                    localSC.Sort((a, b) => a.Day == b.Day ? a.startTime.CompareTo(b.startTime) : 0);
                }
                // 정렬된 값 저장.
                List<clsMonthScadule> mSC = new List<clsMonthScadule>();

                foreach (clsMonthScadule tt in localSC)
                {
                    mSC.Add(tt);
                }
                SaveFile(mSC);
            }
            else
            {
                MessageBox.Show("동일한 시간에 스케쥴이 존재 합니다.");
                return;
            }
        }


        private void UpdateMusicList()
        {
            string ss = "-";
            listBox_music.Items.Clear();
            if (musicList.Count > 0)
            {
                List<string> mList = new List<string>();
                foreach (string s in musicList)
                {
                    string name = Path.GetFileNameWithoutExtension(s);
                    mList.Add(name);
                    listBox_music.Items.Add(name);
                }

                if (mList.Count > 0)
                {
                    ss = mList[0];
                    if (mList.Count > 1)
                        ss = string.Format("{0}({1})", ss, mList.Count-1);
                }
            }
            btn_musicFile.Text = ss;
        }


        private void btn_musicFile_Click(object sender, EventArgs e)
        {
            var openFileDialog = new OpenFileDialog()
            {
                InitialDirectory = app.mainVar.musicFolder,
                Filter = "MP3|*.mp3|WAV|*.wav",
                FilterIndex = 0,
                Multiselect = false
            };
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                musicList.Add(openFileDialog.FileName);
                UpdateMusicList();
            }
        }

        private void btn_all_Click(object sender, EventArgs e)
        {
            bool hasFalse = CheckDays.Any(value => value.Checked == false);
            Array.ForEach(CheckDays, val => val.Checked = hasFalse ? true : false);
        }

        private void listBox_music_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = listBox_music.SelectedIndex;
            if (index != -1)
            {
                musicList.RemoveAt(index);
                UpdateMusicList();
            }
        }
    }
}
