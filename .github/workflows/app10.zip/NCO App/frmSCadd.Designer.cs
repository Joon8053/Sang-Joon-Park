﻿namespace NCO_App
{
    partial class frmSCadd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSCadd));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.listBox_music = new System.Windows.Forms.ListBox();
            this.panel_preset = new System.Windows.Forms.Panel();
            this.panel_zone = new System.Windows.Forms.Panel();
            this.btn_Alloff = new RHBform.RHBbutton();
            this.btn_Allon = new RHBform.RHBbutton();
            this.btn_preAdd = new RHBform.RHBbutton();
            this.rhBbutton1 = new RHBform.RHBbutton();
            this.rhBbutton2 = new RHBform.RHBbutton();
            this.gr_msc = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.gr_day = new System.Windows.Forms.GroupBox();
            this.btn_all = new System.Windows.Forms.Button();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.btn_musicFile = new System.Windows.Forms.Button();
            this.btn_save2 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_date = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.combo_BGM = new System.Windows.Forms.ComboBox();
            this.check_Auto = new System.Windows.Forms.CheckBox();
            this.txt_Endtime = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_startTime = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.gr_msc.SuspendLayout();
            this.gr_day.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.panel_preset);
            this.panel1.Controls.Add(this.panel_zone);
            this.panel1.Controls.Add(this.btn_Alloff);
            this.panel1.Controls.Add(this.btn_Allon);
            this.panel1.Controls.Add(this.btn_preAdd);
            this.panel1.Controls.Add(this.rhBbutton1);
            this.panel1.Controls.Add(this.rhBbutton2);
            this.panel1.Location = new System.Drawing.Point(12, 185);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1224, 766);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Controls.Add(this.listBox_music);
            this.panel2.Location = new System.Drawing.Point(1002, 28);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(210, 266);
            this.panel2.TabIndex = 528;
            // 
            // listBox_music
            // 
            this.listBox_music.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.listBox_music.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.listBox_music.ForeColor = System.Drawing.Color.White;
            this.listBox_music.FormattingEnabled = true;
            this.listBox_music.ItemHeight = 15;
            this.listBox_music.Location = new System.Drawing.Point(12, 10);
            this.listBox_music.Name = "listBox_music";
            this.listBox_music.Size = new System.Drawing.Size(183, 244);
            this.listBox_music.TabIndex = 0;
            this.listBox_music.SelectedIndexChanged += new System.EventHandler(this.listBox_music_SelectedIndexChanged);
            // 
            // panel_preset
            // 
            this.panel_preset.AutoScroll = true;
            this.panel_preset.BackColor = System.Drawing.Color.Black;
            this.panel_preset.Location = new System.Drawing.Point(1002, 326);
            this.panel_preset.Name = "panel_preset";
            this.panel_preset.Size = new System.Drawing.Size(210, 437);
            this.panel_preset.TabIndex = 523;
            // 
            // panel_zone
            // 
            this.panel_zone.AutoScroll = true;
            this.panel_zone.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.panel_zone.Location = new System.Drawing.Point(0, 28);
            this.panel_zone.Name = "panel_zone";
            this.panel_zone.Size = new System.Drawing.Size(996, 735);
            this.panel_zone.TabIndex = 2;
            // 
            // btn_Alloff
            // 
            this.btn_Alloff.BackColor = System.Drawing.Color.Transparent;
            this.btn_Alloff.ForeColor = System.Drawing.Color.Yellow;
            this.btn_Alloff.Location = new System.Drawing.Point(876, -15);
            this.btn_Alloff.Name = "btn_Alloff";
            this.btn_Alloff.setFontColor = System.Drawing.Color.Yellow;
            this.btn_Alloff.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_Alloff.setOFFimage")));
            this.btn_Alloff.setON = false;
            this.btn_Alloff.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_Alloff.setONimage")));
            this.btn_Alloff.setText = "전체 취소";
            this.btn_Alloff.setToggle = false;
            this.btn_Alloff.Size = new System.Drawing.Size(120, 60);
            this.btn_Alloff.TabIndex = 524;
            this.btn_Alloff.TabStop = false;
            this.btn_Alloff.Tag = "2";
            this.btn_Alloff.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Alloff.Click += new System.EventHandler(this.btn_Alloff_Click);
            // 
            // btn_Allon
            // 
            this.btn_Allon.BackColor = System.Drawing.Color.Transparent;
            this.btn_Allon.ForeColor = System.Drawing.Color.Yellow;
            this.btn_Allon.Location = new System.Drawing.Point(757, -15);
            this.btn_Allon.Name = "btn_Allon";
            this.btn_Allon.setFontColor = System.Drawing.Color.Yellow;
            this.btn_Allon.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_Allon.setOFFimage")));
            this.btn_Allon.setON = false;
            this.btn_Allon.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_Allon.setONimage")));
            this.btn_Allon.setText = "전체 선택";
            this.btn_Allon.setToggle = false;
            this.btn_Allon.Size = new System.Drawing.Size(120, 60);
            this.btn_Allon.TabIndex = 525;
            this.btn_Allon.TabStop = false;
            this.btn_Allon.Tag = "2";
            this.btn_Allon.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Allon.Click += new System.EventHandler(this.btn_Allon_Click);
            // 
            // btn_preAdd
            // 
            this.btn_preAdd.BackColor = System.Drawing.Color.Transparent;
            this.btn_preAdd.ForeColor = System.Drawing.Color.Yellow;
            this.btn_preAdd.Location = new System.Drawing.Point(1002, 278);
            this.btn_preAdd.Name = "btn_preAdd";
            this.btn_preAdd.setFontColor = System.Drawing.Color.Yellow;
            this.btn_preAdd.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_preAdd.setOFFimage")));
            this.btn_preAdd.setON = false;
            this.btn_preAdd.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_preAdd.setONimage")));
            this.btn_preAdd.setText = "방송그룹";
            this.btn_preAdd.setToggle = false;
            this.btn_preAdd.Size = new System.Drawing.Size(120, 60);
            this.btn_preAdd.TabIndex = 526;
            this.btn_preAdd.TabStop = false;
            this.btn_preAdd.Tag = "2";
            this.btn_preAdd.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // rhBbutton1
            // 
            this.rhBbutton1.BackColor = System.Drawing.Color.Transparent;
            this.rhBbutton1.ForeColor = System.Drawing.Color.Yellow;
            this.rhBbutton1.Location = new System.Drawing.Point(1, -14);
            this.rhBbutton1.Name = "rhBbutton1";
            this.rhBbutton1.setFontColor = System.Drawing.Color.Yellow;
            this.rhBbutton1.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton1.setOFFimage")));
            this.rhBbutton1.setON = false;
            this.rhBbutton1.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton1.setONimage")));
            this.rhBbutton1.setText = "방송 지역 선택";
            this.rhBbutton1.setToggle = false;
            this.rhBbutton1.Size = new System.Drawing.Size(120, 60);
            this.rhBbutton1.TabIndex = 527;
            this.rhBbutton1.TabStop = false;
            this.rhBbutton1.Tag = "2";
            this.rhBbutton1.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // rhBbutton2
            // 
            this.rhBbutton2.BackColor = System.Drawing.Color.Transparent;
            this.rhBbutton2.ForeColor = System.Drawing.Color.Yellow;
            this.rhBbutton2.Location = new System.Drawing.Point(1003, -17);
            this.rhBbutton2.Name = "rhBbutton2";
            this.rhBbutton2.setFontColor = System.Drawing.Color.Yellow;
            this.rhBbutton2.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton2.setOFFimage")));
            this.rhBbutton2.setON = false;
            this.rhBbutton2.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton2.setONimage")));
            this.rhBbutton2.setText = "음원 목록 (클릭 삭제)";
            this.rhBbutton2.setToggle = false;
            this.rhBbutton2.Size = new System.Drawing.Size(159, 60);
            this.rhBbutton2.TabIndex = 529;
            this.rhBbutton2.TabStop = false;
            this.rhBbutton2.Tag = "2";
            this.rhBbutton2.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gr_msc
            // 
            this.gr_msc.Controls.Add(this.label4);
            this.gr_msc.Controls.Add(this.gr_day);
            this.gr_msc.Controls.Add(this.btn_musicFile);
            this.gr_msc.Controls.Add(this.btn_save2);
            this.gr_msc.Controls.Add(this.label6);
            this.gr_msc.Controls.Add(this.txt_date);
            this.gr_msc.Controls.Add(this.label5);
            this.gr_msc.Controls.Add(this.combo_BGM);
            this.gr_msc.Controls.Add(this.check_Auto);
            this.gr_msc.Controls.Add(this.txt_Endtime);
            this.gr_msc.Controls.Add(this.label3);
            this.gr_msc.Controls.Add(this.btn_startTime);
            this.gr_msc.Controls.Add(this.label2);
            this.gr_msc.Controls.Add(this.label1);
            this.gr_msc.Controls.Add(this.txt_name);
            this.gr_msc.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.gr_msc.ForeColor = System.Drawing.Color.White;
            this.gr_msc.Location = new System.Drawing.Point(13, 12);
            this.gr_msc.Name = "gr_msc";
            this.gr_msc.Size = new System.Drawing.Size(1223, 153);
            this.gr_msc.TabIndex = 22;
            this.gr_msc.TabStop = false;
            this.gr_msc.Text = "일자별 스케쥴";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.Location = new System.Drawing.Point(907, 87);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 15);
            this.label4.TabIndex = 8;
            this.label4.Text = "재생 파일 선택";
            // 
            // gr_day
            // 
            this.gr_day.Controls.Add(this.btn_all);
            this.gr_day.Controls.Add(this.checkBox7);
            this.gr_day.Controls.Add(this.checkBox6);
            this.gr_day.Controls.Add(this.checkBox5);
            this.gr_day.Controls.Add(this.checkBox4);
            this.gr_day.Controls.Add(this.checkBox3);
            this.gr_day.Controls.Add(this.checkBox2);
            this.gr_day.Controls.Add(this.checkBox1);
            this.gr_day.ForeColor = System.Drawing.Color.White;
            this.gr_day.Location = new System.Drawing.Point(61, 24);
            this.gr_day.Name = "gr_day";
            this.gr_day.Size = new System.Drawing.Size(544, 55);
            this.gr_day.TabIndex = 27;
            this.gr_day.TabStop = false;
            // 
            // btn_all
            // 
            this.btn_all.ForeColor = System.Drawing.Color.Black;
            this.btn_all.Location = new System.Drawing.Point(422, 16);
            this.btn_all.Name = "btn_all";
            this.btn_all.Size = new System.Drawing.Size(103, 31);
            this.btn_all.TabIndex = 7;
            this.btn_all.Text = "전체";
            this.btn_all.UseVisualStyleBackColor = true;
            this.btn_all.Click += new System.EventHandler(this.btn_all_Click);
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(340, 22);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(41, 19);
            this.checkBox7.TabIndex = 6;
            this.checkBox7.Text = "토";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(290, 22);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(41, 19);
            this.checkBox6.TabIndex = 5;
            this.checkBox6.Text = "금";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(240, 22);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(41, 19);
            this.checkBox5.TabIndex = 4;
            this.checkBox5.Text = "목";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(190, 22);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(41, 19);
            this.checkBox4.TabIndex = 3;
            this.checkBox4.Text = "수";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(140, 22);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(41, 19);
            this.checkBox3.TabIndex = 2;
            this.checkBox3.Text = "화";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(90, 22);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(41, 19);
            this.checkBox2.TabIndex = 1;
            this.checkBox2.Text = "월";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(40, 22);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(41, 19);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.Text = "일";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // btn_musicFile
            // 
            this.btn_musicFile.BackColor = System.Drawing.Color.DimGray;
            this.btn_musicFile.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_musicFile.ForeColor = System.Drawing.Color.White;
            this.btn_musicFile.Location = new System.Drawing.Point(910, 105);
            this.btn_musicFile.Name = "btn_musicFile";
            this.btn_musicFile.Size = new System.Drawing.Size(307, 34);
            this.btn_musicFile.TabIndex = 7;
            this.btn_musicFile.UseVisualStyleBackColor = false;
            this.btn_musicFile.Click += new System.EventHandler(this.btn_musicFile_Click);
            // 
            // btn_save2
            // 
            this.btn_save2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_save2.ForeColor = System.Drawing.Color.Black;
            this.btn_save2.Location = new System.Drawing.Point(1111, 22);
            this.btn_save2.Name = "btn_save2";
            this.btn_save2.Size = new System.Drawing.Size(103, 43);
            this.btn_save2.TabIndex = 26;
            this.btn_save2.Text = "저장\r\n닫기";
            this.btn_save2.UseVisualStyleBackColor = false;
            this.btn_save2.Click += new System.EventHandler(this.btn_save2_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label6.Location = new System.Drawing.Point(62, 26);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 15);
            this.label6.TabIndex = 12;
            this.label6.Text = "방송 일자";
            // 
            // txt_date
            // 
            this.txt_date.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_date.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txt_date.ForeColor = System.Drawing.Color.Black;
            this.txt_date.Location = new System.Drawing.Point(61, 46);
            this.txt_date.Name = "txt_date";
            this.txt_date.Size = new System.Drawing.Size(214, 34);
            this.txt_date.TabIndex = 11;
            this.txt_date.Text = "2023-00-00";
            this.txt_date.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.txt_date.UseVisualStyleBackColor = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.Location = new System.Drawing.Point(753, 87);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 15);
            this.label5.TabIndex = 10;
            this.label5.Text = "BGM 입력";
            // 
            // combo_BGM
            // 
            this.combo_BGM.FormattingEnabled = true;
            this.combo_BGM.Location = new System.Drawing.Point(685, 111);
            this.combo_BGM.Name = "combo_BGM";
            this.combo_BGM.Size = new System.Drawing.Size(191, 23);
            this.combo_BGM.TabIndex = 9;
            // 
            // check_Auto
            // 
            this.check_Auto.AutoSize = true;
            this.check_Auto.Location = new System.Drawing.Point(300, 114);
            this.check_Auto.Name = "check_Auto";
            this.check_Auto.Size = new System.Drawing.Size(91, 19);
            this.check_Auto.TabIndex = 6;
            this.check_Auto.Text = "자동 종료";
            this.check_Auto.UseVisualStyleBackColor = true;
            // 
            // txt_Endtime
            // 
            this.txt_Endtime.BackColor = System.Drawing.Color.DimGray;
            this.txt_Endtime.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txt_Endtime.ForeColor = System.Drawing.Color.White;
            this.txt_Endtime.Location = new System.Drawing.Point(525, 105);
            this.txt_Endtime.Name = "txt_Endtime";
            this.txt_Endtime.Size = new System.Drawing.Size(111, 34);
            this.txt_Endtime.TabIndex = 5;
            this.txt_Endtime.Text = "00:00:00";
            this.txt_Endtime.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(545, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "종료 시간";
            // 
            // btn_startTime
            // 
            this.btn_startTime.BackColor = System.Drawing.Color.DimGray;
            this.btn_startTime.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_startTime.ForeColor = System.Drawing.Color.White;
            this.btn_startTime.Location = new System.Drawing.Point(402, 105);
            this.btn_startTime.Name = "btn_startTime";
            this.btn_startTime.Size = new System.Drawing.Size(111, 34);
            this.btn_startTime.TabIndex = 3;
            this.btn_startTime.Text = "00:00:00";
            this.btn_startTime.UseVisualStyleBackColor = false;
            this.btn_startTime.Click += new System.EventHandler(this.btn_startTime_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(424, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "시작시간";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(58, 87);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "방송 이름";
            // 
            // txt_name
            // 
            this.txt_name.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txt_name.Location = new System.Drawing.Point(61, 111);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(214, 26);
            this.txt_name.TabIndex = 0;
            // 
            // frmSCadd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.ClientSize = new System.Drawing.Size(1246, 961);
            this.Controls.Add(this.gr_msc);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "frmSCadd";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "예약 방송 설정";
            this.Load += new System.EventHandler(this.frmSCadd_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.gr_msc.ResumeLayout(false);
            this.gr_msc.PerformLayout();
            this.gr_day.ResumeLayout(false);
            this.gr_day.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel_zone;
        private System.Windows.Forms.Panel panel_preset;
        private RHBform.RHBbutton btn_Alloff;
        private RHBform.RHBbutton btn_Allon;
        private RHBform.RHBbutton btn_preAdd;
        private RHBform.RHBbutton rhBbutton1;
        private System.Windows.Forms.GroupBox gr_msc;
        private System.Windows.Forms.Button txt_Endtime;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_startTime;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button txt_date;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox combo_BGM;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_musicFile;
        private System.Windows.Forms.CheckBox check_Auto;
        private System.Windows.Forms.Button btn_save2;
        private System.Windows.Forms.GroupBox gr_day;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button btn_all;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ListBox listBox_music;
        private RHBform.RHBbutton rhBbutton2;
    }
}