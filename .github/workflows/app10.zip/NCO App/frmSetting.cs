﻿using RHBLibrary.Tools;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static NCO_App.frmBroadcast;

namespace NCO_App
{
    public partial class frmSetting : Form
    {
        frmMain app;
        public frmSetting(frmMain main)
        {
            InitializeComponent();
            app = main;
        }


        Button[] Zone, BtnNco,BGMColors,BGMnames,CallBtns,sBtn_ncos,Btn_Musics;
        TextBox[] BGMncos;
        private void frmSetting_Load(object sender, EventArgs e)
        {
            Zone = new Button[] { btn_zone1, btn_zone2, btn_zone3, btn_zone4 };
            BtnNco = new Button[] { btn_nco1, btn_nco2, btn_nco3 };
            sBtn_ncos = new Button[] { sbtn_nco1, sbtn_nco2, sbtn_nco3 };

            BGMColors = new Button[] { btn_bgmColor1, btn_bgmColor2, btn_bgmColor3, btn_bgmColor4, btn_bgmColor5 };
            BGMnames = new Button[] { btn_Bgm1, btn_Bgm2, btn_Bgm3, btn_Bgm4, btn_Bgm5 };
            BGMncos = new TextBox[] { txt_BgmNCO1, txt_BgmNCO2, txt_BgmNCO3, txt_BgmNCO4, txt_BgmNCO5 };
            CallBtns = new Button[] { btn_call1, btn_call2, btn_call3, btn_call4, btn_call5 };
            Btn_Musics = new Button[] { btn_music1, btn_music2, btn_music3, btn_music4 };
            initTag(BGMColors);
            initTag(BGMnames);
            initTag(CallBtns);
            initTag(sBtn_ncos);
            initNcoText(BtnNco);
            initNcoText(sBtn_ncos);
            for (int i = 0; i < BGMColors.Length; i++)
            {
                BGMColors[i].Click += BGMColors_Click;
                BGMnames[i].Click += BGMnames_Click;
                CallBtns[i].Click += CallBtns_Click;
                if (Btn_Musics.Length > i)
                {
                    Btn_Musics[i].Tag = i;
                   Btn_Musics[i].Click += BtnMusics_Click;
                }
            }

            FormZone = new frmZone(app);
            FormZone.TopLevel = false;
            FormZone.TopMost = true;
            FormZone.Parent = this;
            panel_zoneFrm.Controls.Add(FormZone);
            FormZone.Width = 990;
            FormZone.Show();
            FormZone.enEdit();
            btn_nco1_Click(null, null);
            btn_zone1_Click(null, null);
            upDateBGM();
            CallBtns_Click(null, null);
            this.Size = new Size(1920, 1100);
            buttonCreate_Net();
            UpdateNetBtn();
            initMusicsName(Btn_Musics);
        }

        private void BtnMusics_Click(object sender, EventArgs e)
        {
            int btn = Convert.ToInt16(((Control)sender).Tag);
            var openFileDialog = new OpenFileDialog()
            {
                InitialDirectory = app.mainVar.musicFolder,
                Filter = "MP3|*.mp3|WAV|*.wav",
                FilterIndex = 0,
                Multiselect = false
            };
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                app.mainVar.MusicFile[btn]=openFileDialog.FileName;
                initMusicsName(Btn_Musics);
                app.mainDataSave();
            }
        }

        private void initMusicsName(Button[] btn)
        {
            for (int i = 0; i < btn.Length; i++)
            {
                btn[i].Text = app.mainVar.getName(i);
            }
        }

        private void initNcoText(Button[] btn)
        {
            for (int i = 0; i < btn.Length; i++)
            {
                btn[i].Text = app.NcoSite.NCO[i].Name;
            }
        }
        private void CallBtns_Click(object sender, EventArgs e)
        {
            if(sender != null)
                selectCall = Convert.ToInt16(((Control)sender).Tag) - 1;

            for (int i = 0; i < CallBtns.Length; i++)
            {
                if (selectCall == i)
                    CallBtns[i].BackColor = Color.Lime;
                else
                    CallBtns[i].BackColor = Color.White;
                CallBtns[i].Text = app.defCalls[i].Name;
            }
            tb_Name.Text = app.defCalls[selectCall].Name;
            tb_Priority.Text = app.defCalls[selectCall].Priority;
            tb_StartChime.Text = app.defCalls[selectCall].StartChime;
            tb_Messages.Text = app.defCalls[selectCall].Message;
            tb_EndChime.Text = app.defCalls[selectCall].EndChime;
            tb_RepeatCnt.Text = app.defCalls[selectCall].Repeat;
            tb_color.BackColor = app.defCalls[selectCall].cl;
        }

        private void btn_callCancel_Click(object sender, EventArgs e)
        {
            app.CallDataLoad();
            CallBtns_Click(null, null);
        }
        int seletEditBGM = 0,selectCall=0;
        private void BGMnames_Click(object sender, EventArgs e)
        {
            seletEditBGM = Convert.ToInt16(((Control)sender).Tag) - 1;
            txt_BGMname.Text = app.defBGMs[seletEditBGM].Name;
            gr_BGMname.Visible = true;
        }

        private void BGMColors_Click(object sender, EventArgs e)
        {
            int btn = Convert.ToInt16(((Control)sender).Tag) - 1;
            DialogResult dr = this.clrdlg_chk.ShowDialog();         //clrdlg_chk(colordialog) 창을 팝업
            if (dr == DialogResult.OK)                              //OK 버튼이 눌리면                    
            {
                BGMColors[btn].BackColor = this.clrdlg_chk.Color;        //버튼136 배경을 선택한 색상으로 변경하라
                app.defBGMs[btn].cl = this.clrdlg_chk.Color;
            }
        }
        private void tb_color_Click(object sender, EventArgs e)
        {
            DialogResult dr = this.clrdlg_chk.ShowDialog();         //clrdlg_chk(colordialog) 창을 팝업
            if (dr == DialogResult.OK)                              //OK 버튼이 눌리면                    
            {
                tb_color.BackColor = this.clrdlg_chk.Color;        //버튼136 배경을 선택한 색상으로 변경하라
                app.defCalls[selectCall].cl = this.clrdlg_chk.Color;
            }
        }
        private void btn_change_Click(object sender, EventArgs e)
        {
            app.defBGMs[seletEditBGM].Name = txt_BGMname.Text;
            gr_BGMname.Visible = false;
            for (int i = 0; i < BGMColors.Length; i++)
            {
                BGMnames[i].Text = app.defBGMs[i].Name;
            }
        }

        private void upDateBGM()
        {
            for (int i = 0; i < BGMColors.Length; i++)
            {
                BGMColors[i].BackColor = app.defBGMs[i].cl;
                BGMnames[i].Text = app.defBGMs[i].Name;
                BGMncos[i].Text = app.defBGMs[i].NCObgm;
            }
        }

        private void initTag(Button[] btn)
        {
            for(int i=0;i<btn.Length;i++)
            {
                btn[i].Tag = i + 1;
            }
        }

        private void initText(Button[] btn, string[] name)
        {
            for (int i = 0; i < btn.Length; i++)
            {
                btn[i].Text = name[i];
            }
        }
        private void setNco_Color()
        {
            for (int i = 0; i < BtnNco.Length; i++)
            {
                if (i == select_nco)
                    BtnNco[i].BackColor = Color.Lime;
                else
                    BtnNco[i].BackColor = Color.White;
            }
        }

        private void setZone_Color()
        {
            txt_GroupName.Text = app.NcoSite.ZoneTitle[select_zone];
            FormZone.setTitle(txt_GroupName.Text);

            for (int i = 0; i < Zone.Length; i++)
            {
                Zone[i].Text = app.NcoSite.ZoneTitle[i];
                if (select_zone == i)
                    Zone[i].BackColor = Color.Lime;
                else
                    Zone[i].BackColor = Color.White;
            }
        }
        frmZone FormZone;
        int select_nco = 0;
        int select_zone = 0;
        private void btn_nco1_Click(object sender, EventArgs e)
        {
            if(sender!=null)
                select_nco = Convert.ToInt16(((Control)sender).Tag)-1;
            txt_NCO_Name.Text = app.NcoSite.NCO[select_nco].Name;
            txt_NCO_IP.Text = app.NcoSite.NCO[select_nco].ip;
            txt_NCO_ID.Text = app.NcoSite.NCO[select_nco].ID;
            txt_NCO_Password.Text = app.NcoSite.NCO[select_nco].password;
            setNco_Color();
        }


        int setNCO_no = 0;
        private void sBtn_NCOs_Color()
        {
            for (int i = 0; i < sBtn_ncos.Length; i++)
            {
                if (i == setNCO_no)
                    sBtn_ncos[i].BackColor = Color.Lime;
                else
                    sBtn_ncos[i].BackColor = Color.White;
            }
        }

        private void sBtn_NCOs_Click(object sender, EventArgs e)
        {
            if (sender != null)
                setNCO_no = Convert.ToInt16(((Control)sender).Tag) - 1;
            txt_bgms.Text = "";
            txt_Messages.Text = "";

            txt_bgms.Text = string.Join(Environment.NewLine, app.BGMlist[setNCO_no]);
            txt_Messages.Text = string.Join(Environment.NewLine, app.Messagelist[setNCO_no]);
            sBtn_NCOs_Color();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            FormZone.AddGroup();
        }

        private void btn_erase_Click(object sender, EventArgs e)
        {
            FormZone.EaseGrup();
        }

        private void btn_callSave_Click(object sender, EventArgs e)
        {

            app.defCalls[selectCall].Name = tb_Name.Text;
            app.defCalls[selectCall].Priority = tb_Priority.Text;
            app.defCalls[selectCall].StartChime = tb_StartChime.Text;
            app.defCalls[selectCall].Message = tb_Messages.Text;
            app.defCalls[selectCall].EndChime = tb_EndChime.Text;
            app.defCalls[selectCall].Repeat = tb_RepeatCnt.Text;
            app.defCalls[selectCall].cl = tb_color.BackColor;
            app.CallDataSave();

        }

        Button[] btnNetCheck = new Button[100];
        private void buttonCreate_Net()
        {
            CreateBtn buttonPos;
            buttonPos = new CreateBtn(199, 49, 10, 10);
            buttonPos.ArrayX = 1;
            buttonPos.GapX = 5;
            buttonPos.GapY = 5;
            for (int i = 0; i < btnNetCheck.Length; i++)
            {
                btnNetCheck[i] = new Button();
                Button btn = btnNetCheck[i];
                panel_net.Controls.Add(btn);
                buttonPos.Cul_pos(i + 1);
                btn.Size = new Size(buttonPos.Width, buttonPos.Height);
                btn.ForeColor = Color.Black;
                btn.BackColor = Color.White;
                btn.Text = i.ToString();
                btn.Tag = i;
                btn.MouseDown += btnNet_MouseDown;
                btn.Location = new Point(buttonPos.PosX, buttonPos.PosY);
                btn.Visible = false;
            }
        }

        private void UpdateNetBtn()
        {
            txt_PingTime.Text = app.netDevice.PingTime.ToString();
            for(int i=0;i< btnNetCheck.Length;i++)
            {
                if(i< app.netDevice.Name.Count)
                {
                    btnNetCheck[i].Visible = true;
                    btnNetCheck[i].Text = app.netDevice.Name[i];
                }
                else
                    btnNetCheck[i].Visible = false;
            }

        }
        int sel_NetBtn;
        private void btnNet_MouseDown(object sender, MouseEventArgs e)
        {

            sel_NetBtn = Convert.ToInt16(((Control)sender).Tag);
            txt_devIP.Text = app.netDevice.IPaddr[sel_NetBtn];
            txt_DevName.Text = app.netDevice.Name[sel_NetBtn];

            ContextMenu m = new ContextMenu(); //메뉴에 들어갈 아이템을 만듭니다
            MenuItem[] sub = new MenuItem[2];
            for (int i = 0; i < 2; i++)
            {
                sub[i] = new MenuItem();
                sub[i].Tag = i + 1;
                sub[i].Click += btnDelMenu_Click;
            }
            sub[0].Text = "삭제";
            sub[1].Text = "나기기";
            m.MenuItems.Add(sub[0]);
            m.MenuItems.Add(sub[1]);
            m.Show((Control)sender, new Point(e.X, e.Y + 20));//현재 마우스가 위치한 장소에 메뉴를 띄워줍니다  
        }

        private void btnDelMenu_Click(object sender, EventArgs e)
        {
            int btn = Convert.ToInt16(((MenuItem)sender).Tag);
            if (btn == 1)
            {
                app.netDevice.Remove(sel_NetBtn);
                app.NetDevSave();
                UpdateNetBtn();
            }
        }

        private void btn_addNet_Click(object sender, EventArgs e)
        {
            app.netDevice.AddData(txt_devIP.Text, txt_DevName.Text);
            app.NetDevSave();
            UpdateNetBtn();
        }

        private void txt_PingTime_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void setting_tab_SelectedIndexChanged(object sender, EventArgs e)
        {
            setNCO_no = 0;
            sBtn_NCOs_Click(null, null);
            app.CallDataLoad();
            app.BGMDataLoad();
        }

        private void btn_zone1_Click(object sender, EventArgs e)
        {
            if (sender != null)
                select_zone = Convert.ToInt16(((Control)sender).Tag) - 1;

            FormZone.LoadData(select_zone);
            setZone_Color();
        }

        private void BGM_save_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < BGMColors.Length; i++)
            {
                app.defBGMs[i].NCObgm = BGMncos[i].Text;
            }
            app.BGMDataSave();
        }



        private void btnSaveCancle_Click(object sender, EventArgs e)
        {
            app.NCO_DataLoad();
        }

        private void btnSaveZone_Click(object sender, EventArgs e)
        {
            app.NcoSite.ZoneTitle[select_zone] = txt_GroupName.Text;
            app.NCO_DataSave();
        }

        private void btn_setNco_Click(object sender, EventArgs e)
        {
            app.NcoSite.NCO[select_nco].Name =txt_NCO_Name.Text;
            app.NcoSite.NCO[select_nco].ip = txt_NCO_IP.Text;
            app.NcoSite.NCO[select_nco].ID = txt_NCO_ID.Text;
            app.NcoSite.NCO[select_nco].password = txt_NCO_Password.Text;
            app.NCO_DataSave();
            initNcoText(BtnNco);
            initNcoText(sBtn_ncos);
        }
    }
}
