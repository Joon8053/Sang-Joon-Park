﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NCO_App
{
    public class clsMonthScadule
    {
        public int Day = 0;
        public bool[] EnWeek = new bool[7];
        public string Name;
        public bool Auto;
        public int startTime = 0;
        public int endTime = 0;
        public List<string> MusicFile = new List<string>();
        public int input;
        public List<bool[]> Zone = new List<bool[]>();


        public string getMusicFile()
        {
            string ss = "-";
            if (MusicFile.Count > 0)
            {
                ss = Path.GetFileNameWithoutExtension(MusicFile[0]);
                if (MusicFile.Count > 1) 
                    ss = string.Format("{0}({1})",ss,MusicFile.Count-1);
            }
            return ss;
        }

        public string[] getMusicList()
        {
            List<string> mList = new List<string>();
            foreach(string s in MusicFile)
            {
                mList.Add(Path.GetFileNameWithoutExtension(s));
            }
            return mList.ToArray();
        }
        public string getStartTime()
        {
            return ConvertSecondsToTimeFormat(startTime);
        }
        public string getEndtTime()
        {
            return ConvertSecondsToTimeFormat(endTime);
        }
        public void setStartTime(string sTime)
        {
            string[] mTime = convTime(sTime);
            if ((mTime != null) && (mTime.Length > 2))
                startTime = ConvertTimeToSeconds(mTime);
        }

        public void setEndTime(string sTime)
        {
            string[] mTime = convTime(sTime);
            if ((mTime != null) && (mTime.Length > 2))
                endTime = ConvertTimeToSeconds(mTime);
        }
        private string ConvertSecondsToTimeFormat(int seconds)
        {
            // 시, 분, 초 값 계산
            int hour = seconds / 3600;
            int minute = (seconds % 3600) / 60;
            int second = (seconds % 3600) % 60;

            // 시간 정보 문자열 반환
            return $"{hour:00}:{minute:00}:{second:00}";
        }
        private string[] convTime(string sTime)
        {
            string[] aTime;
            if (sTime.Contains(":"))
            {
                aTime = sTime.Split(':');
            }
            else if (sTime.Contains("-"))
            {
                aTime = sTime.Split('-');
            }
            else
            {
                return null;  // fail
            }
            return aTime;
        }

        private int ConvertTimeToSeconds(string[] sTime)
        {
            // 시간을 초로 변환
            int timeInSeconds = Convert.ToInt32(sTime[0]) * 3600;

            // 분을 초로 변환하여 초에 더함
            timeInSeconds += Convert.ToInt32(sTime[1]) * 60;

            // 초를 더해서 전체 초 값을 반환
            timeInSeconds += Convert.ToInt32(sTime[2]);

            return timeInSeconds;
        }
    }
}
