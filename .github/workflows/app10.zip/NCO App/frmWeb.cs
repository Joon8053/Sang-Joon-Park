﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NCO_App
{
    public partial class frmWeb : Form
    {
        string uri;
        public frmWeb(string addr)
        {
            InitializeComponent();
            uri = addr;
        }

        private void frmWeb_Load(object sender, EventArgs e)
        {
            webBrowser1.ScriptErrorsSuppressed = true;
            webBrowser1.Navigate(uri);
        }

        private void WebBrowser1_NewWindow(object sender, CancelEventArgs e)
        {
            e.Cancel = true; // 현재 창에서 새로운 창을 열지 않음
            WebBrowser webBrowser = sender as WebBrowser;
            if (webBrowser != null)
            {
                // url 새로 띄워주기
                webBrowser.Navigate(webBrowser.StatusText);
            }
        }
    }
}
