﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RHBform;

namespace Schedule_Application
{
    public partial class frmMain : Form
    {

        #region FormBoder
        private void customBackgroundPainter(PaintEventArgs e, int linethickness = 2, Color linecolor = new Color(), int offsetborder = 6)
        {
            Rectangle rect = new Rectangle(offsetborder, offsetborder, this.ClientSize.Width - (offsetborder * 2), this.ClientSize.Height - (offsetborder * 2));

            Pen pen = new Pen(new Color());
            pen.Width = linethickness;
            if (linecolor != new Color())
            {
                pen.Color = linecolor;
            }
            else
            {
                pen.Color = Color.Black;
            }

            e.Graphics.DrawRectangle(pen, rect);
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            Color cl = Color.FromArgb(100, 100, 100);
            base.OnPaintBackground(e);
            customBackgroundPainter(
            e,
            linethickness: 1,
            linecolor: cl,
            offsetborder: 1
            );
        }
        #endregion

        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            this.Location = new Point(0, 0);
            fromBase frm = new fromBase(this, panel_head, btn_close, btn_mini, label_t);  //new fromBase(this, panel_head, btn_close, label_t);
            frm.ObjectAdd(label_dis2);
            frm.ObjectAdd(dis_sc);
            frm.ObjectAdd(dis_time);
            FormMonitering = new frmMonitering(this);
            FormSchedule = new frmSchedule(this);
            FormDeviceAdd = new frmDeviceADD(this);
            FormAdd(FormSchedule, panel_base);
            FormAdd(FormDeviceAdd, panel_base);
            FormAdd(FormMonitering, panel_base);
            sMenu(1);
        }


        private void FormAdd(Form frm, Panel pBase)
        {
            frm.TopLevel = false;
            frm.TopMost = true;
            frm.Parent = this;
            pBase.Controls.Add(frm);
            frm.Show();
        }


        frmMonitering FormMonitering;
        frmSchedule FormSchedule;
        frmDeviceADD FormDeviceAdd;

        private void btn_menu1_Click(object sender, EventArgs e)
        {
            int no = Convert.ToInt16(((Control)sender).Tag);
            sMenu(no);
        }
        private void sMenu(int no)
        {
            btn_menu1.setON = false;
            btn_menu2.setON = false;
            btn_menu3.setON = false;
            if (no == 1)
            {
                FormSchedule.BringToFront();
                btn_menu1.setON = true;
            }
            else if (no == 2)
            {
                FormMonitering.BringToFront();
                btn_menu2.setON = true;
            }
            else if (no == 3)
            {
                FormDeviceAdd.BringToFront();
                btn_menu3.setON = true;
            }
        }

        bool flg_admin = false;
        public bool en_schedule = true;
        private void btn_admin_Click(object sender, EventArgs e)
        {
            flg_admin = !flg_admin;
            en_schedule = !flg_admin;
            btn_menu3.Visible = flg_admin;
            btn_admin.setON = flg_admin;
            if(flg_admin==false)
            {
                sMenu(1);
            }
            label_dis2.Visible = en_schedule;
            dis_time.Visible = en_schedule;
            dis_sc.Visible = en_schedule;
            FormSchedule.SetAdmin(!en_schedule);
        }
    }
}
