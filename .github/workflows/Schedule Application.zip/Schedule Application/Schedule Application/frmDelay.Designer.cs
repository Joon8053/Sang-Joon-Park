﻿namespace Schedule_Application
{
    partial class frmDelay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.led_sync = new System.Windows.Forms.Button();
            this.btn_close = new System.Windows.Forms.Button();
            this.label_t = new System.Windows.Forms.Label();
            this.btn_save = new System.Windows.Forms.Button();
            this.panel_head = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_Sec = new System.Windows.Forms.TextBox();
            this.textBox_rep = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_pc = new System.Windows.Forms.TextBox();
            this.panel_head.SuspendLayout();
            this.SuspendLayout();
            // 
            // led_sync
            // 
            this.led_sync.BackColor = System.Drawing.Color.Lime;
            this.led_sync.Enabled = false;
            this.led_sync.ForeColor = System.Drawing.Color.White;
            this.led_sync.Location = new System.Drawing.Point(5, 7);
            this.led_sync.Name = "led_sync";
            this.led_sync.Size = new System.Drawing.Size(31, 25);
            this.led_sync.TabIndex = 464;
            this.led_sync.UseVisualStyleBackColor = false;
            // 
            // btn_close
            // 
            this.btn_close.BackColor = System.Drawing.Color.Black;
            this.btn_close.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btn_close.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.btn_close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_close.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_close.ForeColor = System.Drawing.Color.White;
            this.btn_close.Location = new System.Drawing.Point(311, 7);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(44, 27);
            this.btn_close.TabIndex = 463;
            this.btn_close.Text = "X";
            this.btn_close.UseVisualStyleBackColor = false;
            // 
            // label_t
            // 
            this.label_t.AutoSize = true;
            this.label_t.Location = new System.Drawing.Point(45, 14);
            this.label_t.Name = "label_t";
            this.label_t.Size = new System.Drawing.Size(85, 12);
            this.label_t.TabIndex = 2;
            this.label_t.Text = "전원 반복 설정";
            // 
            // btn_save
            // 
            this.btn_save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btn_save.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_save.ForeColor = System.Drawing.Color.Black;
            this.btn_save.Location = new System.Drawing.Point(311, 58);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(46, 69);
            this.btn_save.TabIndex = 58;
            this.btn_save.Text = "저장 닫기";
            this.btn_save.UseVisualStyleBackColor = false;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // panel_head
            // 
            this.panel_head.BackColor = System.Drawing.Color.Black;
            this.panel_head.Controls.Add(this.led_sync);
            this.panel_head.Controls.Add(this.btn_close);
            this.panel_head.Controls.Add(this.label_t);
            this.panel_head.Location = new System.Drawing.Point(2, 4);
            this.panel_head.Name = "panel_head";
            this.panel_head.Size = new System.Drawing.Size(367, 40);
            this.panel_head.TabIndex = 56;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Yellow;
            this.label5.Location = new System.Drawing.Point(18, 108);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(274, 36);
            this.label5.TabIndex = 44;
            this.label5.Text = "동작시 상단에 잔여 횟수 표시됨\r\n\r\nPC 시간은 디스플레이가 꺼진후 지연 시간 입니다";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(97, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 12);
            this.label2.TabIndex = 3;
            this.label2.Text = "반복 주기(초)";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "반복 횟수";
            // 
            // textBox_Sec
            // 
            this.textBox_Sec.Location = new System.Drawing.Point(99, 72);
            this.textBox_Sec.Name = "textBox_Sec";
            this.textBox_Sec.Size = new System.Drawing.Size(77, 21);
            this.textBox_Sec.TabIndex = 60;
            this.textBox_Sec.Text = "5";
            this.textBox_Sec.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_rep_KeyPress);
            // 
            // textBox_rep
            // 
            this.textBox_rep.Location = new System.Drawing.Point(20, 72);
            this.textBox_rep.Name = "textBox_rep";
            this.textBox_rep.Size = new System.Drawing.Size(73, 21);
            this.textBox_rep.TabIndex = 59;
            this.textBox_rep.Text = "5";
            this.textBox_rep.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_rep_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(185, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 12);
            this.label3.TabIndex = 61;
            this.label3.Text = "PC (꺼짐 시간 초)";
            // 
            // textBox_pc
            // 
            this.textBox_pc.Location = new System.Drawing.Point(187, 72);
            this.textBox_pc.Name = "textBox_pc";
            this.textBox_pc.Size = new System.Drawing.Size(102, 21);
            this.textBox_pc.TabIndex = 62;
            this.textBox_pc.Text = "5";
            this.textBox_pc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_rep_KeyPress);
            // 
            // frmDelay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.ClientSize = new System.Drawing.Size(366, 152);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox_pc);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox_Sec);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox_rep);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.panel_head);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmDelay";
            this.Text = "frmDelay";
            this.Load += new System.EventHandler(this.frmDelay_Load);
            this.panel_head.ResumeLayout(false);
            this.panel_head.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button led_sync;
        private System.Windows.Forms.Button btn_close;
        private System.Windows.Forms.Label label_t;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Panel panel_head;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_Sec;
        private System.Windows.Forms.TextBox textBox_rep;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_pc;
    }
}