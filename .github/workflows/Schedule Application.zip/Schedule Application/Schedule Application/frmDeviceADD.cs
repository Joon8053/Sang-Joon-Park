﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Schedule_Application
{
    public partial class frmDeviceADD : Form
    {

        frmMain app;

        public frmDeviceADD(frmMain main)
        {
            InitializeComponent();
            app = main;
        }
        TreeNode DefNode;


        private string make(string sum)
        {
            string[] aStr = sum.Split(',');
            string ss="";
            int[] strLen = { 10, 15, 20, 20 };
           // ss += string.Format("{0,-15}", aStr[0]);//  aStr[0].PadRight(15, ' ');
          //  ss += aStr[2].PadRight(20, ' ');
          //  ss += aStr[3].PadRight(20, ' ');

            for(int i=0;i<aStr.Length;i++) //   foreach (string s in aStr)
            {
                ss += aStr[i].PadRight(strLen[i], ' ');
            }

            return ss;
        }
        private void frmDeviceADD_Load(object sender, EventArgs e)
        {

            TreeNode DefNode = new TreeNode("미분류", 0, 0);

            DefNode.Nodes.Add(make("Power,PC,192.168.0.1,00-00-00-00-00-00"));
            DefNode.Nodes.Add(make("Player,Madmapper,192.168.0.1,00-00-00-00-00-00"));
            treeView1.Nodes.Add(DefNode);
            treeView1.ExpandAll();
        }

        private void textBox_rep_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_AddPowerDevice1_Click(object sender, EventArgs e)
        {
            int no = Convert.ToInt16(((Control)sender).Tag);
            if(no==1)
            {
                frmPJlinkAdd dlg = new frmPJlinkAdd();

                dlg.ShowDialog();
            }
            else if (no == 2)
            {
                frmAddPJlinkNone dlg = new frmAddPJlinkNone();
                dlg.onAdd += Dlg_onAdd;
                dlg.ShowDialog();
            }
            else if (no == 4)
            {
                frmPCadd dlg = new frmPCadd();

                dlg.ShowDialog();
            }
        }

        private void Dlg_onAdd(RHBLibrary.schedule.clsScheduleDevice.DEVICE obj)
        {
            throw new NotImplementedException();
        }

        private void btn_AddRoom_Click(object sender, EventArgs e)
        {
            frmRoomAdd dlg = new frmRoomAdd();
            dlg.ShowDialog();
        }

        private void btn_AddEtcDevice1_Click(object sender, EventArgs e)
        {
            int no = Convert.ToInt16(((Control)sender).Tag);
            if (no == 1)
            {
                frmMadmapper dlg = new frmMadmapper();

                dlg.ShowDialog();
            }
        }

        private void btn_onoff_Click(object sender, EventArgs e)
        {
            frmDelay dlg = new frmDelay();
            dlg.ShowDialog();
        }
    }
}
