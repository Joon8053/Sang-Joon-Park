﻿namespace Schedule_Application
{
    partial class frmAddPJlinkNone
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.textBox_name = new System.Windows.Forms.TextBox();
            this.timer_check = new System.Windows.Forms.Timer(this.components);
            this.label10 = new System.Windows.Forms.Label();
            this.textBox_port = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox_rcv = new System.Windows.Forms.TextBox();
            this.st_rcv = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.st_lamp = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.st_input = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.st_power = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboBox_location = new System.Windows.Forms.ComboBox();
            this.btn_save = new System.Windows.Forms.Button();
            this.btn_ask = new System.Windows.Forms.Button();
            this.btn_close = new System.Windows.Forms.Button();
            this.led_sync = new System.Windows.Forms.Button();
            this.label_t = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel_head = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_ip = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.panel_head.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox_name
            // 
            this.textBox_name.Location = new System.Drawing.Point(15, 163);
            this.textBox_name.Name = "textBox_name";
            this.textBox_name.Size = new System.Drawing.Size(282, 21);
            this.textBox_name.TabIndex = 35;
            this.textBox_name.Text = "프로젝터";
            // 
            // timer_check
            // 
            this.timer_check.Interval = 1000;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(306, 50);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(131, 12);
            this.label10.TabIndex = 34;
            this.label10.Text = "네트웍 포트(기본 4352)";
            // 
            // textBox_port
            // 
            this.textBox_port.Location = new System.Drawing.Point(308, 65);
            this.textBox_port.Name = "textBox_port";
            this.textBox_port.Size = new System.Drawing.Size(220, 21);
            this.textBox_port.TabIndex = 33;
            this.textBox_port.Text = "4352";
            this.textBox_port.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_port_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(13, 323);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(69, 12);
            this.label9.TabIndex = 32;
            this.label9.Text = "수신 데이터";
            // 
            // textBox_rcv
            // 
            this.textBox_rcv.BackColor = System.Drawing.Color.Black;
            this.textBox_rcv.ForeColor = System.Drawing.Color.White;
            this.textBox_rcv.Location = new System.Drawing.Point(15, 339);
            this.textBox_rcv.Multiline = true;
            this.textBox_rcv.Name = "textBox_rcv";
            this.textBox_rcv.Size = new System.Drawing.Size(513, 154);
            this.textBox_rcv.TabIndex = 31;
            // 
            // st_rcv
            // 
            this.st_rcv.BackColor = System.Drawing.Color.Transparent;
            this.st_rcv.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.st_rcv.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.st_rcv.ForeColor = System.Drawing.Color.White;
            this.st_rcv.Location = new System.Drawing.Point(265, 88);
            this.st_rcv.Name = "st_rcv";
            this.st_rcv.Size = new System.Drawing.Size(214, 22);
            this.st_rcv.TabIndex = 13;
            this.st_rcv.Text = "정상 수신";
            this.st_rcv.UseVisualStyleBackColor = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(263, 26);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(57, 12);
            this.label8.TabIndex = 12;
            this.label8.Text = "램프 시간";
            // 
            // st_lamp
            // 
            this.st_lamp.Location = new System.Drawing.Point(265, 41);
            this.st_lamp.Name = "st_lamp";
            this.st_lamp.Size = new System.Drawing.Size(215, 21);
            this.st_lamp.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(24, 75);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 12);
            this.label7.TabIndex = 10;
            this.label7.Text = "입력 소스";
            // 
            // st_input
            // 
            this.st_input.Location = new System.Drawing.Point(26, 89);
            this.st_input.Name = "st_input";
            this.st_input.Size = new System.Drawing.Size(215, 21);
            this.st_input.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(24, 26);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 12);
            this.label6.TabIndex = 8;
            this.label6.Text = "전원 상태";
            // 
            // st_power
            // 
            this.st_power.Location = new System.Drawing.Point(26, 41);
            this.st_power.Name = "st_power";
            this.st_power.Size = new System.Drawing.Size(215, 21);
            this.st_power.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 145);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(155, 12);
            this.label2.TabIndex = 36;
            this.label2.Text = "장비 이름(스케쥴에서 사용)";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.st_rcv);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.st_lamp);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.st_input);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.st_power);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(15, 193);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(513, 127);
            this.groupBox1.TabIndex = 30;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = " 장비 정보 수신 (접속 상태 점검) ";
            // 
            // comboBox_location
            // 
            this.comboBox_location.FormattingEnabled = true;
            this.comboBox_location.Items.AddRange(new object[] {
            "1.전체",
            "2.?? 전시실"});
            this.comboBox_location.Location = new System.Drawing.Point(15, 65);
            this.comboBox_location.Name = "comboBox_location";
            this.comboBox_location.Size = new System.Drawing.Size(282, 20);
            this.comboBox_location.TabIndex = 28;
            // 
            // btn_save
            // 
            this.btn_save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btn_save.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_save.ForeColor = System.Drawing.Color.Black;
            this.btn_save.Location = new System.Drawing.Point(423, 149);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(104, 34);
            this.btn_save.TabIndex = 27;
            this.btn_save.Text = "장비 추가";
            this.btn_save.UseVisualStyleBackColor = false;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // btn_ask
            // 
            this.btn_ask.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_ask.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ask.Location = new System.Drawing.Point(309, 149);
            this.btn_ask.Name = "btn_ask";
            this.btn_ask.Size = new System.Drawing.Size(104, 34);
            this.btn_ask.TabIndex = 26;
            this.btn_ask.Text = "상태 요청";
            this.btn_ask.UseVisualStyleBackColor = true;
            this.btn_ask.Click += new System.EventHandler(this.btn_ask_Click);
            // 
            // btn_close
            // 
            this.btn_close.BackColor = System.Drawing.Color.Black;
            this.btn_close.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btn_close.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.btn_close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_close.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_close.ForeColor = System.Drawing.Color.White;
            this.btn_close.Location = new System.Drawing.Point(490, 6);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(44, 27);
            this.btn_close.TabIndex = 463;
            this.btn_close.Text = "X";
            this.btn_close.UseVisualStyleBackColor = false;
            // 
            // led_sync
            // 
            this.led_sync.BackColor = System.Drawing.Color.Lime;
            this.led_sync.Enabled = false;
            this.led_sync.ForeColor = System.Drawing.Color.White;
            this.led_sync.Location = new System.Drawing.Point(5, 7);
            this.led_sync.Name = "led_sync";
            this.led_sync.Size = new System.Drawing.Size(31, 25);
            this.led_sync.TabIndex = 3;
            this.led_sync.UseVisualStyleBackColor = false;
            // 
            // label_t
            // 
            this.label_t.AutoSize = true;
            this.label_t.Location = new System.Drawing.Point(45, 14);
            this.label_t.Name = "label_t";
            this.label_t.Size = new System.Drawing.Size(208, 12);
            this.label_t.TabIndex = 2;
            this.label_t.Text = "PJlink 프로젝터 등록 (패스워드 없슴)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 50);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(147, 12);
            this.label5.TabIndex = 29;
            this.label5.Text = "그룹 선택 (기본은 미분류)";
            // 
            // panel_head
            // 
            this.panel_head.BackColor = System.Drawing.Color.Black;
            this.panel_head.Controls.Add(this.btn_close);
            this.panel_head.Controls.Add(this.led_sync);
            this.panel_head.Controls.Add(this.label_t);
            this.panel_head.Location = new System.Drawing.Point(1, 1);
            this.panel_head.Name = "panel_head";
            this.panel_head.Size = new System.Drawing.Size(542, 40);
            this.panel_head.TabIndex = 21;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 12);
            this.label1.TabIndex = 20;
            this.label1.Text = "IP Address";
            // 
            // textBox_ip
            // 
            this.textBox_ip.Location = new System.Drawing.Point(15, 112);
            this.textBox_ip.Name = "textBox_ip";
            this.textBox_ip.Size = new System.Drawing.Size(282, 21);
            this.textBox_ip.TabIndex = 19;
            this.textBox_ip.Text = "127.0.0.1";
            // 
            // frmAddPJlinkNone
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.ClientSize = new System.Drawing.Size(542, 502);
            this.Controls.Add(this.textBox_name);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.textBox_port);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBox_rcv);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.comboBox_location);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.btn_ask);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.panel_head);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox_ip);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmAddPJlinkNone";
            this.Text = "frmAddPJlinkNone";
            this.Load += new System.EventHandler(this.frmAddPJlinkNone_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel_head.ResumeLayout(false);
            this.panel_head.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_name;
        private System.Windows.Forms.Timer timer_check;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox_port;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox_rcv;
        private System.Windows.Forms.Button st_rcv;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox st_lamp;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox st_input;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox st_power;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox comboBox_location;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Button btn_ask;
        private System.Windows.Forms.Button btn_close;
        private System.Windows.Forms.Button led_sync;
        private System.Windows.Forms.Label label_t;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel_head;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_ip;
    }
}