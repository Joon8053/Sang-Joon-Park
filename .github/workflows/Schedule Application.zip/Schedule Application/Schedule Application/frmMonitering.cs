﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Schedule_Application
{
    public partial class frmMonitering : Form
    {

        frmMain app;

        public frmMonitering(frmMain main)
        {
            InitializeComponent();
            app = main;
        }

        private void frmMonitering_Load(object sender, EventArgs e)
        {

        }
    }
}
