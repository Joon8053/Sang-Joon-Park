﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RHBform;
using RHBLibrary.Projector;
using RHBLibrary.schedule;

namespace Schedule_Application
{
    public partial class frmPJlinkAdd : Form
    {

        #region FormBoder
        private void customBackgroundPainter(PaintEventArgs e, int linethickness = 2, Color linecolor = new Color(), int offsetborder = 6)
        {
            Rectangle rect = new Rectangle(offsetborder, offsetborder, this.ClientSize.Width - (offsetborder * 2), this.ClientSize.Height - (offsetborder * 2));

            Pen pen = new Pen(new Color());
            pen.Width = linethickness;
            if (linecolor != new Color())
            {
                pen.Color = linecolor;
            }
            else
            {
                pen.Color = Color.Black;
            }

            e.Graphics.DrawRectangle(pen, rect);
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            Color cl = Color.FromArgb(100,100,100);
            base.OnPaintBackground(e);
            customBackgroundPainter(
            e,
            linethickness: 1,
            linecolor: cl,
            offsetborder: 1
            ) ;
        }
        #endregion

        public frmPJlinkAdd()
        {
            InitializeComponent();
        }

        clsScheduleRoom mRoom;


        private void Form1_Load(object sender, EventArgs e)
        {
            fromBase frm = new fromBase(this, panel_head, btn_close, label_t);
            panel_head.Size = new Size(this.Width - 4, panel_head.Height);
            panel_head.Location = new Point(2, 2);
            System.Timers.Timer SyncTimer = new System.Timers.Timer();
            SyncTimer.Interval = 1000;
            SyncTimer.Elapsed += SyncTimer_Elapsed;
            SyncTimer.Enabled = true;
            mRoom = new clsScheduleRoom();
            comboBox_location.Items.Clear();
            foreach (string ss in mRoom.mData.room)
            { 
                comboBox_location.Items.Add(ss);
            }
        }

        private void SyncTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (led_sync.BackColor == Color.Red)
                led_sync.BackColor = Color.Lime;
            else
                led_sync.BackColor = Color.Red;
        }

        clsPJlink_None testPJ;
        private void btn_ask_Click(object sender, EventArgs e)
        {

            textBox_rcv.Text = "";
            loop_cnt = 0;
            testPJ = new clsPJlink_None(textBox_ip.Text,Convert.ToInt16(textBox_port.Text), 0, textBox_pass.Text);
            testPJ.OnRxData += TestPJ_rxData;
            timer_check.Enabled = true;
        }

        private void TestPJ_rxData(int id,string ss)
        {
            Invoke(new Action(() =>
            {
                textBox_rcv.Text += ss + "\r\n";
            }));
        }

        int loop_cnt = 0;
        private void timer_check_Tick(object sender, EventArgs e)
        {
            if (loop_cnt == 0)
                testPJ.PowerCheck();
            else if (loop_cnt == 1)
                timer_check.Enabled = false;

            loop_cnt++;
        }




        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void st_input_TextChanged(object sender, EventArgs e)
        {

        }

        private void st_rcv_Click(object sender, EventArgs e)
        {

        }

        private void btn_save_Click(object sender, EventArgs e)
        {

        }
    }
}
