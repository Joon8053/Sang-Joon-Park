﻿namespace Schedule_Application
{
    partial class frmDeviceADD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDeviceADD));
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.rhBbutton2 = new RHBform.RHBbutton();
            this.rhBbutton1 = new RHBform.RHBbutton();
            this.rhBbutton3 = new RHBform.RHBbutton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rhBbutton12 = new RHBform.RHBbutton();
            this.rhBbutton11 = new RHBform.RHBbutton();
            this.rhBbutton10 = new RHBform.RHBbutton();
            this.rhBbutton9 = new RHBform.RHBbutton();
            this.rhBbutton8 = new RHBform.RHBbutton();
            this.rhBbutton7 = new RHBform.RHBbutton();
            this.rhBbutton6 = new RHBform.RHBbutton();
            this.rhBbutton5 = new RHBform.RHBbutton();
            this.btn_AddPowerDevice1 = new RHBform.RHBbutton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rhBbutton13 = new RHBform.RHBbutton();
            this.rhBbutton14 = new RHBform.RHBbutton();
            this.rhBbutton15 = new RHBform.RHBbutton();
            this.rhBbutton20 = new RHBform.RHBbutton();
            this.btn_AddEtcDevice1 = new RHBform.RHBbutton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btn_AddRoom = new RHBform.RHBbutton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btn_onoff = new RHBform.RHBbutton();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // treeView1
            // 
            this.treeView1.Location = new System.Drawing.Point(33, 63);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(724, 788);
            this.treeView1.TabIndex = 0;
            // 
            // rhBbutton2
            // 
            this.rhBbutton2.BackColor = System.Drawing.Color.Transparent;
            this.rhBbutton2.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.rhBbutton2.ForeColor = System.Drawing.Color.Yellow;
            this.rhBbutton2.Location = new System.Drawing.Point(33, 31);
            this.rhBbutton2.Margin = new System.Windows.Forms.Padding(8);
            this.rhBbutton2.Name = "rhBbutton2";
            this.rhBbutton2.setFontColor = System.Drawing.Color.Yellow;
            this.rhBbutton2.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton2.setOFFimage")));
            this.rhBbutton2.setON = false;
            this.rhBbutton2.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton2.setONimage")));
            this.rhBbutton2.setText = "등록된 장비";
            this.rhBbutton2.setToggle = false;
            this.rhBbutton2.Size = new System.Drawing.Size(171, 37);
            this.rhBbutton2.TabIndex = 25;
            this.rhBbutton2.TabStop = false;
            this.rhBbutton2.Tag = "1";
            this.rhBbutton2.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // rhBbutton1
            // 
            this.rhBbutton1.BackColor = System.Drawing.Color.Transparent;
            this.rhBbutton1.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.rhBbutton1.ForeColor = System.Drawing.Color.Yellow;
            this.rhBbutton1.Location = new System.Drawing.Point(933, 63);
            this.rhBbutton1.Margin = new System.Windows.Forms.Padding(8);
            this.rhBbutton1.Name = "rhBbutton1";
            this.rhBbutton1.setFontColor = System.Drawing.Color.Yellow;
            this.rhBbutton1.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton1.setOFFimage")));
            this.rhBbutton1.setON = false;
            this.rhBbutton1.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton1.setONimage")));
            this.rhBbutton1.setText = "선택된 장비 삭제";
            this.rhBbutton1.setToggle = false;
            this.rhBbutton1.Size = new System.Drawing.Size(149, 63);
            this.rhBbutton1.TabIndex = 26;
            this.rhBbutton1.TabStop = false;
            this.rhBbutton1.Tag = "1";
            this.rhBbutton1.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // rhBbutton3
            // 
            this.rhBbutton3.BackColor = System.Drawing.Color.Transparent;
            this.rhBbutton3.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.rhBbutton3.ForeColor = System.Drawing.Color.Yellow;
            this.rhBbutton3.Location = new System.Drawing.Point(779, 63);
            this.rhBbutton3.Margin = new System.Windows.Forms.Padding(8);
            this.rhBbutton3.Name = "rhBbutton3";
            this.rhBbutton3.setFontColor = System.Drawing.Color.Yellow;
            this.rhBbutton3.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton3.setOFFimage")));
            this.rhBbutton3.setON = false;
            this.rhBbutton3.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton3.setONimage")));
            this.rhBbutton3.setText = "선택된 장비 수정";
            this.rhBbutton3.setToggle = false;
            this.rhBbutton3.Size = new System.Drawing.Size(149, 63);
            this.rhBbutton3.TabIndex = 27;
            this.rhBbutton3.TabStop = false;
            this.rhBbutton3.Tag = "1";
            this.rhBbutton3.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rhBbutton12);
            this.groupBox1.Controls.Add(this.rhBbutton11);
            this.groupBox1.Controls.Add(this.rhBbutton10);
            this.groupBox1.Controls.Add(this.rhBbutton9);
            this.groupBox1.Controls.Add(this.rhBbutton8);
            this.groupBox1.Controls.Add(this.rhBbutton7);
            this.groupBox1.Controls.Add(this.rhBbutton6);
            this.groupBox1.Controls.Add(this.rhBbutton5);
            this.groupBox1.Controls.Add(this.btn_AddPowerDevice1);
            this.groupBox1.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(779, 146);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(292, 705);
            this.groupBox1.TabIndex = 28;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = " 전원 장비 등록 ";
            // 
            // rhBbutton12
            // 
            this.rhBbutton12.BackColor = System.Drawing.Color.Transparent;
            this.rhBbutton12.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.rhBbutton12.ForeColor = System.Drawing.Color.Yellow;
            this.rhBbutton12.Location = new System.Drawing.Point(29, 615);
            this.rhBbutton12.Margin = new System.Windows.Forms.Padding(8);
            this.rhBbutton12.Name = "rhBbutton12";
            this.rhBbutton12.setFontColor = System.Drawing.Color.Yellow;
            this.rhBbutton12.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton12.setOFFimage")));
            this.rhBbutton12.setON = false;
            this.rhBbutton12.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton12.setONimage")));
            this.rhBbutton12.setText = "UDP 장비";
            this.rhBbutton12.setToggle = false;
            this.rhBbutton12.Size = new System.Drawing.Size(234, 63);
            this.rhBbutton12.TabIndex = 35;
            this.rhBbutton12.TabStop = false;
            this.rhBbutton12.Tag = "9";
            this.rhBbutton12.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.rhBbutton12.Click += new System.EventHandler(this.btn_AddPowerDevice1_Click);
            // 
            // rhBbutton11
            // 
            this.rhBbutton11.BackColor = System.Drawing.Color.Transparent;
            this.rhBbutton11.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.rhBbutton11.ForeColor = System.Drawing.Color.Yellow;
            this.rhBbutton11.Location = new System.Drawing.Point(29, 543);
            this.rhBbutton11.Margin = new System.Windows.Forms.Padding(8);
            this.rhBbutton11.Name = "rhBbutton11";
            this.rhBbutton11.setFontColor = System.Drawing.Color.Yellow;
            this.rhBbutton11.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton11.setOFFimage")));
            this.rhBbutton11.setON = false;
            this.rhBbutton11.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton11.setONimage")));
            this.rhBbutton11.setText = "TCP/IP 장비";
            this.rhBbutton11.setToggle = false;
            this.rhBbutton11.Size = new System.Drawing.Size(234, 63);
            this.rhBbutton11.TabIndex = 34;
            this.rhBbutton11.TabStop = false;
            this.rhBbutton11.Tag = "8";
            this.rhBbutton11.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.rhBbutton11.Click += new System.EventHandler(this.btn_AddPowerDevice1_Click);
            // 
            // rhBbutton10
            // 
            this.rhBbutton10.BackColor = System.Drawing.Color.Transparent;
            this.rhBbutton10.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.rhBbutton10.ForeColor = System.Drawing.Color.Yellow;
            this.rhBbutton10.Location = new System.Drawing.Point(29, 471);
            this.rhBbutton10.Margin = new System.Windows.Forms.Padding(8);
            this.rhBbutton10.Name = "rhBbutton10";
            this.rhBbutton10.setFontColor = System.Drawing.Color.Yellow;
            this.rhBbutton10.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton10.setOFFimage")));
            this.rhBbutton10.setON = false;
            this.rhBbutton10.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton10.setONimage")));
            this.rhBbutton10.setText = "RS232 장비";
            this.rhBbutton10.setToggle = false;
            this.rhBbutton10.Size = new System.Drawing.Size(234, 63);
            this.rhBbutton10.TabIndex = 33;
            this.rhBbutton10.TabStop = false;
            this.rhBbutton10.Tag = "7";
            this.rhBbutton10.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.rhBbutton10.Click += new System.EventHandler(this.btn_AddPowerDevice1_Click);
            // 
            // rhBbutton9
            // 
            this.rhBbutton9.BackColor = System.Drawing.Color.Transparent;
            this.rhBbutton9.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.rhBbutton9.ForeColor = System.Drawing.Color.Yellow;
            this.rhBbutton9.Location = new System.Drawing.Point(29, 183);
            this.rhBbutton9.Margin = new System.Windows.Forms.Padding(8);
            this.rhBbutton9.Name = "rhBbutton9";
            this.rhBbutton9.setFontColor = System.Drawing.Color.Yellow;
            this.rhBbutton9.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton9.setOFFimage")));
            this.rhBbutton9.setON = false;
            this.rhBbutton9.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton9.setONimage")));
            this.rhBbutton9.setText = "프로젝터 라이브러리";
            this.rhBbutton9.setToggle = false;
            this.rhBbutton9.Size = new System.Drawing.Size(234, 63);
            this.rhBbutton9.TabIndex = 32;
            this.rhBbutton9.TabStop = false;
            this.rhBbutton9.Tag = "3";
            this.rhBbutton9.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.rhBbutton9.Click += new System.EventHandler(this.btn_AddPowerDevice1_Click);
            // 
            // rhBbutton8
            // 
            this.rhBbutton8.BackColor = System.Drawing.Color.Transparent;
            this.rhBbutton8.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.rhBbutton8.ForeColor = System.Drawing.Color.Yellow;
            this.rhBbutton8.Location = new System.Drawing.Point(29, 399);
            this.rhBbutton8.Margin = new System.Windows.Forms.Padding(8);
            this.rhBbutton8.Name = "rhBbutton8";
            this.rhBbutton8.setFontColor = System.Drawing.Color.Yellow;
            this.rhBbutton8.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton8.setOFFimage")));
            this.rhBbutton8.setON = false;
            this.rhBbutton8.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton8.setONimage")));
            this.rhBbutton8.setText = "RS232 Relay(전원)";
            this.rhBbutton8.setToggle = false;
            this.rhBbutton8.Size = new System.Drawing.Size(234, 63);
            this.rhBbutton8.TabIndex = 31;
            this.rhBbutton8.TabStop = false;
            this.rhBbutton8.Tag = "6";
            this.rhBbutton8.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.rhBbutton8.Click += new System.EventHandler(this.btn_AddPowerDevice1_Click);
            // 
            // rhBbutton7
            // 
            this.rhBbutton7.BackColor = System.Drawing.Color.Transparent;
            this.rhBbutton7.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.rhBbutton7.ForeColor = System.Drawing.Color.Yellow;
            this.rhBbutton7.Location = new System.Drawing.Point(29, 327);
            this.rhBbutton7.Margin = new System.Windows.Forms.Padding(8);
            this.rhBbutton7.Name = "rhBbutton7";
            this.rhBbutton7.setFontColor = System.Drawing.Color.Yellow;
            this.rhBbutton7.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton7.setOFFimage")));
            this.rhBbutton7.setON = false;
            this.rhBbutton7.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton7.setONimage")));
            this.rhBbutton7.setText = "리눅스 PC 등록";
            this.rhBbutton7.setToggle = false;
            this.rhBbutton7.Size = new System.Drawing.Size(234, 63);
            this.rhBbutton7.TabIndex = 30;
            this.rhBbutton7.TabStop = false;
            this.rhBbutton7.Tag = "5";
            this.rhBbutton7.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.rhBbutton7.Click += new System.EventHandler(this.btn_AddPowerDevice1_Click);
            // 
            // rhBbutton6
            // 
            this.rhBbutton6.BackColor = System.Drawing.Color.Transparent;
            this.rhBbutton6.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.rhBbutton6.ForeColor = System.Drawing.Color.Yellow;
            this.rhBbutton6.Location = new System.Drawing.Point(29, 255);
            this.rhBbutton6.Margin = new System.Windows.Forms.Padding(8);
            this.rhBbutton6.Name = "rhBbutton6";
            this.rhBbutton6.setFontColor = System.Drawing.Color.Yellow;
            this.rhBbutton6.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton6.setOFFimage")));
            this.rhBbutton6.setON = false;
            this.rhBbutton6.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton6.setONimage")));
            this.rhBbutton6.setText = "윈도우 PC 등록";
            this.rhBbutton6.setToggle = false;
            this.rhBbutton6.Size = new System.Drawing.Size(234, 63);
            this.rhBbutton6.TabIndex = 29;
            this.rhBbutton6.TabStop = false;
            this.rhBbutton6.Tag = "4";
            this.rhBbutton6.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.rhBbutton6.Click += new System.EventHandler(this.btn_AddPowerDevice1_Click);
            // 
            // rhBbutton5
            // 
            this.rhBbutton5.BackColor = System.Drawing.Color.Transparent;
            this.rhBbutton5.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.rhBbutton5.ForeColor = System.Drawing.Color.Yellow;
            this.rhBbutton5.Location = new System.Drawing.Point(29, 111);
            this.rhBbutton5.Margin = new System.Windows.Forms.Padding(8);
            this.rhBbutton5.Name = "rhBbutton5";
            this.rhBbutton5.setFontColor = System.Drawing.Color.Yellow;
            this.rhBbutton5.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton5.setOFFimage")));
            this.rhBbutton5.setON = false;
            this.rhBbutton5.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton5.setONimage")));
            this.rhBbutton5.setText = "프로젝터 PJLink(패스워드 x)";
            this.rhBbutton5.setToggle = false;
            this.rhBbutton5.Size = new System.Drawing.Size(234, 63);
            this.rhBbutton5.TabIndex = 28;
            this.rhBbutton5.TabStop = false;
            this.rhBbutton5.Tag = "2";
            this.rhBbutton5.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.rhBbutton5.Click += new System.EventHandler(this.btn_AddPowerDevice1_Click);
            // 
            // btn_AddPowerDevice1
            // 
            this.btn_AddPowerDevice1.BackColor = System.Drawing.Color.Transparent;
            this.btn_AddPowerDevice1.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_AddPowerDevice1.ForeColor = System.Drawing.Color.Yellow;
            this.btn_AddPowerDevice1.Location = new System.Drawing.Point(29, 39);
            this.btn_AddPowerDevice1.Margin = new System.Windows.Forms.Padding(8);
            this.btn_AddPowerDevice1.Name = "btn_AddPowerDevice1";
            this.btn_AddPowerDevice1.setFontColor = System.Drawing.Color.Yellow;
            this.btn_AddPowerDevice1.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_AddPowerDevice1.setOFFimage")));
            this.btn_AddPowerDevice1.setON = false;
            this.btn_AddPowerDevice1.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_AddPowerDevice1.setONimage")));
            this.btn_AddPowerDevice1.setText = "프로젝터 PJLink1";
            this.btn_AddPowerDevice1.setToggle = false;
            this.btn_AddPowerDevice1.Size = new System.Drawing.Size(234, 63);
            this.btn_AddPowerDevice1.TabIndex = 27;
            this.btn_AddPowerDevice1.TabStop = false;
            this.btn_AddPowerDevice1.Tag = "1";
            this.btn_AddPowerDevice1.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_AddPowerDevice1.Click += new System.EventHandler(this.btn_AddPowerDevice1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rhBbutton13);
            this.groupBox2.Controls.Add(this.rhBbutton14);
            this.groupBox2.Controls.Add(this.rhBbutton15);
            this.groupBox2.Controls.Add(this.rhBbutton20);
            this.groupBox2.Controls.Add(this.btn_AddEtcDevice1);
            this.groupBox2.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(1097, 146);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(292, 411);
            this.groupBox2.TabIndex = 29;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = " 플레이어외 장비 등록 ";
            // 
            // rhBbutton13
            // 
            this.rhBbutton13.BackColor = System.Drawing.Color.Transparent;
            this.rhBbutton13.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.rhBbutton13.ForeColor = System.Drawing.Color.Yellow;
            this.rhBbutton13.Location = new System.Drawing.Point(29, 327);
            this.rhBbutton13.Margin = new System.Windows.Forms.Padding(8);
            this.rhBbutton13.Name = "rhBbutton13";
            this.rhBbutton13.setFontColor = System.Drawing.Color.Yellow;
            this.rhBbutton13.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton13.setOFFimage")));
            this.rhBbutton13.setON = false;
            this.rhBbutton13.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton13.setONimage")));
            this.rhBbutton13.setText = "UDP 장비";
            this.rhBbutton13.setToggle = false;
            this.rhBbutton13.Size = new System.Drawing.Size(234, 63);
            this.rhBbutton13.TabIndex = 35;
            this.rhBbutton13.TabStop = false;
            this.rhBbutton13.Tag = "5";
            this.rhBbutton13.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.rhBbutton13.Click += new System.EventHandler(this.btn_AddEtcDevice1_Click);
            // 
            // rhBbutton14
            // 
            this.rhBbutton14.BackColor = System.Drawing.Color.Transparent;
            this.rhBbutton14.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.rhBbutton14.ForeColor = System.Drawing.Color.Yellow;
            this.rhBbutton14.Location = new System.Drawing.Point(29, 255);
            this.rhBbutton14.Margin = new System.Windows.Forms.Padding(8);
            this.rhBbutton14.Name = "rhBbutton14";
            this.rhBbutton14.setFontColor = System.Drawing.Color.Yellow;
            this.rhBbutton14.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton14.setOFFimage")));
            this.rhBbutton14.setON = false;
            this.rhBbutton14.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton14.setONimage")));
            this.rhBbutton14.setText = "TCP/IP 장비";
            this.rhBbutton14.setToggle = false;
            this.rhBbutton14.Size = new System.Drawing.Size(234, 63);
            this.rhBbutton14.TabIndex = 34;
            this.rhBbutton14.TabStop = false;
            this.rhBbutton14.Tag = "4";
            this.rhBbutton14.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.rhBbutton14.Click += new System.EventHandler(this.btn_AddEtcDevice1_Click);
            // 
            // rhBbutton15
            // 
            this.rhBbutton15.BackColor = System.Drawing.Color.Transparent;
            this.rhBbutton15.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.rhBbutton15.ForeColor = System.Drawing.Color.Yellow;
            this.rhBbutton15.Location = new System.Drawing.Point(29, 183);
            this.rhBbutton15.Margin = new System.Windows.Forms.Padding(8);
            this.rhBbutton15.Name = "rhBbutton15";
            this.rhBbutton15.setFontColor = System.Drawing.Color.Yellow;
            this.rhBbutton15.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton15.setOFFimage")));
            this.rhBbutton15.setON = false;
            this.rhBbutton15.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton15.setONimage")));
            this.rhBbutton15.setText = "RS232 장비";
            this.rhBbutton15.setToggle = false;
            this.rhBbutton15.Size = new System.Drawing.Size(234, 63);
            this.rhBbutton15.TabIndex = 33;
            this.rhBbutton15.TabStop = false;
            this.rhBbutton15.Tag = "3";
            this.rhBbutton15.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.rhBbutton15.Click += new System.EventHandler(this.btn_AddEtcDevice1_Click);
            // 
            // rhBbutton20
            // 
            this.rhBbutton20.BackColor = System.Drawing.Color.Transparent;
            this.rhBbutton20.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.rhBbutton20.ForeColor = System.Drawing.Color.Yellow;
            this.rhBbutton20.Location = new System.Drawing.Point(29, 111);
            this.rhBbutton20.Margin = new System.Windows.Forms.Padding(8);
            this.rhBbutton20.Name = "rhBbutton20";
            this.rhBbutton20.setFontColor = System.Drawing.Color.Yellow;
            this.rhBbutton20.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton20.setOFFimage")));
            this.rhBbutton20.setON = false;
            this.rhBbutton20.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton20.setONimage")));
            this.rhBbutton20.setText = "라브러리 장비";
            this.rhBbutton20.setToggle = false;
            this.rhBbutton20.Size = new System.Drawing.Size(234, 63);
            this.rhBbutton20.TabIndex = 28;
            this.rhBbutton20.TabStop = false;
            this.rhBbutton20.Tag = "2";
            this.rhBbutton20.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.rhBbutton20.Click += new System.EventHandler(this.btn_AddEtcDevice1_Click);
            // 
            // btn_AddEtcDevice1
            // 
            this.btn_AddEtcDevice1.BackColor = System.Drawing.Color.Transparent;
            this.btn_AddEtcDevice1.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_AddEtcDevice1.ForeColor = System.Drawing.Color.Yellow;
            this.btn_AddEtcDevice1.Location = new System.Drawing.Point(29, 39);
            this.btn_AddEtcDevice1.Margin = new System.Windows.Forms.Padding(8);
            this.btn_AddEtcDevice1.Name = "btn_AddEtcDevice1";
            this.btn_AddEtcDevice1.setFontColor = System.Drawing.Color.Yellow;
            this.btn_AddEtcDevice1.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_AddEtcDevice1.setOFFimage")));
            this.btn_AddEtcDevice1.setON = false;
            this.btn_AddEtcDevice1.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_AddEtcDevice1.setONimage")));
            this.btn_AddEtcDevice1.setText = "Madmapper (UDP)";
            this.btn_AddEtcDevice1.setToggle = false;
            this.btn_AddEtcDevice1.Size = new System.Drawing.Size(234, 63);
            this.btn_AddEtcDevice1.TabIndex = 27;
            this.btn_AddEtcDevice1.TabStop = false;
            this.btn_AddEtcDevice1.Tag = "1";
            this.btn_AddEtcDevice1.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_AddEtcDevice1.Click += new System.EventHandler(this.btn_AddEtcDevice1_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btn_AddRoom);
            this.groupBox3.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox3.ForeColor = System.Drawing.Color.White;
            this.groupBox3.Location = new System.Drawing.Point(1097, 572);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(292, 128);
            this.groupBox3.TabIndex = 30;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = " 그룹 등록  ";
            // 
            // btn_AddRoom
            // 
            this.btn_AddRoom.BackColor = System.Drawing.Color.Transparent;
            this.btn_AddRoom.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_AddRoom.ForeColor = System.Drawing.Color.Yellow;
            this.btn_AddRoom.Location = new System.Drawing.Point(29, 44);
            this.btn_AddRoom.Margin = new System.Windows.Forms.Padding(8);
            this.btn_AddRoom.Name = "btn_AddRoom";
            this.btn_AddRoom.setFontColor = System.Drawing.Color.Yellow;
            this.btn_AddRoom.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_AddRoom.setOFFimage")));
            this.btn_AddRoom.setON = false;
            this.btn_AddRoom.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_AddRoom.setONimage")));
            this.btn_AddRoom.setText = "그룹 추가(장소 추가)";
            this.btn_AddRoom.setToggle = false;
            this.btn_AddRoom.Size = new System.Drawing.Size(234, 63);
            this.btn_AddRoom.TabIndex = 27;
            this.btn_AddRoom.TabStop = false;
            this.btn_AddRoom.Tag = "1";
            this.btn_AddRoom.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_AddRoom.Click += new System.EventHandler(this.btn_AddRoom_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btn_onoff);
            this.groupBox4.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox4.ForeColor = System.Drawing.Color.White;
            this.groupBox4.Location = new System.Drawing.Point(1097, 723);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(292, 128);
            this.groupBox4.TabIndex = 31;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "전원 반복 동작 ";
            // 
            // btn_onoff
            // 
            this.btn_onoff.BackColor = System.Drawing.Color.Transparent;
            this.btn_onoff.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_onoff.ForeColor = System.Drawing.Color.Yellow;
            this.btn_onoff.Location = new System.Drawing.Point(29, 38);
            this.btn_onoff.Margin = new System.Windows.Forms.Padding(8);
            this.btn_onoff.Name = "btn_onoff";
            this.btn_onoff.setFontColor = System.Drawing.Color.Yellow;
            this.btn_onoff.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_onoff.setOFFimage")));
            this.btn_onoff.setON = false;
            this.btn_onoff.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_onoff.setONimage")));
            this.btn_onoff.setText = "On/Off 반복 설정";
            this.btn_onoff.setToggle = false;
            this.btn_onoff.Size = new System.Drawing.Size(234, 63);
            this.btn_onoff.TabIndex = 28;
            this.btn_onoff.TabStop = false;
            this.btn_onoff.Tag = "1";
            this.btn_onoff.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_onoff.Click += new System.EventHandler(this.btn_onoff_Click);
            // 
            // frmDeviceADD
            // 
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.ClientSize = new System.Drawing.Size(1435, 890);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.rhBbutton3);
            this.Controls.Add(this.rhBbutton1);
            this.Controls.Add(this.treeView1);
            this.Controls.Add(this.rhBbutton2);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmDeviceADD";
            this.Text = "frmDeviceADD";
            this.Load += new System.EventHandler(this.frmDeviceADD_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TreeView treeView1;
        private RHBform.RHBbutton rhBbutton2;
        private RHBform.RHBbutton rhBbutton1;
        private RHBform.RHBbutton rhBbutton3;
        private System.Windows.Forms.GroupBox groupBox1;
        private RHBform.RHBbutton rhBbutton12;
        private RHBform.RHBbutton rhBbutton11;
        private RHBform.RHBbutton rhBbutton10;
        private RHBform.RHBbutton rhBbutton9;
        private RHBform.RHBbutton rhBbutton8;
        private RHBform.RHBbutton rhBbutton7;
        private RHBform.RHBbutton rhBbutton6;
        private RHBform.RHBbutton rhBbutton5;
        private RHBform.RHBbutton btn_AddPowerDevice1;
        private System.Windows.Forms.GroupBox groupBox2;
        private RHBform.RHBbutton rhBbutton13;
        private RHBform.RHBbutton rhBbutton14;
        private RHBform.RHBbutton rhBbutton15;
        private RHBform.RHBbutton rhBbutton20;
        private RHBform.RHBbutton btn_AddEtcDevice1;
        private System.Windows.Forms.GroupBox groupBox3;
        private RHBform.RHBbutton btn_AddRoom;
        private System.Windows.Forms.GroupBox groupBox4;
        private RHBform.RHBbutton btn_onoff;
    }
}