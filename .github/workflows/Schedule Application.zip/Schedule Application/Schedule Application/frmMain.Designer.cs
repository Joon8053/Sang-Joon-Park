﻿namespace Schedule_Application
{
    partial class frmMain
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.panel_head = new System.Windows.Forms.Panel();
            this.dis_sc = new System.Windows.Forms.Button();
            this.label_dis2 = new System.Windows.Forms.Label();
            this.dis_time = new System.Windows.Forms.Button();
            this.rhBbutton4 = new RHBform.RHBbutton();
            this.btn_admin = new RHBform.RHBbutton();
            this.btn_mini = new System.Windows.Forms.Button();
            this.btn_close = new System.Windows.Forms.Button();
            this.label_t = new System.Windows.Forms.Label();
            this.panel_base = new System.Windows.Forms.Panel();
            this.log_pc = new System.Windows.Forms.RichTextBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.btn_menu1 = new RHBform.RHBbutton();
            this.btn_menu2 = new RHBform.RHBbutton();
            this.btn_menu3 = new RHBform.RHBbutton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel_head.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_head
            // 
            this.panel_head.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(39)))), ((int)(((byte)(53)))));
            this.panel_head.Controls.Add(this.dis_sc);
            this.panel_head.Controls.Add(this.label_dis2);
            this.panel_head.Controls.Add(this.dis_time);
            this.panel_head.Controls.Add(this.rhBbutton4);
            this.panel_head.Controls.Add(this.btn_admin);
            this.panel_head.Controls.Add(this.btn_mini);
            this.panel_head.Controls.Add(this.btn_close);
            this.panel_head.Controls.Add(this.label_t);
            this.panel_head.Location = new System.Drawing.Point(1, 1);
            this.panel_head.Margin = new System.Windows.Forms.Padding(4);
            this.panel_head.Name = "panel_head";
            this.panel_head.Size = new System.Drawing.Size(1920, 46);
            this.panel_head.TabIndex = 4;
            // 
            // dis_sc
            // 
            this.dis_sc.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.dis_sc.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.dis_sc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dis_sc.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.dis_sc.Location = new System.Drawing.Point(949, 8);
            this.dis_sc.Name = "dis_sc";
            this.dis_sc.Size = new System.Drawing.Size(460, 31);
            this.dis_sc.TabIndex = 472;
            this.dis_sc.Tag = "31";
            this.dis_sc.Text = "--";
            this.dis_sc.UseVisualStyleBackColor = true;
            // 
            // label_dis2
            // 
            this.label_dis2.AutoSize = true;
            this.label_dis2.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_dis2.Location = new System.Drawing.Point(856, 15);
            this.label_dis2.Name = "label_dis2";
            this.label_dis2.Size = new System.Drawing.Size(87, 15);
            this.label_dis2.TabIndex = 471;
            this.label_dis2.Text = "다음 스케쥴";
            // 
            // dis_time
            // 
            this.dis_time.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.dis_time.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Black;
            this.dis_time.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dis_time.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.dis_time.Location = new System.Drawing.Point(626, 8);
            this.dis_time.Name = "dis_time";
            this.dis_time.Size = new System.Drawing.Size(214, 31);
            this.dis_time.TabIndex = 470;
            this.dis_time.Tag = "31";
            this.dis_time.Text = "00:00:00";
            this.dis_time.UseVisualStyleBackColor = true;
            // 
            // rhBbutton4
            // 
            this.rhBbutton4.BackColor = System.Drawing.Color.Transparent;
            this.rhBbutton4.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.rhBbutton4.ForeColor = System.Drawing.Color.Yellow;
            this.rhBbutton4.Location = new System.Drawing.Point(1535, -8);
            this.rhBbutton4.Margin = new System.Windows.Forms.Padding(8);
            this.rhBbutton4.Name = "rhBbutton4";
            this.rhBbutton4.setFontColor = System.Drawing.Color.Yellow;
            this.rhBbutton4.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton4.setOFFimage")));
            this.rhBbutton4.setON = false;
            this.rhBbutton4.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton4.setONimage")));
            this.rhBbutton4.setText = "전원 장비 동작(1)";
            this.rhBbutton4.setToggle = false;
            this.rhBbutton4.Size = new System.Drawing.Size(168, 58);
            this.rhBbutton4.TabIndex = 469;
            this.rhBbutton4.TabStop = false;
            this.rhBbutton4.Tag = "1";
            this.rhBbutton4.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_admin
            // 
            this.btn_admin.BackColor = System.Drawing.Color.Transparent;
            this.btn_admin.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_admin.ForeColor = System.Drawing.Color.Yellow;
            this.btn_admin.Location = new System.Drawing.Point(1702, -8);
            this.btn_admin.Margin = new System.Windows.Forms.Padding(8);
            this.btn_admin.Name = "btn_admin";
            this.btn_admin.setFontColor = System.Drawing.Color.Yellow;
            this.btn_admin.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_admin.setOFFimage")));
            this.btn_admin.setON = false;
            this.btn_admin.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_admin.setONimage")));
            this.btn_admin.setText = "설정";
            this.btn_admin.setToggle = false;
            this.btn_admin.Size = new System.Drawing.Size(88, 58);
            this.btn_admin.TabIndex = 468;
            this.btn_admin.TabStop = false;
            this.btn_admin.Tag = "1";
            this.btn_admin.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_admin.Click += new System.EventHandler(this.btn_admin_Click);
            // 
            // btn_mini
            // 
            this.btn_mini.BackColor = System.Drawing.Color.Black;
            this.btn_mini.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btn_mini.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.btn_mini.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_mini.Font = new System.Drawing.Font("굴림", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_mini.ForeColor = System.Drawing.Color.White;
            this.btn_mini.Location = new System.Drawing.Point(1802, 7);
            this.btn_mini.Margin = new System.Windows.Forms.Padding(4);
            this.btn_mini.Name = "btn_mini";
            this.btn_mini.Size = new System.Drawing.Size(51, 30);
            this.btn_mini.TabIndex = 467;
            this.btn_mini.Text = "_";
            this.btn_mini.UseVisualStyleBackColor = false;
            // 
            // btn_close
            // 
            this.btn_close.BackColor = System.Drawing.Color.Black;
            this.btn_close.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btn_close.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.btn_close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_close.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_close.ForeColor = System.Drawing.Color.White;
            this.btn_close.Location = new System.Drawing.Point(1858, 7);
            this.btn_close.Margin = new System.Windows.Forms.Padding(4);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(51, 30);
            this.btn_close.TabIndex = 466;
            this.btn_close.Text = "X";
            this.btn_close.UseVisualStyleBackColor = false;
            // 
            // label_t
            // 
            this.label_t.AutoSize = true;
            this.label_t.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_t.Location = new System.Drawing.Point(20, 10);
            this.label_t.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_t.Name = "label_t";
            this.label_t.Size = new System.Drawing.Size(245, 24);
            this.label_t.TabIndex = 465;
            this.label_t.Text = "Schedule Application";
            // 
            // panel_base
            // 
            this.panel_base.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.panel_base.Location = new System.Drawing.Point(1, 78);
            this.panel_base.Name = "panel_base";
            this.panel_base.Size = new System.Drawing.Size(1435, 890);
            this.panel_base.TabIndex = 5;
            // 
            // log_pc
            // 
            this.log_pc.BackColor = System.Drawing.Color.DimGray;
            this.log_pc.Location = new System.Drawing.Point(1440, 109);
            this.log_pc.Name = "log_pc";
            this.log_pc.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.log_pc.Size = new System.Drawing.Size(468, 410);
            this.log_pc.TabIndex = 6;
            this.log_pc.Text = "";
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.DimGray;
            this.richTextBox1.Location = new System.Drawing.Point(1440, 557);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.richTextBox1.Size = new System.Drawing.Size(468, 410);
            this.richTextBox1.TabIndex = 7;
            this.richTextBox1.Text = "";
            // 
            // btn_menu1
            // 
            this.btn_menu1.BackColor = System.Drawing.Color.Transparent;
            this.btn_menu1.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_menu1.ForeColor = System.Drawing.Color.Yellow;
            this.btn_menu1.Location = new System.Drawing.Point(0, 33);
            this.btn_menu1.Margin = new System.Windows.Forms.Padding(8);
            this.btn_menu1.Name = "btn_menu1";
            this.btn_menu1.setFontColor = System.Drawing.Color.Yellow;
            this.btn_menu1.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_menu1.setOFFimage")));
            this.btn_menu1.setON = false;
            this.btn_menu1.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_menu1.setONimage")));
            this.btn_menu1.setText = "스케쥴";
            this.btn_menu1.setToggle = false;
            this.btn_menu1.Size = new System.Drawing.Size(171, 56);
            this.btn_menu1.TabIndex = 22;
            this.btn_menu1.TabStop = false;
            this.btn_menu1.Tag = "1";
            this.btn_menu1.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_menu1.Click += new System.EventHandler(this.btn_menu1_Click);
            // 
            // btn_menu2
            // 
            this.btn_menu2.BackColor = System.Drawing.Color.Transparent;
            this.btn_menu2.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_menu2.ForeColor = System.Drawing.Color.Yellow;
            this.btn_menu2.Location = new System.Drawing.Point(170, 33);
            this.btn_menu2.Margin = new System.Windows.Forms.Padding(8);
            this.btn_menu2.Name = "btn_menu2";
            this.btn_menu2.setFontColor = System.Drawing.Color.Yellow;
            this.btn_menu2.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_menu2.setOFFimage")));
            this.btn_menu2.setON = false;
            this.btn_menu2.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_menu2.setONimage")));
            this.btn_menu2.setText = "장비 모니터링";
            this.btn_menu2.setToggle = false;
            this.btn_menu2.Size = new System.Drawing.Size(171, 56);
            this.btn_menu2.TabIndex = 23;
            this.btn_menu2.TabStop = false;
            this.btn_menu2.Tag = "2";
            this.btn_menu2.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_menu2.Click += new System.EventHandler(this.btn_menu1_Click);
            // 
            // btn_menu3
            // 
            this.btn_menu3.BackColor = System.Drawing.Color.Transparent;
            this.btn_menu3.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_menu3.ForeColor = System.Drawing.Color.Yellow;
            this.btn_menu3.Location = new System.Drawing.Point(340, 33);
            this.btn_menu3.Margin = new System.Windows.Forms.Padding(8);
            this.btn_menu3.Name = "btn_menu3";
            this.btn_menu3.setFontColor = System.Drawing.Color.Yellow;
            this.btn_menu3.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_menu3.setOFFimage")));
            this.btn_menu3.setON = false;
            this.btn_menu3.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_menu3.setONimage")));
            this.btn_menu3.setText = "장비 등록";
            this.btn_menu3.setToggle = false;
            this.btn_menu3.Size = new System.Drawing.Size(171, 56);
            this.btn_menu3.TabIndex = 24;
            this.btn_menu3.TabStop = false;
            this.btn_menu3.Tag = "3";
            this.btn_menu3.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_menu3.Visible = false;
            this.btn_menu3.Click += new System.EventHandler(this.btn_menu1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(1443, 83);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(150, 16);
            this.label1.TabIndex = 25;
            this.label1.Text = "전원 장비 통신 상태";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(1443, 530);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(150, 16);
            this.label2.TabIndex = 26;
            this.label2.Text = "기타 장비 통신 상태";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(8, 975);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(145, 16);
            this.label3.TabIndex = 27;
            this.label3.Text = "Relese : 2022.08.15";
            // 
            // frmMain
            // 
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1920, 1000);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.log_pc);
            this.Controls.Add(this.panel_base);
            this.Controls.Add(this.panel_head);
            this.Controls.Add(this.btn_menu1);
            this.Controls.Add(this.btn_menu2);
            this.Controls.Add(this.btn_menu3);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmMain";
            this.Text = "Schedule";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.panel_head.ResumeLayout(false);
            this.panel_head.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel_head;
        private System.Windows.Forms.Button btn_mini;
        private System.Windows.Forms.Label label_t;
        private System.Windows.Forms.Button btn_close;
        private System.Windows.Forms.Panel panel_base;
        private System.Windows.Forms.RichTextBox log_pc;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private RHBform.RHBbutton btn_menu1;
        private RHBform.RHBbutton btn_menu2;
        private RHBform.RHBbutton btn_menu3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private RHBform.RHBbutton rhBbutton4;
        private RHBform.RHBbutton btn_admin;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button dis_sc;
        private System.Windows.Forms.Label label_dis2;
        private System.Windows.Forms.Button dis_time;
    }
}

