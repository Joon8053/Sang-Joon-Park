﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Schedule_Application
{
    public partial class frmSchedule : Form
    {

        frmMain app;

        public frmSchedule(frmMain main)
        {
            InitializeComponent();
            app = main;
        }

        private void frmSchedule_Load(object sender, EventArgs e)
        {

        }

        public void SetAdmin(bool flg)
        {
            groupBox_sc1.Visible = flg;
            groupBox_sc2.Visible = flg;
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            frmADDschedule dlg = new frmADDschedule();

            dlg.ShowDialog();
        }
    }
}
