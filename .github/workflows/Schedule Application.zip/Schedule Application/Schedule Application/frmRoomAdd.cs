﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RHBform;
using RHBLibrary.schedule;

namespace Schedule_Application
{
    public partial class frmRoomAdd : Form
    {
        #region FormBoder
        private void customBackgroundPainter(PaintEventArgs e, int linethickness = 2, Color linecolor = new Color(), int offsetborder = 6)
        {
            Rectangle rect = new Rectangle(offsetborder, offsetborder, this.ClientSize.Width - (offsetborder * 2), this.ClientSize.Height - (offsetborder * 2));

            Pen pen = new Pen(new Color());
            pen.Width = linethickness;
            if (linecolor != new Color())
            {
                pen.Color = linecolor;
            }
            else
            {
                pen.Color = Color.Black;
            }

            e.Graphics.DrawRectangle(pen, rect);
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            Color cl = Color.FromArgb(100, 100, 100);
            base.OnPaintBackground(e);
            customBackgroundPainter(
            e,
            linethickness: 1,
            linecolor: cl,
            offsetborder: 1
            );
        }
        #endregion

        public frmRoomAdd()
        {
            InitializeComponent();
        }

        clsScheduleRoom mRoom;
        private void frmRoomAdd_Load(object sender, EventArgs e)
        {
            fromBase frm = new fromBase(this, panel_head, btn_close, label_t);
            panel_head.Size = new Size(this.Width - 4, panel_head.Height);
            panel_head.Location = new Point(2, 2);
            System.Timers.Timer SyncTimer = new System.Timers.Timer();
            SyncTimer.Interval = 1000;
            SyncTimer.Elapsed += SyncTimer_Elapsed;
            SyncTimer.Enabled = true;
            mRoom = new clsScheduleRoom();
            DataInit();
        }


        private void DataInit()
        {
            treeView_group.Nodes.Clear();
            foreach(string ss in mRoom.mData.room)
            {
                treeView_group.Nodes.Add(ss);
            }
        }
        private void SyncTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (led_sync.BackColor == Color.Red)
                led_sync.BackColor = Color.Lime;
            else
                led_sync.BackColor = Color.Red;
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            if (textBox_name.Text != "")
            {
                mRoom.mData.room.Add(textBox_name.Text);
                treeView_group.Nodes.Add(textBox_name.Text);
                textBox_name.Text = "";
            }
            
        }

        private void btn_erase_Click(object sender, EventArgs e)
        {
            string ss = treeView_group.SelectedNode.Text;
            if (ss != "미분류")
            {
                mRoom.mData.room.Remove(treeView_group.SelectedNode.Text);
                treeView_group.SelectedNode.Remove();
            }
        }

        private void treeView_group_AfterSelect(object sender, TreeViewEventArgs e)
        {
            //textBox_name.Text = treeView_group.SelectedNode.Text;
        }

        public event Action<bool> onUpdate;
        private void btn_save_Click(object sender, EventArgs e)
        {
            mRoom.DataSave();
            onUpdate?.Invoke(true);
            this.Close();
        }
    }
}
