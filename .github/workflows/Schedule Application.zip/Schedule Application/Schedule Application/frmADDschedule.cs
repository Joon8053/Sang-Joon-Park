﻿using RHBform;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Schedule_Application
{
    public partial class frmADDschedule : Form
    {
        #region FormBoder
        private void customBackgroundPainter(PaintEventArgs e, int linethickness = 2, Color linecolor = new Color(), int offsetborder = 6)
        {
            Rectangle rect = new Rectangle(offsetborder, offsetborder, this.ClientSize.Width - (offsetborder * 2), this.ClientSize.Height - (offsetborder * 2));

            Pen pen = new Pen(new Color());
            pen.Width = linethickness;
            if (linecolor != new Color())
            {
                pen.Color = linecolor;
            }
            else
            {
                pen.Color = Color.Black;
            }

            e.Graphics.DrawRectangle(pen, rect);
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            Color cl = Color.FromArgb(100, 100, 100);
            base.OnPaintBackground(e);
            customBackgroundPainter(
            e,
            linethickness: 1,
            linecolor: cl,
            offsetborder: 1
            );
        }
        #endregion
        public frmADDschedule()
        {
            InitializeComponent();
        }

        private void frmADDschedule_Load(object sender, EventArgs e)
        {
            fromBase frm = new fromBase(this, panel_head, btn_close, label_t);
            panel_head.Size = new Size(this.Width - 4, panel_head.Height);
            panel_head.Location = new Point(2, 2);
            System.Timers.Timer SyncTimer = new System.Timers.Timer();
            SyncTimer.Interval = 1000;
            SyncTimer.Elapsed += SyncTimer_Elapsed;
            SyncTimer.Enabled = true;
        }

        private void SyncTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (led_sync.BackColor == Color.Red)
                led_sync.BackColor = Color.Lime;
            else
                led_sync.BackColor = Color.Red;
        }

        private void st_power_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || e.KeyChar == Convert.ToChar(Keys.Back)))
            {
                e.Handled = true;
            }
        }
    }
}
