﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tellus_Manager
{
    class ClassWOL:IDisposable
    {
        private frmMain myParent { get; set; }

        private int fv_MaxCnt = 10;
        private int fv_Interval = 1000;

        private int curCnt = 0;

        public ClassWOL(frmMain _myParent, string _macAddr, string ipaddress)
        {
            myParent = _myParent;

            fv_MaxCnt = myParent.fv_RtoTimeOutCnt_PC;
            fv_Interval = myParent.fv_RtoInterval_PC;

            Console.WriteLine(">> Create :: ClassWOL << ");
            fn_AsyncWakeUp(_macAddr, ipaddress);
        }
        public void Dispose()
        {
            Console.WriteLine(">> Dispose :: ClassWOL << ");
        }

        //private void fn_WakeUp(string _mac)
        //{
        //    WOL.WakeUp(_mac);
        //}

        private PingTest _pingtest;

        async void fn_AsyncWakeUp(string _mac, string ipaddress)
        {
            WOL.WakeUp(_mac);
            Console.WriteLine(">> try WOL.WakeUp(); :: " + _mac + ", " + ipaddress);
            myParent.fn_Log(">> try WOL.WakeUp(); :: " + _mac + ", " + ipaddress);

            if (myParent.isRtoUseYn_PC == true)     // 사용 ON일때만
            {

                await Task.Delay(fv_Interval);  // 정한 간격만큼 기다리고 1.연결확인 2.카운트확인 하고 다시 호출

                _pingtest = new PingTest();
                if (_pingtest.fn_isAlive(ipaddress) == false)
                {
                    curCnt++;
                    if (curCnt < fv_MaxCnt)
                    {
                        Console.WriteLine(">> pc ON curCnt :: " + curCnt);
                        myParent.fn_Log(">> pc ON curCnt :: " + curCnt);

                        fn_AsyncWakeUp(_mac, ipaddress);
                    }
                    else
                    {
                        Console.WriteLine(">> pc ON curCnt :: 최대카운트만큼 모두 보냄, 종료");
                        myParent.fn_Log(">> pc ON curCnt :: 최대카운트만큼 모두 보냄, 종료");
                    }
                }
                else
                {
                    Console.WriteLine(">> pc 켜져 있음 :: " + _mac + ", " + ipaddress);
                    myParent.fn_Log(">> pc 켜져 있음, 종료 :: " + _mac + ", " + ipaddress);
                }

            }

        }

    }

    
}
