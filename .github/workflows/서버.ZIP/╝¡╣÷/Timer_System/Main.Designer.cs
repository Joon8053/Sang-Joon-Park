﻿namespace Timer_System
{
    partial class Main
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btn_save = new System.Windows.Forms.Button();
            this.btn_set = new System.Windows.Forms.Button();
            this.btn_del = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_all_on = new System.Windows.Forms.Button();
            this.btn_all_off = new System.Windows.Forms.Button();
            this.sc_edit = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.DCombo = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.sc_save = new System.Windows.Forms.Button();
            this.sc_del = new System.Windows.Forms.Button();
            this.sc_add = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label29 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_CurTime = new System.Windows.Forms.TextBox();
            this.textBox_CurWeek = new System.Windows.Forms.TextBox();
            this.set_data = new System.Windows.Forms.DataGridView();
            this.scdule_view = new System.Windows.Forms.DataGridView();
            this.top_menu_image = new System.Windows.Forms.ImageList(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.time_dis = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.next_sc_dis = new System.Windows.Forms.Label();
            this.timer_lcd = new System.Windows.Forms.Timer(this.components);
            this.clock_dis = new System.Windows.Forms.Timer(this.components);
            this.all_OnOff = new System.Windows.Forms.Timer(this.components);
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn2 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn3 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn4 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn5 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn6 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn7 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.dataGridViewButtonColumn1 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Column18 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.변환시간 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.모드 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sc_edit)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.set_data)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.scdule_view)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel3.Controls.Add(this.btn_save);
            this.panel3.Controls.Add(this.btn_set);
            this.panel3.Controls.Add(this.btn_del);
            this.panel3.Controls.Add(this.btn_add);
            this.panel3.Location = new System.Drawing.Point(391, 19);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1011, 64);
            this.panel3.TabIndex = 361;
            // 
            // btn_save
            // 
            this.btn_save.BackColor = System.Drawing.Color.Silver;
            this.btn_save.Enabled = false;
            this.btn_save.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_save.ForeColor = System.Drawing.Color.Navy;
            this.btn_save.Location = new System.Drawing.Point(843, 6);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(137, 51);
            this.btn_save.TabIndex = 358;
            this.btn_save.Text = "저장";
            this.btn_save.UseVisualStyleBackColor = false;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // btn_set
            // 
            this.btn_set.BackColor = System.Drawing.Color.Silver;
            this.btn_set.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_set.ForeColor = System.Drawing.Color.Navy;
            this.btn_set.Location = new System.Drawing.Point(26, 9);
            this.btn_set.Name = "btn_set";
            this.btn_set.Size = new System.Drawing.Size(360, 48);
            this.btn_set.TabIndex = 355;
            this.btn_set.Text = "설정";
            this.btn_set.UseVisualStyleBackColor = false;
            this.btn_set.Click += new System.EventHandler(this.btn_set_Click);
            // 
            // btn_del
            // 
            this.btn_del.BackColor = System.Drawing.Color.Silver;
            this.btn_del.Enabled = false;
            this.btn_del.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_del.ForeColor = System.Drawing.Color.Navy;
            this.btn_del.Location = new System.Drawing.Point(578, 9);
            this.btn_del.Name = "btn_del";
            this.btn_del.Size = new System.Drawing.Size(170, 48);
            this.btn_del.TabIndex = 357;
            this.btn_del.Text = "삭제";
            this.btn_del.UseVisualStyleBackColor = false;
            this.btn_del.Click += new System.EventHandler(this.btn_del_Click);
            // 
            // btn_add
            // 
            this.btn_add.BackColor = System.Drawing.Color.Silver;
            this.btn_add.Enabled = false;
            this.btn_add.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_add.ForeColor = System.Drawing.Color.Navy;
            this.btn_add.Location = new System.Drawing.Point(392, 9);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(180, 48);
            this.btn_add.TabIndex = 356;
            this.btn_add.Text = "추가";
            this.btn_add.UseVisualStyleBackColor = false;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.Controls.Add(this.btn_all_on);
            this.panel2.Controls.Add(this.btn_all_off);
            this.panel2.Location = new System.Drawing.Point(23, 19);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(353, 64);
            this.panel2.TabIndex = 360;
            // 
            // btn_all_on
            // 
            this.btn_all_on.BackColor = System.Drawing.Color.Silver;
            this.btn_all_on.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btn_all_on.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btn_all_on.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_all_on.ForeColor = System.Drawing.Color.Navy;
            this.btn_all_on.Location = new System.Drawing.Point(16, 9);
            this.btn_all_on.Name = "btn_all_on";
            this.btn_all_on.Size = new System.Drawing.Size(146, 51);
            this.btn_all_on.TabIndex = 16;
            this.btn_all_on.Text = "전체 전원 ON";
            this.btn_all_on.UseVisualStyleBackColor = false;
            this.btn_all_on.Click += new System.EventHandler(this.btn_all_on_Click);
            // 
            // btn_all_off
            // 
            this.btn_all_off.BackColor = System.Drawing.Color.Silver;
            this.btn_all_off.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btn_all_off.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.btn_all_off.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_all_off.ForeColor = System.Drawing.Color.Navy;
            this.btn_all_off.Location = new System.Drawing.Point(168, 9);
            this.btn_all_off.Name = "btn_all_off";
            this.btn_all_off.Size = new System.Drawing.Size(157, 51);
            this.btn_all_off.TabIndex = 352;
            this.btn_all_off.Text = "전체 전원 OFF";
            this.btn_all_off.UseVisualStyleBackColor = false;
            this.btn_all_off.Click += new System.EventHandler(this.btn_all_off_Click0);
            // 
            // sc_edit
            // 
            this.sc_edit.BackgroundColor = System.Drawing.Color.Gainsboro;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.sc_edit.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.sc_edit.ColumnHeadersHeight = 40;
            this.sc_edit.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.sc_edit.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.DCombo,
            this.Column9,
            this.Column10,
            this.Column11});
            this.sc_edit.GridColor = System.Drawing.SystemColors.ActiveCaption;
            this.sc_edit.Location = new System.Drawing.Point(23, 91);
            this.sc_edit.Name = "sc_edit";
            this.sc_edit.ReadOnly = true;
            this.sc_edit.RowHeadersWidth = 40;
            this.sc_edit.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.sc_edit.RowTemplate.Height = 30;
            this.sc_edit.Size = new System.Drawing.Size(1457, 813);
            this.sc_edit.TabIndex = 356;
            this.sc_edit.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.sc_edit_CellContentClick);
            // 
            // Column1
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.Column1.DefaultCellStyle = dataGridViewCellStyle2;
            this.Column1.HeaderText = "설치 장소";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 200;
            // 
            // Column2
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column2.DefaultCellStyle = dataGridViewCellStyle3;
            this.Column2.HeaderText = "IP 주소";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 170;
            // 
            // Column3
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column3.DefaultCellStyle = dataGridViewCellStyle4;
            this.Column3.HeaderText = "MAC 주소";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 170;
            // 
            // Column4
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.Transparent;
            this.Column4.DefaultCellStyle = dataGridViewCellStyle5;
            this.Column4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Column4.HeaderText = "NET";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column4.Text = "";
            this.Column4.Width = 40;
            // 
            // Column5
            // 
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.Transparent;
            this.Column5.DefaultCellStyle = dataGridViewCellStyle6;
            this.Column5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Column5.HeaderText = "전원";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column5.Width = 40;
            // 
            // Column6
            // 
            this.Column6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Column6.HeaderText = "ON";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            this.Column6.Width = 160;
            // 
            // Column7
            // 
            this.Column7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Column7.HeaderText = "OFF";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            this.Column7.Width = 160;
            // 
            // DCombo
            // 
            this.DCombo.HeaderText = "장비명";
            this.DCombo.Items.AddRange(new object[] {
            "PC",
            "Projector",
            "Player",
            "Barco Projector",
            "Chrisite Projector",
            "리눅스 Player"});
            this.DCombo.MaxDropDownItems = 10;
            this.DCombo.Name = "DCombo";
            this.DCombo.ReadOnly = true;
            this.DCombo.Width = 80;
            // 
            // Column9
            // 
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column9.DefaultCellStyle = dataGridViewCellStyle7;
            this.Column9.HeaderText = "cpu";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            // 
            // Column10
            // 
            this.Column10.HeaderText = "RAM";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            this.Column10.Width = 150;
            // 
            // Column11
            // 
            this.Column11.HeaderText = "PC Relay";
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.ImageList = this.top_menu_image;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1920, 1050);
            this.tabControl1.TabIndex = 362;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Silver;
            this.tabPage2.Controls.Add(this.sc_edit);
            this.tabPage2.Controls.Add(this.panel3);
            this.tabPage2.Controls.Add(this.panel2);
            this.tabPage2.ImageIndex = 2;
            this.tabPage2.Location = new System.Drawing.Point(4, 57);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1912, 989);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Setting";
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Silver;
            this.tabPage1.Controls.Add(this.sc_save);
            this.tabPage1.Controls.Add(this.sc_del);
            this.tabPage1.Controls.Add(this.sc_add);
            this.tabPage1.Controls.Add(this.panel4);
            this.tabPage1.Controls.Add(this.scdule_view);
            this.tabPage1.ImageIndex = 1;
            this.tabPage1.Location = new System.Drawing.Point(4, 57);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1912, 989);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "주간 타이머";
            // 
            // sc_save
            // 
            this.sc_save.Font = new System.Drawing.Font("굴림", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.sc_save.ForeColor = System.Drawing.Color.Blue;
            this.sc_save.Location = new System.Drawing.Point(551, 645);
            this.sc_save.Name = "sc_save";
            this.sc_save.Size = new System.Drawing.Size(155, 59);
            this.sc_save.TabIndex = 358;
            this.sc_save.Text = "저장";
            this.sc_save.UseVisualStyleBackColor = true;
            this.sc_save.Click += new System.EventHandler(this.sc_save_Click);
            // 
            // sc_del
            // 
            this.sc_del.Font = new System.Drawing.Font("굴림", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.sc_del.ForeColor = System.Drawing.Color.Blue;
            this.sc_del.Location = new System.Drawing.Point(169, 645);
            this.sc_del.Name = "sc_del";
            this.sc_del.Size = new System.Drawing.Size(155, 59);
            this.sc_del.TabIndex = 357;
            this.sc_del.Text = "일정 삭제";
            this.sc_del.UseVisualStyleBackColor = true;
            this.sc_del.Click += new System.EventHandler(this.sc_del_Click);
            // 
            // sc_add
            // 
            this.sc_add.Font = new System.Drawing.Font("굴림", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.sc_add.ForeColor = System.Drawing.Color.Blue;
            this.sc_add.Location = new System.Drawing.Point(8, 645);
            this.sc_add.Name = "sc_add";
            this.sc_add.Size = new System.Drawing.Size(155, 59);
            this.sc_add.TabIndex = 356;
            this.sc_add.Text = "일정 추가";
            this.sc_add.UseVisualStyleBackColor = true;
            this.sc_add.Click += new System.EventHandler(this.sc_add_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel4.Controls.Add(this.label29);
            this.panel4.Controls.Add(this.label5);
            this.panel4.Controls.Add(this.textBox_CurTime);
            this.panel4.Controls.Add(this.textBox_CurWeek);
            this.panel4.Controls.Add(this.set_data);
            this.panel4.Location = new System.Drawing.Point(722, 30);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(775, 609);
            this.panel4.TabIndex = 355;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(223, 24);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(63, 13);
            this.label29.TabIndex = 13;
            this.label29.Text = "현재 시간";
            this.label29.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "현재 요일";
            // 
            // textBox_CurTime
            // 
            this.textBox_CurTime.Location = new System.Drawing.Point(292, 17);
            this.textBox_CurTime.Name = "textBox_CurTime";
            this.textBox_CurTime.Size = new System.Drawing.Size(129, 22);
            this.textBox_CurTime.TabIndex = 11;
            this.textBox_CurTime.Visible = false;
            // 
            // textBox_CurWeek
            // 
            this.textBox_CurWeek.Location = new System.Drawing.Point(88, 17);
            this.textBox_CurWeek.Name = "textBox_CurWeek";
            this.textBox_CurWeek.Size = new System.Drawing.Size(129, 22);
            this.textBox_CurWeek.TabIndex = 10;
            // 
            // set_data
            // 
            this.set_data.BackgroundColor = System.Drawing.Color.Gainsboro;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.set_data.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.set_data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.set_data.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column18,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.변환시간,
            this.모드});
            this.set_data.GridColor = System.Drawing.SystemColors.ActiveCaption;
            this.set_data.Location = new System.Drawing.Point(20, 56);
            this.set_data.Name = "set_data";
            this.set_data.RowTemplate.Height = 23;
            this.set_data.Size = new System.Drawing.Size(734, 530);
            this.set_data.TabIndex = 9;
            // 
            // scdule_view
            // 
            this.scdule_view.BackgroundColor = System.Drawing.Color.Gainsboro;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.scdule_view.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.scdule_view.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.scdule_view.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column15,
            this.dataGridViewCheckBoxColumn1,
            this.dataGridViewCheckBoxColumn2,
            this.dataGridViewCheckBoxColumn3,
            this.dataGridViewCheckBoxColumn4,
            this.dataGridViewCheckBoxColumn5,
            this.dataGridViewCheckBoxColumn6,
            this.dataGridViewCheckBoxColumn7,
            this.Column8,
            this.dataGridViewButtonColumn1,
            this.dataGridViewTextBoxColumn1,
            this.Column12});
            this.scdule_view.GridColor = System.Drawing.SystemColors.ActiveCaption;
            this.scdule_view.Location = new System.Drawing.Point(6, 30);
            this.scdule_view.Name = "scdule_view";
            this.scdule_view.RowTemplate.Height = 23;
            this.scdule_view.Size = new System.Drawing.Size(700, 609);
            this.scdule_view.TabIndex = 15;
            this.scdule_view.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.scdule_view_CellMouseClick);
            // 
            // top_menu_image
            // 
            this.top_menu_image.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("top_menu_image.ImageStream")));
            this.top_menu_image.TransparentColor = System.Drawing.Color.Transparent;
            this.top_menu_image.Images.SetKeyName(0, "06-Computer-Windows-7-icon.png");
            this.top_menu_image.Images.SetKeyName(1, "Clock-Date-Time-icon.png");
            this.top_menu_image.Images.SetKeyName(2, "Control-Panel-icon100.png");
            this.top_menu_image.Images.SetKeyName(3, "Keyboard-icon.png");
            this.top_menu_image.Images.SetKeyName(4, "Document-Text-icon.png");
            this.top_menu_image.Images.SetKeyName(5, "Actions-document-encrypt-icon_96.png");
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.time_dis);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.next_sc_dis);
            this.panel1.Location = new System.Drawing.Point(696, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(795, 54);
            this.panel1.TabIndex = 363;
            // 
            // time_dis
            // 
            this.time_dis.AutoSize = true;
            this.time_dis.BackColor = System.Drawing.Color.Transparent;
            this.time_dis.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.time_dis.ForeColor = System.Drawing.Color.Blue;
            this.time_dis.Location = new System.Drawing.Point(20, 18);
            this.time_dis.Name = "time_dis";
            this.time_dis.Size = new System.Drawing.Size(116, 19);
            this.time_dis.TabIndex = 364;
            this.time_dis.Text = "프리셋 설정";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(318, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 15);
            this.label3.TabIndex = 363;
            this.label3.Text = "스케쥴 :";
            // 
            // next_sc_dis
            // 
            this.next_sc_dis.AutoSize = true;
            this.next_sc_dis.BackColor = System.Drawing.Color.Transparent;
            this.next_sc_dis.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.next_sc_dis.ForeColor = System.Drawing.Color.Red;
            this.next_sc_dis.Location = new System.Drawing.Point(387, 19);
            this.next_sc_dis.Name = "next_sc_dis";
            this.next_sc_dis.Size = new System.Drawing.Size(162, 18);
            this.next_sc_dis.TabIndex = 362;
            this.next_sc_dis.Text = "다음 예약시간 :  00:00:00";
            // 
            // timer_lcd
            // 
            this.timer_lcd.Enabled = true;
            this.timer_lcd.Interval = 5000;
            this.timer_lcd.Tick += new System.EventHandler(this.timer_lcd_Tick);
            // 
            // clock_dis
            // 
            this.clock_dis.Enabled = true;
            this.clock_dis.Tick += new System.EventHandler(this.clock_dis_Tick);
            // 
            // all_OnOff
            // 
            this.all_OnOff.Interval = 5000;
            this.all_OnOff.Tick += new System.EventHandler(this.all_on_Tick);
            // 
            // Column15
            // 
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column15.DefaultCellStyle = dataGridViewCellStyle15;
            this.Column15.HeaderText = "이름";
            this.Column15.Name = "Column15";
            // 
            // dataGridViewCheckBoxColumn1
            // 
            this.dataGridViewCheckBoxColumn1.HeaderText = "일";
            this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
            this.dataGridViewCheckBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCheckBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewCheckBoxColumn1.Width = 30;
            // 
            // dataGridViewCheckBoxColumn2
            // 
            this.dataGridViewCheckBoxColumn2.HeaderText = "월";
            this.dataGridViewCheckBoxColumn2.Name = "dataGridViewCheckBoxColumn2";
            this.dataGridViewCheckBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCheckBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewCheckBoxColumn2.Width = 30;
            // 
            // dataGridViewCheckBoxColumn3
            // 
            this.dataGridViewCheckBoxColumn3.HeaderText = "화";
            this.dataGridViewCheckBoxColumn3.Name = "dataGridViewCheckBoxColumn3";
            this.dataGridViewCheckBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCheckBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewCheckBoxColumn3.Width = 30;
            // 
            // dataGridViewCheckBoxColumn4
            // 
            this.dataGridViewCheckBoxColumn4.HeaderText = "수";
            this.dataGridViewCheckBoxColumn4.Name = "dataGridViewCheckBoxColumn4";
            this.dataGridViewCheckBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCheckBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewCheckBoxColumn4.Width = 30;
            // 
            // dataGridViewCheckBoxColumn5
            // 
            this.dataGridViewCheckBoxColumn5.HeaderText = "목";
            this.dataGridViewCheckBoxColumn5.Name = "dataGridViewCheckBoxColumn5";
            this.dataGridViewCheckBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCheckBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewCheckBoxColumn5.Width = 30;
            // 
            // dataGridViewCheckBoxColumn6
            // 
            this.dataGridViewCheckBoxColumn6.HeaderText = "금";
            this.dataGridViewCheckBoxColumn6.Name = "dataGridViewCheckBoxColumn6";
            this.dataGridViewCheckBoxColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCheckBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewCheckBoxColumn6.Width = 30;
            // 
            // dataGridViewCheckBoxColumn7
            // 
            this.dataGridViewCheckBoxColumn7.HeaderText = "토";
            this.dataGridViewCheckBoxColumn7.Name = "dataGridViewCheckBoxColumn7";
            this.dataGridViewCheckBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCheckBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewCheckBoxColumn7.Width = 30;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "주중";
            this.Column8.Name = "Column8";
            this.Column8.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Column8.Width = 70;
            // 
            // dataGridViewButtonColumn1
            // 
            this.dataGridViewButtonColumn1.HeaderText = "전체";
            this.dataGridViewButtonColumn1.Name = "dataGridViewButtonColumn1";
            this.dataGridViewButtonColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewButtonColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewButtonColumn1.Width = 70;
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle16;
            this.dataGridViewTextBoxColumn1.HeaderText = "시간";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // Column12
            // 
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column12.DefaultCellStyle = dataGridViewCellStyle17;
            this.Column12.HeaderText = "동작";
            this.Column12.Items.AddRange(new object[] {
            "켜짐(ON)",
            "꺼짐(OFF)",
            "리눅스 play",
            "리눅스 stop",
            "play 1",
            "play 2",
            "play 3",
            "play 4",
            "play 5",
            "play 6",
            "play 7",
            "play 8",
            "play 9"});
            this.Column12.Name = "Column12";
            this.Column12.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // Column18
            // 
            this.Column18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Column18.HeaderText = "진행";
            this.Column18.Name = "Column18";
            this.Column18.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column18.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Column18.Width = 40;
            // 
            // dataGridViewTextBoxColumn2
            // 
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridViewTextBoxColumn2.HeaderText = "이름";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle10;
            this.dataGridViewTextBoxColumn3.HeaderText = "시간";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 120;
            // 
            // dataGridViewTextBoxColumn4
            // 
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle11;
            this.dataGridViewTextBoxColumn4.HeaderText = "동작";
            this.dataGridViewTextBoxColumn4.Items.AddRange(new object[] {
            "켜짐(ON)",
            "꺼짐(OFF)",
            "리눅스 play",
            "리눅스 stop",
            "play 1",
            "play 2",
            "play 3",
            "play 4",
            "play 5",
            "play 6",
            "play 7",
            "play 8",
            "play 9"});
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn4.Width = 120;
            // 
            // 변환시간
            // 
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.변환시간.DefaultCellStyle = dataGridViewCellStyle12;
            this.변환시간.HeaderText = "변환시간";
            this.변환시간.Name = "변환시간";
            // 
            // 모드
            // 
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.모드.DefaultCellStyle = dataGridViewCellStyle13;
            this.모드.HeaderText = "모드";
            this.모드.Name = "모드";
            this.모드.Width = 200;
            // 
            // Main
            // 
            this.ClientSize = new System.Drawing.Size(1489, 984);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "스케쥴 프로그램";
            this.Load += new System.EventHandler(this.Main_Load);
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.sc_edit)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.set_data)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.scdule_view)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Button btn_set;
        private System.Windows.Forms.Button btn_del;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btn_all_on;
        private System.Windows.Forms.Button btn_all_off;
        public System.Windows.Forms.DataGridView sc_edit;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ImageList top_menu_image;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Timer timer_lcd;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button sc_save;
        private System.Windows.Forms.Button sc_del;
        private System.Windows.Forms.Button sc_add;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_CurTime;
        private System.Windows.Forms.TextBox textBox_CurWeek;
        private System.Windows.Forms.DataGridView set_data;
        private System.Windows.Forms.DataGridView scdule_view;
        private System.Windows.Forms.Label time_dis;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label next_sc_dis;
        private System.Windows.Forms.Timer clock_dis;
        private System.Windows.Forms.Timer all_OnOff;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewButtonColumn Column4;
        private System.Windows.Forms.DataGridViewButtonColumn Column5;
        private System.Windows.Forms.DataGridViewButtonColumn Column6;
        private System.Windows.Forms.DataGridViewButtonColumn Column7;
        private System.Windows.Forms.DataGridViewComboBoxColumn DCombo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn2;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn3;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn4;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn5;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn6;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn7;
        private System.Windows.Forms.DataGridViewButtonColumn Column8;
        private System.Windows.Forms.DataGridViewButtonColumn dataGridViewButtonColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewComboBoxColumn Column12;
        private System.Windows.Forms.DataGridViewButtonColumn Column18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn 변환시간;
        private System.Windows.Forms.DataGridViewTextBoxColumn 모드;
    }
}

