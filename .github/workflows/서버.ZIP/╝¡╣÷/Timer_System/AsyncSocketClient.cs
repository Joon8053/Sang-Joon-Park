﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tellus_Manager
{
    public class AsyncSocketClient
    {
        // ManualResetEvent instances signal completion.  
        public ManualResetEvent connectDone = new ManualResetEvent(false);
        public ManualResetEvent sendDone = new ManualResetEvent(false);
        private static ManualResetEvent receiveDone = new ManualResetEvent(false);

        // The response from the remote device.  
        private static String response = String.Empty;

        private static Socket handler_ex;    // 외부에서 사용할 수 있게
        public bool isConnected = false;    // 접속되었는지

        public frmMain myParent { get; set; }

        private bool isWait = false;    // 응답 기다리는지 여부
        public string fvipAddr = "";

        public void StartClient(string _fvipAddr, int fvPort, bool _isWait = false)
        {
            // Connect to a remote device.  
            try
            {
                isWait = _isWait;
                fvipAddr = _fvipAddr;

                IPHostEntry ipHostInfo = Dns.Resolve(Dns.GetHostName());
                IPAddress ipAddress = ipHostInfo.AddressList[0];

                //long longAddress = BitConverter.ToInt32(IPAddress.Parse(fvipAddr).GetAddressBytes(), 0);
                //IPEndPoint remoteEP = new IPEndPoint(longAddress, Convert.ToInt16(fvPort));

                // 20-08-01
                // 위 길이가 길어서 안되는 주소도 있어서 교체함
                string ipAddrStr = _fvipAddr + ":" + fvPort;
                IPEndPoint remoteEP = fn_CreateIPEndPoint(ipAddrStr);

                // Create a TCP/IP socket.  
                Socket client = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

                // Connect to the remote endpoint.  
                client.BeginConnect(remoteEP, new AsyncCallback(ConnectCallback), client);
                connectDone.WaitOne();

                // Write the response to the console.  
                //Console.WriteLine("Response received : {0}", response);

                // Release the socket.  
                //client.Shutdown(SocketShutdown.Both);
                //client.Close();
            }
            catch (Exception e)
            {
                //MessageBox.Show(e.ToString());
                Console.WriteLine(e.ToString());
                myParent.fn_Log(e.ToString());
            }
        }

        //
        // 접속 결과
        private void ConnectCallback(IAsyncResult ar)
        {
            try
            {
                // Retrieve the socket from the state object.  
                //Socket client = (Socket)ar.AsyncState;
                handler_ex = (Socket)ar.AsyncState;

                // Complete the connection.  
                handler_ex.EndConnect(ar);

                Console.WriteLine("Socket connected to {0}", handler_ex.RemoteEndPoint.ToString());

                // Signal that the connection has been made.  
                isConnected = true;
                connectDone.Set();  // 접속 완료

                // 데이터 수신 받을 필요 있을때만 활성화
                if (isWait)
                {
                    Receive(handler_ex);    // 수신 이벤트 실행
                    fn_asyncDisconnect();   // 지정시간 이후에 연결 끊기 3sec

                    receiveDone.WaitOne();
                }
            }
            catch (Exception e)
            {
                string errMsg = "TCP 서버가 켜져있는지, 포트번호가 맞는지 확인하고 재실행 해주세요.";
                Console.WriteLine(errMsg);

                isConnected = false;
                connectDone.Set();  // 접속 안됨

                //MessageBox.Show(ifv_msg, "TCP Connect Error", MessageBoxButtons.OK);
            }
        }

        //private static void Receive(Socket client)
        private void Receive(Socket client)
        {
            try
            {
                // Create the state object.  
                StateObject state = new StateObject();
                state.workSocket = client;

                // Begin receiving the data from the remote device.  
                client.BeginReceive(state.buffer, 0, StateObject.BufferSize, 0, new AsyncCallback(ReceiveCallback), state);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                //myParent.fn_Log(e.ToString());
            }
        }

        //private static void ReceiveCallback(IAsyncResult ar)
        private void ReceiveCallback(IAsyncResult ar)
        {
            try
            {
                // Retrieve the state object and the client socket   
                // from the asynchronous state object.  
                StateObject state = (StateObject)ar.AsyncState;
                Socket client = state.workSocket;

                //if (!client.Available) return;
               
                // Read data from the remote device.  
                int bytesRead = client.EndReceive(ar);

                if (bytesRead > 0)
                {
                    // There might be more data, so store the data received so far.  
                    state.sb.Append(Encoding.ASCII.GetString(state.buffer, 0, bytesRead));
                }

                int byteRemain = state.workSocket.Available;
                if (byteRemain > 0)
                {
                    client.BeginReceive(state.buffer, 0, StateObject.BufferSize, SocketFlags.None, new AsyncCallback(ReceiveCallback), state);
                }
                else
                {
                    // All the data has arrived; put it in response.  
                    if (state.sb.Length >= 1)
                    {
                        response = state.sb.ToString();
                    }
                    else
                        response = "";
                    
                    // Signal that all bytes have been received.
                    receiveDone.Set();
                    Console.WriteLine(response);
                    myParent.fn_Log(">> TCP ret all:: " + response);

                    // 응답 대기면 소켓 종료시킨다
                    if (isWait)
                    {
                        if (response.IndexOf("%1ERST") != -1 
                            || response.IndexOf("%1POWR") != -1)
                        {
                            //string ret = response.Replace("%1ERST=", "");
                            //myParent.fn_Log(">> TCP %1ERST= ret:: " + fvipAddr + " , " + ret);
                            myParent.fn_ReceivePrjData(response, fvipAddr);
                        }

                        // 수신시... 끊기
                        //fn_Disconnect();

                        // 수신시... 계속받기
                        Receive(handler_ex);    // 수신 이벤트 실행
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                //myParent.fn_Log(e.ToString());
            }
        }

        

        //public static void Send(Socket client, String data)
        public void Send(String data)
        {
            try
            {
                Socket client = handler_ex;

                if (data != "" && data != null)
                {
                    // Convert the string data to byte data using ASCII encoding.
                    byte[] byteData = Encoding.ASCII.GetBytes(data);

                    // Begin sending the data to the remote device.  
                    handler_ex.BeginSend(byteData, 0, byteData.Length, 0, new AsyncCallback(SendCallback), client);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                //myParent.fn_Log(e.ToString());
            }

            
        }

        public async void SendTwice(String data)    // 프로젝터만 두번보내는 로직(여기)으로 진행됨
        {
            Send(data);
            await Task.Delay(500);
            Send(data);
        }

        async void fn_asyncDisconnect()     // 모든 소켓은 접속 후 3초 뒤에 자동 종료됨
        {
            await Task.Delay(3000);
            fn_Disconnect();
        }

        public void fn_Disconnect()
        {
            try
            {
                handler_ex.Shutdown(SocketShutdown.Both);
                handler_ex.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                //myParent.fn_Log(e.ToString());
            }
            
        }

        private void SendCallback(IAsyncResult ar)
        {
            try
            {
                // Retrieve the socket from the state object.  
                Socket client = (Socket)ar.AsyncState;

                // Complete sending the data to the remote device.  
                int bytesSent = client.EndSend(ar);
                Console.WriteLine("Sent {0} bytes to server.", bytesSent);

                // Signal that all bytes have been sent.  
                sendDone.Set();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                myParent.fn_Log(e.ToString());
            }
        }

        private IPEndPoint fn_CreateIPEndPoint(string endPoint)
        {
            string[] ep = endPoint.Split(':');
            if (ep.Length != 2) throw new FormatException("Invalid endpoint format");
            IPAddress ip;
            if (!IPAddress.TryParse(ep[0], out ip))
            {
                throw new FormatException("Invalid ip-adress");
            }
            int port;
            if (!int.TryParse(ep[1], NumberStyles.None, NumberFormatInfo.CurrentInfo, out port))
            {
                throw new FormatException("Invalid port");
            }
            return new IPEndPoint(ip, port);
        }


    }
}
