﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Timer_System
{
    public partial class frmInput : Form
    {
        public frmInput()
        {
            InitializeComponent();
        }

        public int iStartHour, iStartMin, iStartSec;
        public frmInput(object pStart)
        {
            InitializeComponent();

            string data1 = Convert.ToString(pStart);

            kkk(data1);
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || e.KeyChar == Convert.ToChar(Keys.Back)))
            {
                e.Handled = true;
            }
        }
        private void kkk(string a)
        {
            string[] adata1 = a.Split(':');
            in_StartHour.Text = adata1[0];
            in_StartMin.Text = adata1[1];
            in_StartSec.Text = adata1[2];

            TimeChange();
        }

        private void TimeChange()
        {
            iStartHour = Convert.ToInt16(in_StartHour.Text);
            iStartMin = Convert.ToInt16(in_StartMin.Text);
            iStartSec = Convert.ToInt16(in_StartSec.Text);
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            if (0 <= Convert.ToInt16(in_StartHour.Text) & Convert.ToInt16(in_StartHour.Text) <= 23)
            {
                if (0 <= Convert.ToInt16(in_StartMin.Text) & Convert.ToInt16(in_StartMin.Text) <= 59)
                {
                    if (0 <= Convert.ToInt16(in_StartSec.Text) & Convert.ToInt16(in_StartSec.Text) <= 59)
                    {
                        int ishour = Convert.ToInt16(in_StartHour.Text);
                        int ismin = Convert.ToInt16(in_StartMin.Text);
                        int issec = Convert.ToInt16(in_StartSec.Text);
                    }
                    else
                    {
                        MessageBox.Show("초 범위 초과");
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("분 범위 초과");
                    return;
                }
            }
            else
            {
                MessageBox.Show("시간 범위 초과");
                return;
            }


            TimeChange();

            this.Close();
        }
    }
}
