﻿namespace Timer_System
{
    partial class Debug
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Debug));
            this.richTextBox_TX = new System.Windows.Forms.RichTextBox();
            this.log_pause = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.clear_btn = new System.Windows.Forms.Button();
            this.richTextBox_RX = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // richTextBox_TX
            // 
            this.richTextBox_TX.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.richTextBox_TX.Location = new System.Drawing.Point(12, 63);
            this.richTextBox_TX.Name = "richTextBox_TX";
            this.richTextBox_TX.Size = new System.Drawing.Size(777, 480);
            this.richTextBox_TX.TabIndex = 0;
            this.richTextBox_TX.Text = "";
            // 
            // log_pause
            // 
            this.log_pause.BackColor = System.Drawing.Color.White;
            this.log_pause.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.log_pause.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.log_pause.FlatAppearance.BorderSize = 2;
            this.log_pause.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.log_pause.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.log_pause.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.log_pause.ForeColor = System.Drawing.Color.Black;
            this.log_pause.Location = new System.Drawing.Point(250, 16);
            this.log_pause.Name = "log_pause";
            this.log_pause.Size = new System.Drawing.Size(113, 37);
            this.log_pause.TabIndex = 358;
            this.log_pause.Text = "일시정지";
            this.log_pause.UseVisualStyleBackColor = false;
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.Color.White;
            this.button27.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button27.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button27.FlatAppearance.BorderSize = 2;
            this.button27.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.button27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button27.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button27.ForeColor = System.Drawing.Color.Black;
            this.button27.Location = new System.Drawing.Point(131, 16);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(113, 37);
            this.button27.TabIndex = 357;
            this.button27.Text = "저장";
            this.button27.UseVisualStyleBackColor = false;
            // 
            // clear_btn
            // 
            this.clear_btn.BackColor = System.Drawing.Color.White;
            this.clear_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.clear_btn.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.clear_btn.FlatAppearance.BorderSize = 2;
            this.clear_btn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.clear_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.clear_btn.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.clear_btn.ForeColor = System.Drawing.Color.Black;
            this.clear_btn.Location = new System.Drawing.Point(12, 16);
            this.clear_btn.Name = "clear_btn";
            this.clear_btn.Size = new System.Drawing.Size(113, 37);
            this.clear_btn.TabIndex = 356;
            this.clear_btn.Text = "내용 지우기";
            this.clear_btn.UseVisualStyleBackColor = false;
            this.clear_btn.Click += new System.EventHandler(this.clear_btn_Click);
            // 
            // richTextBox_RX
            // 
            this.richTextBox_RX.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.richTextBox_RX.Location = new System.Drawing.Point(12, 568);
            this.richTextBox_RX.Name = "richTextBox_RX";
            this.richTextBox_RX.Size = new System.Drawing.Size(777, 285);
            this.richTextBox_RX.TabIndex = 359;
            this.richTextBox_RX.Text = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(14, 548);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 15);
            this.label1.TabIndex = 360;
            this.label1.Text = "RX Data";
            // 
            // Debug
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(801, 865);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.richTextBox_RX);
            this.Controls.Add(this.log_pause);
            this.Controls.Add(this.button27);
            this.Controls.Add(this.richTextBox_TX);
            this.Controls.Add(this.clear_btn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Debug";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Debug";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Debug_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextBox_TX;
        private System.Windows.Forms.Button log_pause;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button clear_btn;
        private System.Windows.Forms.RichTextBox richTextBox_RX;
        private System.Windows.Forms.Label label1;
    }
}