﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Timer_System
{
    public partial class Debug : Form
    {
        public Debug()
        {
            InitializeComponent();
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
        }

        private void Debug_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;  // 종료 막기.
            this.Hide();      // 숨기기
        }
        private void ADD_Text(RichTextBox box, string text, Color color)
        {
            box.SelectionStart = box.TextLength;
            box.SelectionLength = 0;
            box.SelectionColor = color;
            box.AppendText(text);
            box.AppendText(" \r\n");  // line feed
            box.SelectionColor = box.ForeColor;
            box.SelectionStart = box.Text.Length;
            box.ScrollToCaret();

            if (box.TextLength > 100000)
                box.Text = "";
        }


        public void Add_data0(string strData, Color cl)
        {
            ADD_Text(richTextBox_TX, strData, cl);
        }

        public void Add_data(string strData, Color cl)
        {
            try
            {
                this.Invoke(new MethodInvoker(
                    delegate()
                    {
                        Add_data0(strData, cl);
                    }
                )
                );
            }
            catch { }
        }



        private void clear_btn_Click(object sender, EventArgs e)
        {
            richTextBox_TX.Text = "";
            richTextBox_RX.Text = "";
        }

        public void Add_data_rx0(string strData, Color cl)
        {
            ADD_Text(richTextBox_RX, strData, cl);
        }

        public void Add_data_rx(string strData, Color cl)
        {
            /*
            this.Invoke(new MethodInvoker(
                delegate()
                {
                    Add_data_rx0(strData, cl);
                }
            )
            );
             * */
        }


    }
}
