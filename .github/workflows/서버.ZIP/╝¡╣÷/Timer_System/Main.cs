﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.Collections;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security;
using System.Security.Cryptography;
using RHBLibrary.AppCommnucation;
using Newtonsoft.Json;
using RHBLibrary.Tools;
using RHBLibrary.Projector;
using RHBLibrary.Network;
using RHBLibrary.other;
using RHBLibrary.DiD_Monitor;
using RHBLibrary.Video;
using System.Timers;
using RHBLibrary.Log;

namespace Timer_System

{
    public partial class Main : Form
    {
        enum PJ_control {ON,OFF,Satus,Lamp}
        enum MACHINE { PC, PJ, PL }

        public Main()
        {
            InitializeComponent();
        }

        List<clsPowerControl> Device = new List<clsPowerControl>();

        clsLogmanager Logmanager;

        public void LogWrite(string data)
        {
            Logmanager.WriteLine(data);
        }

        #region Other Function
        public void Add_data(string strData, Color cl)
        {
            if (debug != null)                                                                                     //디버그창이 열려있지 않으면
            {
                debug.Add_data(strData, cl);
            }
        }

        public void Add_data2(string strData, Color cl)
        {
            this.Invoke(new MethodInvoker(
                delegate()
                {
                    Add_data(strData, cl);
                }
            )
            );
        }
        private static DateTime Delay(int MS)
        {
            DateTime ThisMoment = DateTime.Now;
            TimeSpan duration = new TimeSpan(0, 0, 0, 0, MS);
            DateTime AfterWards = ThisMoment.Add(duration);

            while (AfterWards >= ThisMoment)
            {
                System.Windows.Forms.Application.DoEvents();
                ThisMoment = DateTime.Now;
            }

            return DateTime.Now;
        }
        Debug debug = new Debug();

        private void btn_Debug_Click(object sender, EventArgs e)
        {
            debug.Show();
        }
        #endregion

        #region Device status File
        private void Save_List()
        {
            if (Device.Count > 0)
            {
                using (StreamWriter writer = File.CreateText("Setting.cfg"))
                {
                    string sData = JsonConvert.SerializeObject(Device);
                    writer.WriteLine(sData);
                }
            }
        }

        private void Load_List()
        {
            string file = "Setting.cfg";
            string file_path = App.Root + file;
            if (File.Exists(file_path) == true)
            {
                using (StreamReader reader = File.OpenText(file))
                {
                    string sData = reader.ReadToEnd();
                    try
                    {
                        List<clsPowerControl> tmp = JsonConvert.DeserializeObject<List<clsPowerControl>>(sData);
                        Device = tmp;
                    }
                    catch (Exception err)
                    {

                    }
                }
            }
        }
        #endregion

        #region Data open
        //프로그램 시작시 DATA 읽어서 초기 그리드 생성START---------------------------------------------------------------------------------------------------------------

        List<clsPJlink_None> devProjector = new List<clsPJlink_None>();
        List<clsBarcoJson> devBarco = new List<clsBarcoJson>();
        List<clsChrisite_HD> devChrisite = new List<clsChrisite_HD>();
        List<clsPCpower> devPC = new List<clsPCpower>();
        clsMadmaper mplayer;
        clsLinuxPlay Lplayer;
        private void grid_load()
        {
            sc_edit.AllowUserToAddRows = false;          //데이타 그리드뷰 마지막 빈줄 삭제
            sc_edit.Rows.Clear();
            devProjector.Clear();
            devPC.Clear();
            Load_List();
            if(Device.Count>0)
            {
                int cnt = 0;
                foreach (clsPowerControl tmp in Device)
                {
                    sc_edit.Rows.Add("설치장소", "192.168.0.001", "00-08-DC-1E-4F-00", "", "", "켜기", "끄기", null, "");      // 데이터 그리드 행 추가
                    sc_edit.Rows[cnt].Cells[0].Value = tmp.Name;
                    sc_edit.Rows[cnt].Cells[1].Value = tmp.IPaddress;
                    sc_edit.Rows[cnt].Cells[2].Value = tmp.MacAddr;
                    sc_edit.Rows[cnt].Cells[7].Value = tmp.Model;
                    sc_edit.Rows[cnt].Cells[10].Value = tmp.PC_Relay;
                    if (tmp.Model == "PC")
                    {
                        clsPCpower dPC = new clsPCpower(tmp.IPaddress, cnt, 10002, tmp.MacAddr); // clsPCpower(tmp.IPaddress, cnt, tmp.MacAddr);
                        dPC.End_check += new EventHandler(pcStatus);
                        try
                        {
                            dPC.Relay = Convert.ToInt16(tmp.PC_Relay);
                        }
                        catch
                        {
                            dPC.Relay = 0;
                        }
                        devPC.Add(dPC);
                    }
                    else if(tmp.Model.Contains("Projector"))
                    {
                        clsPJlink_None tmpLCD = new clsPJlink_None(tmp.IPaddress,0,cnt);
                        tmpLCD.onPowerST += TmpLCD_onPowerST;// += new EventHandler(StatusProjector);
                        devProjector.Add(tmpLCD);
                    }
                    else if (tmp.Model.Contains("Barco"))
                    {
                        clsBarcoJson tmpLCD = new clsBarcoJson(tmp.IPaddress, 9090,100, cnt);
                        tmpLCD.onPowerST += TmpLCD_onPowerST;// += new EventHandler(StatusProjector);
                        devBarco.Add(tmpLCD);
                    }
                    else if (tmp.Model.Contains("Chrisite"))
                    {
                        clsChrisite_HD tmpLCD = new clsChrisite_HD(tmp.IPaddress, 3002, 100, cnt);
                        tmpLCD.onPowerST += TmpLCD_onPowerST;// += new EventHandler(StatusProjector);
                        devChrisite.Add(tmpLCD);
                    }
                    else if (tmp.Model.Contains("리눅스"))
                    {
                        sc_edit.Rows[cnt].Cells[5].Value = "play";
                        sc_edit.Rows[cnt].Cells[6].Value = "Stop";
                        if (Lplayer == null)
                        {
                            Lplayer = new clsLinuxPlay(tmp.IPaddress, 7475);
                        }
                    }
                    else if(tmp.Model == "Player")
                    {
                        sc_edit.Rows[cnt].Cells[5].Value = "play 1";
                        sc_edit.Rows[cnt].Cells[6].Value = "play 2";
                        if (mplayer == null)
                        {
                            mplayer = new clsMadmaper(tmp.IPaddress, 8010);
                        }
                    }

                    if (tmp.Model != "Player")
                    {
                        clsPingThread dPing = new clsPingThread(tmp.IPaddress, cnt);
                        dPing.End_check += new EventHandler(PingCheck);
                    }
                    cnt++;
                }                                                                                          //읽기 스트림 닫기
            }
        }



        #endregion

        #region PC status
        private void Display_System(int id, string cpu,string ram)
        {
            if (Edit_mode == false)
            {
                sc_edit.Rows[id].Cells[8].Value = cpu;
                sc_edit.Rows[id].Cells[9].Value = ram;
            }
        }
        private void pcStatus(object sender, EventArgs e)
        {
            clsPCpower tmp = (clsPCpower)sender;
            int id = tmp.ID;
            Display_Power(id, true);
            Display_System(id, tmp.mainSystem.CPU, tmp.mainSystem.MeM);
        }
        #endregion

        #region Projector Stauts
        byte lcnt = 0;
        private void Display_Power(int id, bool mode)
        {
            if (Edit_mode == false)
            {
                if (mode)
                    sc_edit.Rows[id].Cells[4].Style.BackColor = Color.Lime;
                else
                    sc_edit.Rows[id].Cells[4].Style.BackColor = Color.White;
            }
        }

        private void TmpLCD_onPowerST(int ID, bool flg)
        {
            int id =ID;
            Display_Power(id, flg);
            sc_edit.Rows[id].Cells[9].Value = "Check" + lcnt.ToString();
            lcnt++;
        }

        private void timer_lcd_Tick(object sender, EventArgs e)
        {
            if (devProjector.Count > 0)
            {
                foreach (clsPJlink_None tmp in devProjector)
                {
                    tmp.PowerCheck();
                }
            }
            if (devBarco.Count > 0)
            {
                foreach (clsBarcoJson tmp in devBarco)
                {
                    tmp.PowerCheck();
                }
            }
            if (devChrisite.Count > 0)
            {
                foreach (clsChrisite_HD tmp in devChrisite)
                {
                    tmp.PowerCheck();
                }
            }
        }

        #endregion

        #region Ping Check.
        private void SetPC (int id,bool mode)
        {
            if(devPC.Count >0)
            {
                foreach(clsPCpower tmp in devPC)
                {
                    if (tmp.ID == id)
                    {
                        tmp.enSystem = mode;
                        Display_Power(id, tmp.isConnected);
                        break;
                    }
                }
            }
        }
        private void SetProjector(int id, bool mode)
        {
            if (devProjector.Count > 0)
            {
                foreach (clsPJlink_None tmp in devProjector)
                {
                    if (tmp.ID == id)
                    {
                    //    tmp.enSystem = mode;
                        break;
                    }
                }
            }
        }
        private void Display_Ping(int id, bool mode)
        {
            if (Edit_mode == false)
            {
                if (mode)
                    sc_edit.Rows[id].Cells[3].Style.BackColor = Color.Lime;
                else
                    sc_edit.Rows[id].Cells[3].Style.BackColor = Color.White;
                // pc check.
                string stmp = sc_edit.Rows[id].Cells[7].Value.ToString();
                if (stmp=="PC")
                {
                    SetPC(id, mode);
                }
                else if(stmp=="Projector")
                {
                    SetProjector(id, mode);
                }
            }
        }
        private void PingCheck(object sender, EventArgs e)
        {
            clsPingThread tmp = (clsPingThread)sender;
            int id = Convert.ToInt16(tmp.ID);
            Display_Ping(id, tmp.status);
        }
        #endregion

        #region Start
        clsRCplayer mp3_1, mp3_2;
        private void Main_Load(object sender, EventArgs e)
        {
            Logmanager = new clsLogmanager("Schedule", null);
            LogWrite("프로그램 시작");
            grid_load();
            timer_lcd.Enabled = true;

            try
            {
           //     Audio1_232.Open();
            //    Audio2_232.Open();
             //   pc_232.Open();
            }
            catch
            {
                MessageBox.Show("시리얼 포트를 점검 하세요..");
            }
            System.Timers.Timer aTimer = new System.Timers.Timer();
            aTimer.Elapsed += new ElapsedEventHandler(OnTimedEvent);
            aTimer.Interval = 500;
            aTimer.Enabled = true;
            grid_load2();
        }



        private void Set_Btn_Free()
        {
            btn_add.Enabled = true;
            btn_del.Enabled = true;
            btn_save.Enabled = true;
        }

        private void Set_Btn_Unfree()
        {
            btn_add.Enabled = false;
            btn_del.Enabled = false;
            btn_save.Enabled = false;
        }
        #endregion

        #region Data Edit
        private bool Edit_mode = false;
        private void btn_set_Click(object sender, EventArgs e)
        {
            if (btn_set.BackColor != Color.Red)
            {
                sc_edit.ReadOnly = false;
                btn_set.BackColor = Color.Red;
                Edit_mode = true;
                Set_Btn_Free();
            }
            else
            {
                sc_edit.ReadOnly = true;
                btn_set.BackColor = Color.White;
                Edit_mode = false;
                grid_load();
            }
        }
        private void btn_add_Click(object sender, EventArgs e)
        {
            if (Edit_mode)
            {
                sc_edit.Rows.Add("설치장소", "192.168.0.001", "00-08-DC-1E-4F-00", "", "", "켜기", "끄기", "PC", "");      // 데이터 그리드 행 추가
                sc_edit.CurrentCell = sc_edit.Rows[sc_edit.RowCount - 1].Cells[0];
                //sc_edit.Rows[sc_edit.RowCount - 1].Cells[7].tem
            }
        }

        private void btn_del_Click(object sender, EventArgs e)
        {
            int i = sc_edit.CurrentCellAddress.Y;
            if (i >= 0)
            {
                if (MessageBox.Show("현재 단말을 삭제 하시겠습니까?", "단말 삭제 확인", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    sc_edit.Rows.Remove(sc_edit.Rows[i]);
                }
            }
        }
        private void btn_save_Click(object sender, EventArgs e)
        {
            if (sc_edit.Rows.Count > 0)
            {
                Device.Clear();
                for (int count = 0; count < sc_edit.Rows.Count; count++)
                {
                    clsPowerControl tmp = new clsPowerControl();

                    tmp.Name = string.Format("{0}", sc_edit.Rows[count].Cells[0].Value);
                    tmp.IPaddress = string.Format("{0}", sc_edit.Rows[count].Cells[1].Value);
                    tmp.MacAddr = string.Format("{0}", sc_edit.Rows[count].Cells[2].Value);
                    tmp.Model = string.Format("{0}", sc_edit.Rows[count].Cells[7].Value);
                    tmp.PC_Relay = string.Format("{0}", sc_edit.Rows[count].Cells[10].Value);
                    Device.Add(tmp);
                }
                Save_List();
            }
            else
            {
                File.Delete("Setting.cfg");
            }
            Application.Exit();
            Application.Restart();
        }
        #endregion

        #region Power Control

        private void PCpower(int id, bool mode)
        {
            if (devPC.Count > 0)
            {
                foreach (clsPCpower tmp in devPC)
                {
                    if (tmp.ID == id)
                    {
                        if (mode)
                        {
                            tmp.PCon();
                        }
                        else
                            tmp.PCoff();
                        break;
                    }
                }
            }
        }

        private void LCDpower(int id,bool mode)
        {
            if (devProjector.Count > 0)
            {
                foreach (clsPJlink_None tmp in devProjector)
                {
                    if (tmp.ID == id)
                    {
                        if (mode)
                            tmp.PowerON();
                        else
                            tmp.PowerOff();
                        break;
                    }
                }
            }
        }
        private void Barcopower(int id, bool mode)
        {
            if (devBarco.Count > 0)
            {
                foreach (clsBarcoJson tmp in devBarco)
                {
                    if (tmp.ID == id)
                    {
                        if (mode)
                            tmp.Power_on();
                        else
                            tmp.Power_off();
                        break;
                    }
                }
            }
        }

        private void Chrisitepower(int id, bool mode)
        {
            if (devChrisite.Count > 0)
            {
                foreach (clsChrisite_HD tmp in devChrisite)
                {
                    if (tmp.ID == id)
                    {
                        if (mode)
                            tmp.Power_on();
                        else
                            tmp.Power_off();
                        break;
                    }
                }
            }
        }

        private void power_control(int id, bool mode)
        {
            //  strLog = string.Format("장비 {0}번 OFF", id + 1);
            //  Add_data2(strLog, Color.White);
            if (Convert.ToString(sc_edit.Rows[id].Cells[7].Value) == "PC")
            {
                PCpower(id, mode);
            }
            else if (Convert.ToString(sc_edit.Rows[id].Cells[7].Value) == "Projector")
            {
                LCDpower(id, mode);
            }
            else if (Convert.ToString(sc_edit.Rows[id].Cells[7].Value).Contains("Barco Projector"))
            {
                Barcopower(id, mode);
            }
            else if (Convert.ToString(sc_edit.Rows[id].Cells[7].Value).Contains("Chrisite"))
            {
                Chrisitepower(id, mode);
            }
            else if (Convert.ToString(sc_edit.Rows[id].Cells[7].Value).Contains("리눅스"))
            {
                if (mode == true)
                    Lplayer.PlayControl(true);
                else
                    Lplayer.PlayControl(false);
            }
            else
            {
                if(mplayer != null)
                {
                    if(mode == true)
                        mplayer.SendKey(1);
                    else
                        mplayer.SendKey(2);
                }
            }
        }

        private void sc_edit_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            int row_value;
            int column_value;

            column_value = Convert.ToInt16(e.ColumnIndex);                                                                  //열의 값을 가져옴
            row_value = Convert.ToInt16(e.RowIndex);                                                                       //행의 값을 가져옴

            if (e.ColumnIndex == 5)  // ON 클릭
            {
                power_control(row_value, true);
            }
            else if (e.ColumnIndex == 6)    //OFF클릭
            {
                power_control(row_value, false);
            }
        }


        private void power_display(bool mode)
        {
            for (int cnt = 0; cnt < sc_edit.Rows.Count; cnt++)
            {
                if (Convert.ToString(sc_edit.Rows[cnt].Cells[7].Value) == "Projector")
                {
                    LCDpower(cnt, mode);
                    string ss = string.Format("LCD no={0},mode={1}", cnt, mode);
                    Console.WriteLine(ss);
                }
                if (Convert.ToString(sc_edit.Rows[cnt].Cells[7].Value) == "Barco Projector")
                {
                    Barcopower(cnt, mode);
                    string ss = string.Format("Barco no={0},mode={1}", cnt, mode);
                    Console.WriteLine(ss);
                }
                if (Convert.ToString(sc_edit.Rows[cnt].Cells[7].Value).Contains("Chrisite"))
                {
                    Chrisitepower(cnt, mode);
                    string ss = string.Format("Chrisite no={0},mode={1}", cnt, mode);
                    Console.WriteLine(ss);
                }
            }
        }

        private void power_PC(bool mode)
        {
            for (int cnt = 0; cnt < sc_edit.Rows.Count; cnt++)
            {
                if (Convert.ToString(sc_edit.Rows[cnt].Cells[7].Value) == "PC")
                {
                    PCpower(cnt, mode);
                    string ss = string.Format("PC no={0},mode={1}", cnt, mode);
                    Console.WriteLine(ss);
                }
            }
        }

        private void SC_allOn()
        {
            all_on_cnt = 0;
            all_OnOff.Enabled = true;
            flg_AllonOff = true;
            power_display(flg_AllonOff);
        }

        private void SC_allOff()
        {
            all_on_cnt = 0;
            all_OnOff.Enabled = true;
            flg_AllonOff = false;
            power_PC(flg_AllonOff);
        }


        int all_on_cnt = 0;
        bool flg_AllonOff = true;
        private void all_on_Tick(object sender, EventArgs e)
        {
            all_on_cnt++;
            if (all_on_cnt < 4)
            {
                if (flg_AllonOff)
                    power_display(flg_AllonOff);
                else
                    power_PC(flg_AllonOff);
            }
            else if(all_on_cnt==11)
            {
                all_OnOff.Enabled = false;
            }
            else if (all_on_cnt > 8)
            {
                if (flg_AllonOff==false)
                    power_display(flg_AllonOff);
                else
                    power_PC(flg_AllonOff);
            }
        }

        private void btn_all_on_Click(object sender, EventArgs e)
        {
            for (int cnt = 0; cnt < sc_edit.Rows.Count; cnt++)
            {
                power_control(cnt, true);
            }
        }

        private void btn_all_off_Click(object sender, EventArgs e)
        {
            for (int cnt = 0; cnt < sc_edit.Rows.Count; cnt++)
            {
                power_control(cnt, false);
            }
            System.Threading.Thread.Sleep(500);
            for (int cnt = 0; cnt < sc_edit.Rows.Count; cnt++)
            {
                if (Convert.ToString(sc_edit.Rows[cnt].Cells[7].Value) != "PC")
                {
                    power_control(cnt, false);
                }
            }

        }


        private void btn_all_off_Click0(object sender, EventArgs e)
        {
            if (MessageBox.Show("전체 장비를 OFF 하시겠습니까?", "OFF 확인", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                btn_all_off_Click(null, null);
            }
        }
        #endregion



        private void grid_load2()
        {
            scdule_view.AllowUserToAddRows = false;          //데이타 그리드뷰 마지막 빈줄 삭제
            set_data.AllowUserToAddRows = false;

            string s1 = Application.StartupPath + "\\Schedule\\time.cfg";
            bool file_check = File.Exists(s1);                                                      //해당 경로에 해당 파일이 있는지 유무확인파일
            //bool[] file_use = new bool[SC_max];

            if (file_check == true)                                                                 //해당 경로에 해당 파일이 있다면
            {
                int cnt = 0;
                StreamReader sr = new StreamReader(s1, Encoding.Default);                           //읽기 스트림 열기
                do
                {
                    string ss = sr.ReadLine();                                                      //list에 한줄씩 읽어와
                    if (ss != "" & ss != null)
                    {
                        string[] aData = ss.Split(',');                                                 //스트링형 배열에 ',' 단위로 끊어서 저장
                        scdule_view.Rows.Add("", false, false, false, false, false, false, false, "주중", "전체", "00:00:00", "");      // 데이터 그리드 행 추가
                        scdule_view.Rows[cnt].Cells[0].Value = aData[0];
                        for (int j = 1; j < 8; j++)
                        {
                            if (aData[j] == "T")
                            {
                                scdule_view.Rows[cnt].Cells[j].Value = true;
                            }
                            else
                            {
                                scdule_view.Rows[cnt].Cells[j].Value = false;
                            }
                        }

                        scdule_view.Rows[cnt].Cells[10].Value = aData[8];
                        scdule_view.Rows[cnt].Cells[11].Value = aData[9];

                        cnt++;
                    }
                    else
                    {
                        break;
                    }
                } while (!sr.EndOfStream);
                sr.Close();                                                                                            //읽기 스트림 닫기
            }
            convert_sc_Click(null, null);
        }
        private void sc_del_Click(object sender, EventArgs e)
        {
            try
            {
                int i = scdule_view.CurrentCellAddress.Y;
                if (i >= 0)
                {
                    if (MessageBox.Show("현재 스케쥴을 삭제 하시겠습니까?", "스케쥴 삭제 확인", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        scdule_view.Rows.Remove(scdule_view.Rows[i]);
                    }
                }
            }
            catch
            {

            }
        }

        private void sc_save_Click(object sender, EventArgs e)
        {
            Folder.Create("Schedule");
            string s1 = Application.StartupPath + "\\Schedule\\time.cfg";

            StreamWriter outstream = new StreamWriter(new FileStream(s1, FileMode.Create), Encoding.Default);              //쓰기 스트림 열기

            for (int count = 0; count < scdule_view.Rows.Count; count++)
            {
                string ss = "";
                ss += string.Format("{0},", scdule_view.Rows[count].Cells[0].Value);

                for (int cnt = 1; cnt < 8; cnt++)
                {
                    if (Convert.ToBoolean(scdule_view.Rows[count].Cells[cnt].Value) == true)
                    {
                        ss += "T,";
                    }
                    else
                    {
                        ss += "F,";
                    }
                }

                ss += string.Format("{0},", scdule_view.Rows[count].Cells[10].Value);  //start time
                ss += string.Format("{0},", scdule_view.Rows[count].Cells[11].Value);  //input name
                outstream.WriteLine(ss);
            }
            outstream.Close();
            convert_sc_Click(null, null);
        }

        private void sc_add_Click(object sender, EventArgs e)
        {
            scdule_view.Rows.Add("", false, false, false, false, false, false, false, "주중", "전체", "00:00:00", "켜짐(ON)");      // 데이터 그리드 행 추가
            scdule_view.CurrentCell = scdule_view.Rows[scdule_view.RowCount - 1].Cells[0];
        }


        private void convert_sc_Click(object sender, EventArgs e)
        {
            int line = 0;
            string strTime = "";

            set_data.Rows.Clear();

            int week = Convert.ToInt16(DateTime.Now.DayOfWeek);
            string[] strWeek = { "일", "월", "화", "수", "목", "금", "토" };
            textBox_CurWeek.Text = strWeek[week];

            int sumTime = DateTime.Now.Hour * 3600 + DateTime.Now.Minute * 60 + DateTime.Now.Second;        //현재시간

            int tmpTime;
            for (int count = 0; count < scdule_view.Rows.Count; count++)
            {
                if (Convert.ToBoolean(scdule_view.Rows[count].Cells[week + 1].Value) == true)
                {
                    // start time
                    set_data.Rows.Add();      // 데이터 그리드 행 추가

                    set_data.Rows[line].Cells[1].Value = scdule_view.Rows[count].Cells[0].Value;  //이름
                    set_data.Rows[line].Cells[2].Value = scdule_view.Rows[count].Cells[10].Value;  // 시간

                    set_data.Rows[line].Cells[3].Value = scdule_view.Rows[count].Cells[11].Value;  // 입력

                    strTime = Convert.ToString(set_data.Rows[line].Cells[2].Value);
                    tmpTime = ConvertTime(strTime);

                    set_data.Rows[line].Cells[4].Value = Convert.ToString(tmpTime);

                    if (sumTime < tmpTime)
                    {
                        set_data.Rows[line++].Cells[5].Value = "대기";
                    }
                    else
                    {
                        set_data.Rows[line++].Cells[5].Value = "무시됨";
                    }

                    set_data.Sort(set_data.Columns[2], ListSortDirection.Ascending);
                }
            }

            // active position
            pos_Scdule();
        }


        private int ConvertTime(string strTime)
        {
            int iTime = 0;
            string[] adata1 = strTime.Split(':');
            iTime = Convert.ToInt16(adata1[0]) * 3600;
            iTime = iTime + Convert.ToInt16(adata1[1]) * 60;
            iTime = iTime + Convert.ToInt16(adata1[2]);

            return iTime;
        }

        class NEXT_SCDULE
        {
            public int Time;
            public int pos;
            public bool Start;
            public bool Reset;
        }
        NEXT_SCDULE next = new NEXT_SCDULE();

        private void clock_dis_Tick(object sender, EventArgs e)
        {
            int week = Convert.ToInt16(DateTime.Now.DayOfWeek);
            string[] ss = { "일", "월", "화", "수", "목", "금", "토" };
            time_dis.Text = string.Format("{4}/{5:D2}/{6:D2}({3})  {0:D2}:{1:D2}:{2:D2}", DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second, ss[week], DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day);      //현재 날짜,시간,요일 표시
        }

        private void pos_Scdule()
        {
            string ss = "대기";
            next.Start = false;
            int count;
            for (count = 0; count < set_data.Rows.Count; count++)
            {
                if (Convert.ToString(set_data.Rows[count].Cells[5].Value) == ss)
                {
                    set_data.Rows[count].Cells[0].Value = "<>";
                    next.Time = Convert.ToInt32(set_data.Rows[count].Cells[4].Value);
                    set_data.Rows[count].Cells[0].Style.BackColor = Color.Red;
                    next.pos = count;
                    next.Start = true;
                    // text display...
                    string strMode = "";

                    next_sc_dis.Text = string.Format("{0}_{1} 일정 예정되어 있습니다.  {2}", set_data.Rows[count].Cells[1].Value, strMode, set_data.Rows[count].Cells[2].Value);
                    break;
                }
                else
                {
                    set_data.Rows[count].Cells[0].Value = "";
                    set_data.Rows[count].Cells[0].Style.BackColor = Color.White;
                }
            }
            if (count == set_data.Rows.Count)
            {
                next_sc_dis.Text = "다음 일정이 없습니다.";
                next.Time = 0;
            }
        }

        private void OnTimedEvent(object sender, ElapsedEventArgs e)
        {
            int sumTime = DateTime.Now.Hour * 3600 + DateTime.Now.Minute * 60 + DateTime.Now.Second;
            try
            {
                this.Invoke(new MethodInvoker(
                    delegate ()

                    {
                        Scdule_Action(sumTime);
                    }));
            }
            catch { };
        }

        private void scdule_view_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int row_value;
            int column_value;
            bool check;

            column_value = Convert.ToInt16(e.ColumnIndex);                                                                  //열의 값을 가져옴
            row_value = Convert.ToInt16(e.RowIndex);                                                                       //행의 값을 가져옴

            if (e.ColumnIndex == 8)  // 주중 클릭
            {
                if (Convert.ToBoolean(scdule_view.Rows[e.RowIndex].Cells[2].Value) == true)
                {
                    check = false;
                }
                else
                {
                    check = true;
                }
                for (int i = 2; i < 7; i++)
                {
                    scdule_view.Rows[e.RowIndex].Cells[i].Value = check;
                }
            }
            else if (e.ColumnIndex == 9)  // 전체 클릭
            {
                if (Convert.ToBoolean(scdule_view.Rows[e.RowIndex].Cells[1].Value) == true)
                {
                    check = false;
                }
                else
                {
                    check = true;
                }
                for (int i = 1; i < 8; i++)
                {
                    scdule_view.Rows[e.RowIndex].Cells[i].Value = check;
                }
            }
            else if (10 == e.ColumnIndex)                                                //컬럼값에 해당하는 셀의 데이터 변경
            {
                if (e.RowIndex >= 0)
                {
                    object data1 = scdule_view.Rows[e.RowIndex].Cells[10].Value;

                    frmInput dat_input = new frmInput(data1);
                    dat_input.ShowDialog();

                    scdule_view.Rows[e.RowIndex].Cells[10].Value = string.Format("{0:d2}:{1:d2}:{2:d2}", dat_input.iStartHour, dat_input.iStartMin, dat_input.iStartSec);

                    scdule_view.Sort(scdule_view.Columns[10], ListSortDirection.Ascending);                                 //해당 컬럼라인을 오름차순 정렬
                }
            }
        }


        private void TimeAction()
        {
            if (set_data.Rows[next.pos].Cells[3].Value.ToString().Contains("ON"))
            {
                set_data.Rows[next.pos].Cells[5].Value = "실행완료(ON)";
                LogWrite("실행완료(ON)");
                SC_allOn();
            }
            else if (set_data.Rows[next.pos].Cells[3].Value.ToString().Contains("OFF"))
            {
                set_data.Rows[next.pos].Cells[5].Value = "실행완료(OFF)";
                LogWrite("실행완료(OFF)");
                SC_allOff();
            }
            else if (set_data.Rows[next.pos].Cells[3].Value.ToString().Contains("리눅스"))
            {
                if (set_data.Rows[next.pos].Cells[3].Value.ToString().Contains("play"))
                {
                    set_data.Rows[next.pos].Cells[5].Value = "리눅스 play";
                    LogWrite("리눅스 play");
                    if (Lplayer != null)
                        Lplayer.PlayControl(true);
                }
                else
                {
                    set_data.Rows[next.pos].Cells[5].Value = "리눅스 stop";
                    LogWrite("리눅스 stop");
                    if (Lplayer != null)
                        Lplayer.PlayControl(false);
                }

            }
            else if (set_data.Rows[next.pos].Cells[3].Value.ToString().Contains("play"))
            {
                set_data.Rows[next.pos].Cells[5].Value = "실행완료(play)";
                LogWrite("실행완료(play)");
                string ss = set_data.Rows[next.pos].Cells[3].Value.ToString();
                ss = ss.Replace("play ", "");
                int no = Convert.ToInt16(ss);
                if (mplayer != null)
                    mplayer.SendKey(no);
            }
        }

        private void Scdule_Action(int iTime)
        {
            textBox_CurTime.Text = iTime.ToString();
            
            if ((next.Start == true) & (iTime >= next.Time))
            {
                int saveTime = next.Time;
                TimeAction();
                pos_Scdule();
                while (next.Time == saveTime) // 동일 시간 동작.
                {
                    saveTime = next.Time;
                    TimeAction();
                    pos_Scdule();
                }
            }
            else
            {

            }

            string tmpTime = string.Format("{0:D2}:{1:D2}:{2:D2}", DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);
            pos_Scdule();

            // auto reset  0시에 다시 읽기 (10초이내에 한번 동작 시스템 부하로 0일때 실행하지 않고 10이하로 처리함)
            if (iTime < 10)
            {
                if (next.Reset == false)  // 중복실행 방지
                {
                    next.Reset = true;
                    convert_sc_Click(null, null);
                }
            }
            else
            {
                next.Reset = false;
            }
        }
    }
}
