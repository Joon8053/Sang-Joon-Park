﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tellus_Manager
{
    public class AsyncSocketClientSend: IDisposable
    {
        // ManualResetEvent instances signal completion.  
        public ManualResetEvent connectDone = new ManualResetEvent(false);
        public ManualResetEvent sendDone = new ManualResetEvent(false);
        private static ManualResetEvent receiveDone = new ManualResetEvent(false);
        //private ManualResetEvent receiveDone = new ManualResetEvent(false);

        // The response from the remote device.  
        private static String response = String.Empty;
        //private String response = String.Empty;

        //private static Socket handler_ex;    // ** 외부에서 사용할 수 있게
        private Socket handler_ex;    // 외부에서 사용할 수 있게
        public bool isConnected = false;    // 접속되었는지

        public frmMain myParent { get; set; }

        private string fvipAddr = "";

        private int fv_MaxCnt = 10;
        private int fv_Interval = 1000;

        private int curCnt = 0;

        private bool isRcvDone = false;     // 수신 정상 메시지 받았는지 여부
        //
        //
        public void Dispose()
        {
            Console.WriteLine(">> Dispose :: AsyncSocketClientSend << ");
        }
        //
        //
        //
        public void StartClient(frmMain _myParent, string _fvipAddr, int fvPort, string msgs)
        {
            Console.WriteLine(">> Create :: AsyncSocketClientSend << ");

            // Connect to a remote device.  
            try
            {
                fvipAddr = _fvipAddr;
                myParent = _myParent;   // parent

                // 재전송 값들 가져오고
                fv_MaxCnt = myParent.fv_RtoTimeOutCnt_PRJ;
                fv_Interval = myParent.fv_RtoInterval_PRJ;


                IPHostEntry ipHostInfo = Dns.Resolve(Dns.GetHostName());
                IPAddress ipAddress = ipHostInfo.AddressList[0];

                // 20-08-01
                // 위 길이가 길어서 안되는 주소도 있어서 교체함
                string ipAddrStr = _fvipAddr + ":" + fvPort;
                IPEndPoint remoteEP = fn_CreateIPEndPoint(ipAddrStr);

                // Create a TCP/IP socket.  
                Socket client = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

                // Connect to the remote endpoint.  
                client.BeginConnect(remoteEP, new AsyncCallback(ConnectCallback), client);
                connectDone.WaitOne();

                // Write the response to the console.  
                //Console.WriteLine("Response received : {0}", response);

                // Release the socket.  
                //client.Shutdown(SocketShutdown.Both);
                //client.Close();

                // 1. 연결
                // 2. 보내기
                fn_asyncSend(msgs);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                myParent.fn_Log(e.ToString());
            }
        }
        //
        //
        // add 20-10-15
        // 
        private async void fn_asyncSend(string msgs)
        {
            Console.WriteLine(">> try Tcp send :: " + fvipAddr + ", " + msgs);
            myParent.fn_Log(">> try Tcp send :: " + fvipAddr + ", " + msgs);

            await Task.Delay(500);
            fn_SendTwice(msgs);

            if (myParent.isRtoUseYn_PRJ == true)     // 재전송 사용여부 ON 확인
            {
                await Task.Delay(fv_Interval);    // 정한 간격만큼 기다리고 1.연결확인 2.카운트확인
                //
                // 전송 후 응답이 왔으면 그만 보내고 안왔으면 카운트 증가시키면서 재귀호출
                if (!isRcvDone)
                {
                    curCnt++;
                    if (curCnt < fv_MaxCnt)
                    {
                        Console.WriteLine(">> Tcp send curCnt :: " + curCnt);
                        myParent.fn_Log(">> Tcp send curCnt :: " + curCnt);

                        fn_asyncSend(msgs);
                    }
                    else
                    {
                        isRcvDone = true;
                        fn_asyncDisconnect();   // 지정시간 이후에 연결 끊기 3sec

                        Console.WriteLine(">> Tcp send curCnt :: 최대카운트만큼 모두 보냄, 종료");
                        myParent.fn_Log(">> Tcp send curCnt :: 최대카운트만큼 모두 보냄, 종료");
                    }
                }
                else
                {
                    fn_asyncDisconnect();   // 지정시간 이후에 연결 끊기 3sec

                    Console.WriteLine(">> Tcp send rcv :: 수신완료 메시지 받음, 종료");
                    myParent.fn_Log(">> Tcp send rcv :: 수신완료 메시지 받음, 종료");
                }

            }
        }
        //
        // 접속 결과
        private void ConnectCallback(IAsyncResult ar)
        {
            try
            {
                // Retrieve the socket from the state object.  
                handler_ex = (Socket)ar.AsyncState;

                // Complete the connection.  
                handler_ex.EndConnect(ar);

                Console.WriteLine(":: 실제 접속된 결과:: Socket connected to {0}", handler_ex.RemoteEndPoint.ToString());

                // Signal that the connection has been made.  
                isConnected = true;
                connectDone.Set();  // 접속 완료

                // 데이터 수신
                Receive(handler_ex);    // 수신 이벤트 실행
                //fn_asyncDisconnect();   // 지정시간 이후에 연결 끊기 3sec

                receiveDone.WaitOne();
            }
            catch (Exception e)
            {
                string errMsg = "TCP 서버가 켜져있는지, 포트번호가 맞는지 확인하고 재실행 해주세요.";
                Console.WriteLine(errMsg);

                isConnected = false;
                connectDone.Set();  // 접속 안됨
                //MessageBox.Show(ifv_msg, "TCP Connect Error", MessageBoxButtons.OK);
            }
        }

        //private static void Receive(Socket client)
        private void Receive(Socket client)
        {
            try
            {
                // Create the state object.  
                StateObject state = new StateObject();
                state.workSocket = client;

                // Begin receiving the data from the remote device.  
                client.BeginReceive(state.buffer, 0, StateObject.BufferSize, 0, new AsyncCallback(ReceiveCallback), state);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                //myParent.fn_Log(e.ToString());
            }
        }

        //private static void ReceiveCallback(IAsyncResult ar)
        private void ReceiveCallback(IAsyncResult ar)
        {
            try
            {
                // Retrieve the state object and the client socket   
                // from the asynchronous state object.  
                StateObject state = (StateObject)ar.AsyncState;
                Socket client = state.workSocket;

                //if (!client.Available) return;
               
                // Read data from the remote device.  
                int bytesRead = client.EndReceive(ar);

                if (bytesRead > 0)
                {
                    // There might be more data, so store the data received so far.  
                    state.sb.Append(Encoding.ASCII.GetString(state.buffer, 0, bytesRead));
                }

                int byteRemain = state.workSocket.Available;
                if (byteRemain > 0)
                {
                    client.BeginReceive(state.buffer, 0, StateObject.BufferSize, SocketFlags.None, new AsyncCallback(ReceiveCallback), state);
                }
                else
                {
                    // All the data has arrived; put it in response.  
                    if (state.sb.Length >= 1)
                    {
                        response = state.sb.ToString();
                    }
                    else
                        response = "";
                    
                    // Signal that all bytes have been received.
                    receiveDone.Set();
                    Console.WriteLine(response);
                    myParent.fn_Log(">> TCP ret all:: " + response);

                    // 응답 대기면 소켓 종료시킨다
                    if (response.IndexOf("%1ERST") != -1 
                        || response.IndexOf("%1POWR") != -1
                        || response.IndexOf("PJLINK") != -1)
                    {
                        //string ret = response.Replace("%1ERST=", "");
                        //myParent.fn_Log(">> TCP %1ERST= ret:: " + fvipAddr + " , " + ret);

                        // 수신 완료 처리되면 플래그 변경 (내부에서 처리)
                        isRcvDone = true;

                        //myParent.fn_ReceivePrjData(response, fvipAddr);
                    }

                    // 수신시... 끊기
                    //fn_Disconnect();

                    // 수신시... 계속받기
                    Receive(handler_ex);    // 수신 이벤트 실행
                    
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                //myParent.fn_Log(e.ToString());
            }
        }

        

        //public static void Send(Socket client, String data)
        private void fn_Send(String data)
        {
            try
            {
                Socket client = handler_ex;

                //handler_ex.RemoteEndPoint.ToString();
                // 어디에 보내는지 아이피 확인
                //Console.WriteLine(">> 아이피 >>>>>>>>>>>>  " + client.LocalEndPoint.ToString());
                Console.WriteLine(">> 아이피 >>>>>>>>>>>>  " + client.RemoteEndPoint.ToString());


                if (data != "" && data != null)
                {
                    // Convert the string data to byte data using ASCII encoding.
                    byte[] byteData = Encoding.ASCII.GetBytes(data);

                    // Begin sending the data to the remote device.  
                    handler_ex.BeginSend(byteData, 0, byteData.Length, 0, new AsyncCallback(SendCallback), client);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                //myParent.fn_Log(e.ToString());
            }

            
        }

        private async void fn_SendTwice(String data)    // 프로젝터만 두번보내는 로직(여기)으로 진행됨
        {
            fn_Send(data);
            await Task.Delay(500);
            fn_Send(data);
        }

        async void fn_asyncDisconnect()     // 모든 소켓은 접속 후 3초 뒤에 자동 종료됨
        {
            await Task.Delay(3000);
            fn_Disconnect();
        }

        private void fn_Disconnect()
        {
            try
            {
                handler_ex.Shutdown(SocketShutdown.Both);
                handler_ex.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                //myParent.fn_Log(e.ToString());
            }
            
        }

        private void SendCallback(IAsyncResult ar)
        {
            try
            {
                // Retrieve the socket from the state object.  
                Socket client = (Socket)ar.AsyncState;

                // Complete sending the data to the remote device.  
                int bytesSent = client.EndSend(ar);
                Console.WriteLine("Sent {0} bytes to server.", bytesSent);

                // Signal that all bytes have been sent.  
                sendDone.Set();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                myParent.fn_Log(e.ToString());
            }
        }

        private IPEndPoint fn_CreateIPEndPoint(string endPoint)
        {
            string[] ep = endPoint.Split(':');
            if (ep.Length != 2) throw new FormatException("Invalid endpoint format");
            IPAddress ip;
            if (!IPAddress.TryParse(ep[0], out ip))
            {
                throw new FormatException("Invalid ip-adress");
            }
            int port;
            if (!int.TryParse(ep[1], NumberStyles.None, NumberFormatInfo.CurrentInfo, out port))
            {
                throw new FormatException("Invalid port");
            }
            return new IPEndPoint(ip, port);
        }


    }
}
