﻿namespace NCO_App
{
    partial class frmZoneAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_title = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox_nco = new System.Windows.Forms.ComboBox();
            this.textBox_zone1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_zone2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_zone3 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_zone4 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox_zone5 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBox_zone1 = new System.Windows.Forms.ComboBox();
            this.comboBox_zone2 = new System.Windows.Forms.ComboBox();
            this.comboBox_zone3 = new System.Windows.Forms.ComboBox();
            this.comboBox_zone4 = new System.Windows.Forms.ComboBox();
            this.comboBox_zone5 = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panel_head = new System.Windows.Forms.Panel();
            this.btn_close = new System.Windows.Forms.Button();
            this.label_title = new System.Windows.Forms.Label();
            this.btn_cancle = new System.Windows.Forms.Button();
            this.btn_save = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox_zoneList = new System.Windows.Forms.TextBox();
            this.panel_head.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(24, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "그룹 타이틀";
            // 
            // textBox_title
            // 
            this.textBox_title.Location = new System.Drawing.Point(110, 90);
            this.textBox_title.Name = "textBox_title";
            this.textBox_title.Size = new System.Drawing.Size(199, 21);
            this.textBox_title.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(24, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 12);
            this.label2.TabIndex = 3;
            this.label2.Text = "NCO 선택";
            // 
            // comboBox_nco
            // 
            this.comboBox_nco.FormattingEnabled = true;
            this.comboBox_nco.Location = new System.Drawing.Point(110, 53);
            this.comboBox_nco.Name = "comboBox_nco";
            this.comboBox_nco.Size = new System.Drawing.Size(199, 20);
            this.comboBox_nco.TabIndex = 4;
            this.comboBox_nco.SelectedIndexChanged += new System.EventHandler(this.comboBox_nco_SelectedIndexChanged_1);
            // 
            // textBox_zone1
            // 
            this.textBox_zone1.Location = new System.Drawing.Point(345, 162);
            this.textBox_zone1.Name = "textBox_zone1";
            this.textBox_zone1.Size = new System.Drawing.Size(199, 21);
            this.textBox_zone1.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(93, 168);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(11, 12);
            this.label3.TabIndex = 5;
            this.label3.Text = "1";
            // 
            // textBox_zone2
            // 
            this.textBox_zone2.Location = new System.Drawing.Point(345, 198);
            this.textBox_zone2.Name = "textBox_zone2";
            this.textBox_zone2.Size = new System.Drawing.Size(199, 21);
            this.textBox_zone2.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(93, 204);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(11, 12);
            this.label4.TabIndex = 7;
            this.label4.Text = "2";
            // 
            // textBox_zone3
            // 
            this.textBox_zone3.Location = new System.Drawing.Point(345, 235);
            this.textBox_zone3.Name = "textBox_zone3";
            this.textBox_zone3.Size = new System.Drawing.Size(199, 21);
            this.textBox_zone3.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(93, 241);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(11, 12);
            this.label5.TabIndex = 9;
            this.label5.Text = "3";
            // 
            // textBox_zone4
            // 
            this.textBox_zone4.Location = new System.Drawing.Point(345, 274);
            this.textBox_zone4.Name = "textBox_zone4";
            this.textBox_zone4.Size = new System.Drawing.Size(199, 21);
            this.textBox_zone4.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(93, 280);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(11, 12);
            this.label6.TabIndex = 11;
            this.label6.Text = "4";
            // 
            // textBox_zone5
            // 
            this.textBox_zone5.Location = new System.Drawing.Point(345, 315);
            this.textBox_zone5.Name = "textBox_zone5";
            this.textBox_zone5.Size = new System.Drawing.Size(199, 21);
            this.textBox_zone5.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(93, 321);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(11, 12);
            this.label7.TabIndex = 13;
            this.label7.Text = "5";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(343, 135);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(57, 12);
            this.label8.TabIndex = 15;
            this.label8.Text = "표시 문구";
            // 
            // comboBox_zone1
            // 
            this.comboBox_zone1.FormattingEnabled = true;
            this.comboBox_zone1.Location = new System.Drawing.Point(110, 162);
            this.comboBox_zone1.Name = "comboBox_zone1";
            this.comboBox_zone1.Size = new System.Drawing.Size(199, 20);
            this.comboBox_zone1.TabIndex = 16;
            // 
            // comboBox_zone2
            // 
            this.comboBox_zone2.FormattingEnabled = true;
            this.comboBox_zone2.Location = new System.Drawing.Point(110, 199);
            this.comboBox_zone2.Name = "comboBox_zone2";
            this.comboBox_zone2.Size = new System.Drawing.Size(199, 20);
            this.comboBox_zone2.TabIndex = 17;
            // 
            // comboBox_zone3
            // 
            this.comboBox_zone3.FormattingEnabled = true;
            this.comboBox_zone3.Location = new System.Drawing.Point(110, 235);
            this.comboBox_zone3.Name = "comboBox_zone3";
            this.comboBox_zone3.Size = new System.Drawing.Size(199, 20);
            this.comboBox_zone3.TabIndex = 18;
            // 
            // comboBox_zone4
            // 
            this.comboBox_zone4.FormattingEnabled = true;
            this.comboBox_zone4.Location = new System.Drawing.Point(110, 274);
            this.comboBox_zone4.Name = "comboBox_zone4";
            this.comboBox_zone4.Size = new System.Drawing.Size(199, 20);
            this.comboBox_zone4.TabIndex = 19;
            // 
            // comboBox_zone5
            // 
            this.comboBox_zone5.FormattingEnabled = true;
            this.comboBox_zone5.Location = new System.Drawing.Point(110, 315);
            this.comboBox_zone5.Name = "comboBox_zone5";
            this.comboBox_zone5.Size = new System.Drawing.Size(199, 20);
            this.comboBox_zone5.TabIndex = 20;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(108, 135);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(76, 12);
            this.label9.TabIndex = 21;
            this.label9.Text = "NCO 설정 값";
            // 
            // panel_head
            // 
            this.panel_head.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.panel_head.Controls.Add(this.btn_close);
            this.panel_head.Controls.Add(this.label_title);
            this.panel_head.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_head.Location = new System.Drawing.Point(0, 0);
            this.panel_head.Name = "panel_head";
            this.panel_head.Size = new System.Drawing.Size(881, 35);
            this.panel_head.TabIndex = 70;
            // 
            // btn_close
            // 
            this.btn_close.BackColor = System.Drawing.Color.Black;
            this.btn_close.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btn_close.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.btn_close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_close.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_close.ForeColor = System.Drawing.Color.White;
            this.btn_close.Location = new System.Drawing.Point(831, 3);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(44, 27);
            this.btn_close.TabIndex = 462;
            this.btn_close.Text = "X";
            this.btn_close.UseVisualStyleBackColor = false;
            // 
            // label_title
            // 
            this.label_title.AutoSize = true;
            this.label_title.ForeColor = System.Drawing.Color.White;
            this.label_title.Location = new System.Drawing.Point(12, 13);
            this.label_title.Name = "label_title";
            this.label_title.Size = new System.Drawing.Size(62, 12);
            this.label_title.TabIndex = 0;
            this.label_title.Text = "Zone 설정";
            // 
            // btn_cancle
            // 
            this.btn_cancle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_cancle.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_cancle.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_cancle.FlatAppearance.BorderSize = 2;
            this.btn_cancle.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.btn_cancle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_cancle.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_cancle.ForeColor = System.Drawing.Color.Black;
            this.btn_cancle.Location = new System.Drawing.Point(427, 352);
            this.btn_cancle.Name = "btn_cancle";
            this.btn_cancle.Size = new System.Drawing.Size(116, 44);
            this.btn_cancle.TabIndex = 502;
            this.btn_cancle.Text = "취소";
            this.btn_cancle.UseVisualStyleBackColor = false;
            this.btn_cancle.Click += new System.EventHandler(this.btn_cancle_Click);
            // 
            // btn_save
            // 
            this.btn_save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btn_save.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_save.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_save.FlatAppearance.BorderSize = 2;
            this.btn_save.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.btn_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_save.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_save.ForeColor = System.Drawing.Color.Black;
            this.btn_save.Location = new System.Drawing.Point(305, 352);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(116, 44);
            this.btn_save.TabIndex = 503;
            this.btn_save.Text = "저장";
            this.btn_save.UseVisualStyleBackColor = false;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(561, 53);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(72, 12);
            this.label10.TabIndex = 505;
            this.label10.Text = "NCO 리스트";
            // 
            // textBox_zoneList
            // 
            this.textBox_zoneList.Location = new System.Drawing.Point(563, 68);
            this.textBox_zoneList.Multiline = true;
            this.textBox_zoneList.Name = "textBox_zoneList";
            this.textBox_zoneList.Size = new System.Drawing.Size(285, 328);
            this.textBox_zoneList.TabIndex = 506;
            // 
            // frmZoneAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(881, 408);
            this.Controls.Add(this.textBox_zoneList);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.btn_cancle);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.panel_head);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.comboBox_zone5);
            this.Controls.Add(this.comboBox_zone4);
            this.Controls.Add(this.comboBox_zone3);
            this.Controls.Add(this.comboBox_zone2);
            this.Controls.Add(this.comboBox_zone1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textBox_zone5);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBox_zone4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBox_zone3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox_zone2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox_zone1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.comboBox_nco);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox_title);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmZoneAdd";
            this.Text = "frmZoneAdd";
            this.Load += new System.EventHandler(this.frmZoneAdd_Load);
            this.panel_head.ResumeLayout(false);
            this.panel_head.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_title;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox_nco;
        private System.Windows.Forms.TextBox textBox_zone1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_zone2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_zone3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_zone4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_zone5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox_zone1;
        private System.Windows.Forms.ComboBox comboBox_zone2;
        private System.Windows.Forms.ComboBox comboBox_zone3;
        private System.Windows.Forms.ComboBox comboBox_zone4;
        private System.Windows.Forms.ComboBox comboBox_zone5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel_head;
        private System.Windows.Forms.Button btn_close;
        private System.Windows.Forms.Label label_title;
        private System.Windows.Forms.Button btn_cancle;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox_zoneList;
    }
}