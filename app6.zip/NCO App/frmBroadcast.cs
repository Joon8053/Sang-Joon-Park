﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;
using RHBform;
using RHBLibrary.Tools;
using System.Collections;

namespace NCO_App
{
    public partial class frmBroadcast : Form
    {
        frmMain app;
        public frmBroadcast(frmMain main)
        {
            InitializeComponent();
            app = main;
        }

        private void FromAdd(Form frm, Panel pBase,int width,int height)
        {
            frm.TopLevel = false;
            frm.TopMost = true;
            frm.Parent = this;
            pBase.Controls.Add(frm);
            frm.Width = width;
            frm.Show();
            frm.Location = new Point(0, height);
        }

        frmZone[] FormZone = new frmZone[4];
        Button[] ColorCall,ColorBGM,BtnBGMs,BtnCalls;
        private void frmBroadcast_Load(object sender, EventArgs e)
        {
            FormZone[0] = new frmZone(app);
            FromAdd(FormZone[0], panel_zone,990,0);
            FormZone[0].LoadData(0);
            FormZone[1] = new frmZone(app);
            FromAdd(FormZone[1], panel_zone, 990, FormZone[0].Size.Height+ FormZone[0].Location.Y);
            FormZone[1].LoadData(1);
            FormZone[2] = new frmZone(app);
            FromAdd(FormZone[2], panel_zone, 990, FormZone[1].Size.Height + FormZone[1].Location.Y);
            FormZone[2].LoadData(2);
            FormZone[3] = new frmZone(app);
            FromAdd(FormZone[3], panel_zone, 990, FormZone[2].Size.Height + FormZone[2].Location.Y);
            FormZone[3].LoadData(3);

            ColorBGM = new Button[] { CBGM1,CBGM2,CBGM3,CBGM4,CBGM5 };
            ColorCall = new Button[] {Ccall1,Ccall2,Ccall3,Ccall4,Ccall5};
            BtnBGMs = new Button[] { BGM1,BGM2,BGM3,BGM4,BGM5 };
            BtnCalls = new Button[] { btn_call1,btn_call2,btn_call3,btn_call4,btn_call5 };
            for (int i = 0; i < BtnBGMs.Length; i++)
            {
                BtnBGMs[i].Click += BtnBGMs_Click;
                BtnBGMs[i].Tag = i;
               BtnCalls[i].Click += BtnCalls_Click;
                BtnCalls[i].Tag = i;
            }
            UpdateButtons();

            btn_NCOs = new usrNCOst[] { btn_nco1, btn_nco2, btn_nco3 };
            initNcoText(btn_NCOs);
            frmTTS FormTTS = new frmTTS();
            FromAdd(FormTTS, panel_tts, panel_tts.Width, 0);
            buttonCreate();
            buttonCreate_Net();
            getFile(app.mainVar.musicFolder);
            UpdateNetBtn();
            buttonCreate_Preset();
        }
        usrNCOst[] btn_NCOs;


        public void UpdateZone()
        {
            FormZone[0].LoadData(0);
            FormZone[1].Location = new Point(0, FormZone[0].Size.Height + FormZone[0].Location.Y);
            FormZone[1].LoadData(1);
            FormZone[2].Location = new Point(0, FormZone[1].Size.Height + FormZone[1].Location.Y);
            FormZone[2].LoadData(2);
            FormZone[3].Location = new Point(0, FormZone[2].Size.Height + FormZone[2].Location.Y);
            FormZone[3].LoadData(3);

        }
        private void initNcoText(usrNCOst[] btn)
        {
            for (int i = 0; i < btn.Length; i++)
            {
                btn[i].setTitle = app.NcoSite.NCO[i].Name;
            }
        }
        public void disConnect(int ch,bool mode)
        {
            Invoke(new Action(() =>
            {
                btn_NCOs[ch].setOline = mode;
            }));
        }

        public void upadteFire(int id, bool mode)
        {
            Invoke(new Action(() =>
            {
                btn_NCOs[id].setFire = mode;
            }));
        }
        public void upadteFault(int id, bool mode)
        {
            Invoke(new Action(() =>
            {
                btn_NCOs[id].setFault = mode;
            }));
        }
        string[] StrZones = { "", "", "" };
        private bool setSelect()
        {
            StrZones = new string[]{ "", "", "" };
            FormZone[0].reqNcoZone(ref StrZones);
            FormZone[1].reqNcoZone(ref StrZones);
            FormZone[2].reqNcoZone(ref StrZones);
            FormZone[3].reqNcoZone(ref StrZones);
            int len = 0;
            for (int i = 0; i < StrZones.Length; i++)
            {
                if (StrZones[i].Length > 0)
                {
                    StrZones[i] = StrZones[i].Remove(StrZones[i].Length - 1);
                }
                len += StrZones[i].Length;
            }
            if (len == 0)
            {
                MessageBox.Show("선택된 지역이 없습니다. 확인하세요!!");
                return false;
            }
            else
                return true;
        }
        private void btn_callCancel_Click(object sender, EventArgs e)
        {
            if (setSelect())
            {
                app.NCO_CallEnd();
            }
        }



        public void UpdateButtons()
        {
            for (int i = 0; i < BtnBGMs.Length; i++)
            {
                BtnBGMs[i].Text = app.defBGMs[i].Name;
                ColorBGM[i].BackColor = app.defBGMs[i].cl;
                BtnCalls[i].Text = app.defCalls[i].Name;
                ColorCall[i].BackColor = app.defCalls[i].cl; ;
            }
        }
        private void BtnCalls_Click(object sender, EventArgs e)
        {
            int btn = Convert.ToInt16(((Control)sender).Tag);
            if (setSelect())
            {
                DialogResult result = MessageBox.Show(app.defCalls[btn].Name, "방송 실행", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    app.callCreate(StrZones, btn);
                }
            }
        }

        private void BtnBGMs_Click(object sender, EventArgs e)
        {
            int btn = Convert.ToInt16(((Control)sender).Tag);
            if (setSelect())
            {
                app.AddBGM(StrZones, btn);
            }
        }

        private void BGM_cancel_Click(object sender, EventArgs e)
        {
            if (setSelect())
            {
                for (int i = 0; i <5; i++)
                app.RemoveBGM(StrZones,i);
            }
        }

        private void btn_music_Click(object sender, EventArgs e)
        {
            using (var dialog = new FolderBrowserDialog())
            {
                // 폴더 경로가 유효한지 체크 후, 초기 폴더 경로 설정
                if (Directory.Exists(app.mainVar.musicFolder))
                {
                    dialog.SelectedPath = app.mainVar.musicFolder;
                }
                DialogResult result = dialog.ShowDialog();
                if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(dialog.SelectedPath))
                {
                    string path = dialog.SelectedPath;
                    // 선택된 폴더 경로를 path 변수에 저장하고 사용할 수 있습니다.
                    app.mainVar.musicFolder = path;
                    app.mainDataSave();
                    getFile(path);
                }
            }
        }

        

        List<string> mpFile = new List<string>();
        List<string> bFile = new List<string>();
        
        private void getFile(string filePath)
        {
            try
            {
                mpFile.Clear();

                for (int i = 0; i < btnPreset.Length; i++)
                {
                    btnPreset[i].Visible = false;
                }
                filePath += "\\";
                // 디렉토리 경로에서 mp3, wav 확장자를 가지는 파일들만 가져옴
                // string[] files = Directory.GetFiles(filePath, "*.mp3;*.wav", SearchOption.TopDirectoryOnly);
                // string[] searchPatterns = { "*.mp3", "*.wav" };
                // string[] files = searchPatterns.SelectMany(searchPattern => Directory.GetFiles(filePath, searchPattern)).ToArray();
                //DirectoryInfo di = new DirectoryInfo(filePath);
                //FileInfo[] files = di.GetFiles();
               // string folderPath = @"C:\folder\subfolder";
                string[] searchPatterns = { "*.mp3", "*.wav" };
                string[] files = searchPatterns
                    .SelectMany(pattern => new DirectoryInfo(filePath).GetFiles(pattern))
                    .Select(fileInfo => new FileInfo(fileInfo.FullName))
                    .OrderByDescending(fileInfo => fileInfo.CreationTime)
                    .Select(fileInfo => $"({fileInfo.CreationTime:yyyy-MM-dd}) - {fileInfo.Name}")
                    .ToArray();
                string[] files1 = searchPatterns
                    .SelectMany(pattern => new DirectoryInfo(filePath).GetFiles(pattern))
                    .Select(fileInfo => new FileInfo(fileInfo.FullName))
                    .OrderByDescending(fileInfo => fileInfo.CreationTime)
                    .Select(fileInfo => $"{fileInfo}")
                    .ToArray();
                /*

                DirectoryInfo directoryInfo = new DirectoryInfo(filePath);
                FileInfo[] files = directoryInfo.GetFiles()
                    .Where(file => file.Extension.ToLower() == ".mp3" || file.Extension.ToLower() == ".wav")
                    .ToArray();

                */
                //  string[] files = Directory.GetFiles(filePath, "*.mp3;*.wav");
                // 파일명으로부터 버튼 생성

                foreach (string file in files)
                {
                    bFile.Add(file);
                }
                foreach (string file in files1)
                {
                    mpFile.Add(file);
                }

                /*
                // FileInfo 클래스 객체 생성 후 fileList에 추가하기
                foreach (FileInfo file in files)
                {
                   // FileInfo fileInfo = new FileInfo();
                    mpFile.Add(file.Name);
                   // fileInfo.Name = file.Name;
                    //fileInfo.CreationTime = file.CreationTime;
                   // fileList.Add(fileInfo);
                }
                */

                // 최근 생성된 파일 순으로 정렬
                /*
                fileList = fileList.OrderByDescending(file => file.CreationTime).ToList();

                Console.WriteLine("파일 목록:");
                foreach (FileInfo file in fileList)
                {
                    Console.WriteLine("{0} - {1}", file.CreationTime, file.Name);
                }
                */
                /*
                files = Directory.GetFiles(filePath, "*.wav");
                // 파일명으로부터 버튼 생성
                foreach (string file in files)
                {
                    mpFile.Add(file);
                    string fileName = Path.GetFileNameWithoutExtension(file);
                    bFile.Add(fileName);
                }
                */
                for (int i = 0; i < mpFile.Count; i++)
                {
                    btnPreset[i].Visible = true;
                    btnPreset[i].Text = bFile[i];
                }





            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        OnOffButton[] btnPreset = new OnOffButton[500];
        private void buttonCreate()
        {
            CreateBtn buttonPos;
            buttonPos = new CreateBtn(420, 35, 10, 10);
            buttonPos.ArrayX = 1;
            buttonPos.GapX = 5;
            buttonPos.GapY = 5;
            for(int i=0;i<btnPreset.Length; i++)
            {
                btnPreset[i] = new OnOffButton();
                OnOffButton btn = btnPreset[i];
                panel_music.Controls.Add(btn);
                buttonPos.Cul_pos(i + 1);
                btn.Size = new Size(buttonPos.Width, buttonPos.Height);
                btn.FlatStyle = FlatStyle.Flat;
                btn.FlatAppearance.BorderSize = 1;
                btn.FlatAppearance.BorderColor = Color.White;
                btn.FlatAppearance.MouseOverBackColor = Color.Silver;
                btn.FlatAppearance.MouseDownBackColor = Color.OliveDrab;
                btn.Location = new Point(buttonPos.PosX, buttonPos.PosY);
                btn.Click += Btn_Click;
                btn.IsOn = false;
                btn.Visible = false;
                btn.Tag = i;
                btn.TextAlign = ContentAlignment.MiddleLeft;
            }
        }

        OnOffButton[] btnNetCheck = new OnOffButton[100];
        private void buttonCreate_Net()
        {
            CreateBtn buttonPos;
            buttonPos = new CreateBtn(120, 35, 10, 10);
            buttonPos.ArrayX = 2;
            buttonPos.GapX = 5;
            buttonPos.GapY = 5;
            for (int i = 0; i < btnNetCheck.Length; i++)
            {
                btnNetCheck[i] = new OnOffButton();
                OnOffButton btn = btnNetCheck[i];
                panel_NET.Controls.Add(btn);
                buttonPos.Cul_pos(i + 1);
                btn.Size = new Size(buttonPos.Width, buttonPos.Height);
                btn.FlatStyle = FlatStyle.Flat;
                btn.FlatAppearance.BorderSize = 1;
                btn.FlatAppearance.BorderColor = Color.White;
                btn.FlatAppearance.MouseDownBackColor = Color.OliveDrab;
                btn.Location = new Point(buttonPos.PosX, buttonPos.PosY);
                btn.IsOn = false;
                btn.Visible = false;
                btn.ForeColor = Color.Black;
            }
        }

        Button[] btn_Preset = new Button[100];
        private void buttonCreate_Preset()
        {
            CreateBtn buttonPos;
            buttonPos = new CreateBtn(170, 35, 10, 10);
            buttonPos.ArrayX = 1;
            buttonPos.GapX = 5;
            buttonPos.GapY = 5;
            for (int i = 0; i < btnNetCheck.Length; i++)
            {
                btn_Preset[i] = new Button();
                Button btn = btn_Preset[i];
                panel_preset.Controls.Add(btn);
                buttonPos.Cul_pos(i + 1);
                btn.Size = new Size(buttonPos.Width, buttonPos.Height);
                btn.FlatStyle = FlatStyle.Flat;
                btn.FlatAppearance.BorderSize = 1;
                btn.FlatAppearance.BorderColor = Color.White;
                btn.FlatAppearance.MouseDownBackColor = Color.Lime;
                btn.BackColor = Color.Silver;
                btn.Location = new Point(buttonPos.PosX, buttonPos.PosY);

                btn.Visible = true;
                btn.ForeColor = Color.White;
            }
        }

        public void UpdateNetBtn()
        {
            for (int i = 0; i < btnNetCheck.Length; i++)
            {
                if (i < app.netDevice.Name.Count)
                {
                    btnNetCheck[i].Visible = true;
                    btnNetCheck[i].Text = app.netDevice.Name[i];
                }
                else
                    btnNetCheck[i].Visible = false;
            }
        }

        public void netDeviceStatus(bool mode,int id)
        {
            btnNetCheck[id].IsOn = mode;
        }
        private void Btn_Click(object sender, EventArgs e)
        {
            int btn = Convert.ToInt16(((Control)sender).Tag);
            if ((avPlayer.playState == WMPLib.WMPPlayState.wmppsStopped) || (avPlayer.playState == WMPLib.WMPPlayState.wmppsUndefined) || (avPlayer.playState == WMPLib.WMPPlayState.wmppsReady))
            {
                string file_name = mpFile[btn];
                avPlayer.URL = file_name;
                avPlayer.Ctlcontrols.stop();
                for (int i = 0; i < btnPreset.Length; i++)
                    btnPreset[i].IsOn = false;
                btnPreset[btn].IsOn = true;
            }
        }

        private void timer_reConnet_Tick(object sender, EventArgs e)
        {
 
        }

        private void btn_erase1_Click(object sender, EventArgs e)
        {

        }

        private Color getColor(int Priority)
        {
            Color cl = Color.Silver;
            bool flg = false;
            for (int i = 0; i < app.defCalls.Length; i++)
            {
                if (app.defCalls[i].Priority == Priority.ToString())
                {
                    cl = app.defCalls[i].cl;
                    flg = true;
                    return cl;
                }
            }

            if (flg==false)
                if (Priority > 239)
                    cl = Color.Red;
  
            return cl;
        }

        private void btn_Allon_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < FormZone.Length; i++)
            {
                FormZone[i].AllOnOff(true);
            }
        }


        private void btn_Alloff_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < FormZone.Length; i++)
            {
                FormZone[i].AllOnOff(false);
            }
        }


        List<bool[]> preseZone = new List<bool[]>();
        private void btn_preAdd_Click(object sender, EventArgs e)
        {
            preseZone.Clear();
            for (int i = 0; i < FormZone.Length; i++)
            {
               preseZone.Add(FormZone[i].getSelect().ToArray());
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < FormZone.Length; i++)
            {
                if (preseZone.Count>0)
                {
                    List<bool> tmp = preseZone[i].ToList();
                    FormZone[i].updateSelect(tmp);
                }

            }
        }

        private Color getColor(string channel)
        {
            Color cl = Color.White;

            for(int i=0;i<app.defBGMs.Length;i++)
            {
                if (app.defBGMs[i].NCObgm == channel)
                    cl = app.defBGMs[i].cl;
            }
            return cl;
        }

        public void rcvUpdateZone(int NoNCO,int Priority,List<string> sZone,string channel)
        {
            Color cl = Color.White;
            bool flg = true;
            if (Priority!=65535)
            {
                if(Priority==0)
                {
                    if (channel != "")
                        cl = getColor(channel);
                    else
                    {
                        // ask bgm list.
                        app.SC_BGMlist(NoNCO,false);
                        app.SC_BGMlist(NoNCO, true);
                        return;
                    }    
                }
                else
                {
                    cl = getColor(Priority);
                }
            }

            FormZone[0].UpdateZone(NoNCO, Priority, sZone, cl);
            FormZone[1].UpdateZone(NoNCO, Priority, sZone, cl);
            FormZone[2].UpdateZone(NoNCO, Priority, sZone, cl);
            FormZone[3].UpdateZone(NoNCO, Priority, sZone, cl);
        }

        public class OnOffButton : Button
        {
            private bool isOn;

            public OnOffButton()
            {
                isOn = false;
                this.FlatStyle = FlatStyle.Flat;
            }
            public Color onColor = Color.Lime;
            public Color offColor = Color.White;
            public bool IsOn
            {
                get { return isOn; }
                set 
                { 
                    isOn = value;
                    if (isOn)
                    {
                        this.BackColor = onColor;                       
                    }
                    else
                    {
                        this.BackColor = offColor;
                    }
                    this.FlatAppearance.MouseOverBackColor = this.BackColor;
                }
            }
        }
    }
}
