﻿namespace NCO_App
{
    partial class usrNCOst
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label_online = new System.Windows.Forms.Label();
            this.label_fire = new System.Windows.Forms.Label();
            this.label_fault = new System.Windows.Forms.Label();
            this.label_name = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel1.Controls.Add(this.label_online, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label_fire, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label_fault, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label_name, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(226, 60);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // label_online
            // 
            this.label_online.AutoSize = true;
            this.label_online.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label_online.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_online.Location = new System.Drawing.Point(4, 30);
            this.label_online.Name = "label_online";
            this.label_online.Size = new System.Drawing.Size(82, 29);
            this.label_online.TabIndex = 0;
            this.label_online.Text = "Online";
            this.label_online.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_fire
            // 
            this.label_fire.AutoSize = true;
            this.label_fire.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label_fire.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_fire.Location = new System.Drawing.Point(93, 30);
            this.label_fire.Name = "label_fire";
            this.label_fire.Size = new System.Drawing.Size(60, 29);
            this.label_fire.TabIndex = 1;
            this.label_fire.Text = "Fire";
            this.label_fire.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_fault
            // 
            this.label_fault.AutoSize = true;
            this.label_fault.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label_fault.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_fault.Location = new System.Drawing.Point(160, 30);
            this.label_fault.Name = "label_fault";
            this.label_fault.Size = new System.Drawing.Size(62, 29);
            this.label_fault.TabIndex = 2;
            this.label_fault.Text = "Fault";
            this.label_fault.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label_name, 3);
            this.label_name.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_name.Location = new System.Drawing.Point(4, 1);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(218, 28);
            this.label_name.TabIndex = 3;
            this.label_name.Text = "Name";
            this.label_name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // usrNCOst
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "usrNCOst";
            this.Size = new System.Drawing.Size(226, 60);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label_online;
        private System.Windows.Forms.Label label_fire;
        private System.Windows.Forms.Label label_fault;
        private System.Windows.Forms.Label label_name;
    }
}
