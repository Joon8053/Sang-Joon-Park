﻿namespace NCO_App
{
    partial class frmNCO
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_nco3 = new System.Windows.Forms.Button();
            this.btn_nco2 = new System.Windows.Forms.Button();
            this.btn_nco1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_nco3);
            this.groupBox1.Controls.Add(this.btn_nco2);
            this.groupBox1.Controls.Add(this.btn_nco1);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(26, 22);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(301, 203);
            this.groupBox1.TabIndex = 124;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = " NCO List ";
            // 
            // btn_nco3
            // 
            this.btn_nco3.ForeColor = System.Drawing.Color.Black;
            this.btn_nco3.Location = new System.Drawing.Point(30, 131);
            this.btn_nco3.Name = "btn_nco3";
            this.btn_nco3.Size = new System.Drawing.Size(241, 48);
            this.btn_nco3.TabIndex = 5;
            this.btn_nco3.Tag = "3";
            this.btn_nco3.Text = "NCO3";
            this.btn_nco3.UseVisualStyleBackColor = true;
            this.btn_nco3.Click += new System.EventHandler(this.btn_nco1_Click);
            // 
            // btn_nco2
            // 
            this.btn_nco2.ForeColor = System.Drawing.Color.Black;
            this.btn_nco2.Location = new System.Drawing.Point(30, 77);
            this.btn_nco2.Name = "btn_nco2";
            this.btn_nco2.Size = new System.Drawing.Size(241, 48);
            this.btn_nco2.TabIndex = 4;
            this.btn_nco2.Tag = "2";
            this.btn_nco2.Text = "NCO2";
            this.btn_nco2.UseVisualStyleBackColor = true;
            this.btn_nco2.Click += new System.EventHandler(this.btn_nco1_Click);
            // 
            // btn_nco1
            // 
            this.btn_nco1.ForeColor = System.Drawing.Color.Black;
            this.btn_nco1.Location = new System.Drawing.Point(30, 23);
            this.btn_nco1.Name = "btn_nco1";
            this.btn_nco1.Size = new System.Drawing.Size(241, 48);
            this.btn_nco1.TabIndex = 3;
            this.btn_nco1.Tag = "1";
            this.btn_nco1.Text = "NCO1";
            this.btn_nco1.UseVisualStyleBackColor = true;
            this.btn_nco1.Click += new System.EventHandler(this.btn_nco1_Click);
            // 
            // frmNCO
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.ClientSize = new System.Drawing.Size(1920, 947);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmNCO";
            this.Text = "frmNCO";
            this.Load += new System.EventHandler(this.frmNCO_Load);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_nco3;
        private System.Windows.Forms.Button btn_nco2;
        private System.Windows.Forms.Button btn_nco1;
    }
}