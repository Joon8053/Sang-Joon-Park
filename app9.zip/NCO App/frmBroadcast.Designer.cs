﻿namespace NCO_App
{
    partial class frmBroadcast
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBroadcast));
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.panel_NET = new System.Windows.Forms.Panel();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_nco3 = new NCO_App.usrNCOst();
            this.btn_nco2 = new NCO_App.usrNCOst();
            this.btn_nco1 = new NCO_App.usrNCOst();
            this.btn_erase1 = new RHBform.RHBbutton();
            this.panel_zone = new System.Windows.Forms.Panel();
            this.pg1_menu6 = new System.Windows.Forms.GroupBox();
            this.BGM_cancel = new System.Windows.Forms.Button();
            this.BGM5 = new System.Windows.Forms.Button();
            this.CBGM5 = new System.Windows.Forms.Button();
            this.BGM2 = new System.Windows.Forms.Button();
            this.CBGM4 = new System.Windows.Forms.Button();
            this.CBGM2 = new System.Windows.Forms.Button();
            this.BGM4 = new System.Windows.Forms.Button();
            this.BGM1 = new System.Windows.Forms.Button();
            this.CBGM3 = new System.Windows.Forms.Button();
            this.CBGM1 = new System.Windows.Forms.Button();
            this.BGM3 = new System.Windows.Forms.Button();
            this.btn_Alloff = new RHBform.RHBbutton();
            this.btn_Allon = new RHBform.RHBbutton();
            this.groupBox_mp3 = new System.Windows.Forms.GroupBox();
            this.panel_music = new System.Windows.Forms.Panel();
            this.avPlayer = new AxWMPLib.AxWindowsMediaPlayer();
            this.btn_music = new System.Windows.Forms.Button();
            this.panel_tts = new System.Windows.Forms.Panel();
            this.rhBbutton3 = new RHBform.RHBbutton();
            this.panel_preset = new System.Windows.Forms.Panel();
            this.btn_preAdd = new RHBform.RHBbutton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btn_callCancel = new System.Windows.Forms.Button();
            this.btn_call5 = new System.Windows.Forms.Button();
            this.Ccall5 = new System.Windows.Forms.Button();
            this.btn_call2 = new System.Windows.Forms.Button();
            this.Ccall4 = new System.Windows.Forms.Button();
            this.Ccall2 = new System.Windows.Forms.Button();
            this.btn_call4 = new System.Windows.Forms.Button();
            this.btn_call1 = new System.Windows.Forms.Button();
            this.Ccall3 = new System.Windows.Forms.Button();
            this.Ccall1 = new System.Windows.Forms.Button();
            this.btn_call3 = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.richTextBox_scLog = new System.Windows.Forms.RichTextBox();
            this.timer_reConnet = new System.Windows.Forms.Timer(this.components);
            this.btn_preErase = new RHBform.RHBbutton();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btn_music4 = new System.Windows.Forms.Button();
            this.btn_music3 = new System.Windows.Forms.Button();
            this.btn_music2 = new System.Windows.Forms.Button();
            this.btn_music1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.pg1_menu6.SuspendLayout();
            this.groupBox_mp3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.avPlayer)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.btn_erase1);
            this.panel1.Location = new System.Drawing.Point(8, 8);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(338, 934);
            this.panel1.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.richTextBox1);
            this.groupBox3.ForeColor = System.Drawing.Color.White;
            this.groupBox3.Location = new System.Drawing.Point(20, 671);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(301, 253);
            this.groupBox3.TabIndex = 125;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "방송 로그";
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.Black;
            this.richTextBox1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.richTextBox1.Location = new System.Drawing.Point(6, 20);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(289, 227);
            this.richTextBox1.TabIndex = 347;
            this.richTextBox1.Text = "";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.panel_NET);
            this.groupBox2.Controls.Add(this.richTextBox2);
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(20, 258);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(301, 386);
            this.groupBox2.TabIndex = 124;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = " 네트워크 장비 ";
            // 
            // panel_NET
            // 
            this.panel_NET.AutoScroll = true;
            this.panel_NET.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.panel_NET.Location = new System.Drawing.Point(6, 20);
            this.panel_NET.Name = "panel_NET";
            this.panel_NET.Size = new System.Drawing.Size(289, 237);
            this.panel_NET.TabIndex = 349;
            // 
            // richTextBox2
            // 
            this.richTextBox2.BackColor = System.Drawing.Color.Black;
            this.richTextBox2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.richTextBox2.Location = new System.Drawing.Point(6, 263);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(289, 117);
            this.richTextBox2.TabIndex = 348;
            this.richTextBox2.Text = "";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_nco3);
            this.groupBox1.Controls.Add(this.btn_nco2);
            this.groupBox1.Controls.Add(this.btn_nco1);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(20, 15);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(301, 236);
            this.groupBox1.TabIndex = 123;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = " NCO List ";
            // 
            // btn_nco3
            // 
            this.btn_nco3.BackColor = System.Drawing.Color.White;
            this.btn_nco3.ForeColor = System.Drawing.Color.Black;
            this.btn_nco3.Location = new System.Drawing.Point(23, 157);
            this.btn_nco3.Name = "btn_nco3";
            this.btn_nco3.Size = new System.Drawing.Size(252, 60);
            this.btn_nco3.TabIndex = 5;
            // 
            // btn_nco2
            // 
            this.btn_nco2.BackColor = System.Drawing.Color.White;
            this.btn_nco2.ForeColor = System.Drawing.Color.Black;
            this.btn_nco2.Location = new System.Drawing.Point(23, 91);
            this.btn_nco2.Name = "btn_nco2";
            this.btn_nco2.Size = new System.Drawing.Size(252, 60);
            this.btn_nco2.TabIndex = 4;
            // 
            // btn_nco1
            // 
            this.btn_nco1.BackColor = System.Drawing.Color.White;
            this.btn_nco1.ForeColor = System.Drawing.Color.Black;
            this.btn_nco1.Location = new System.Drawing.Point(23, 25);
            this.btn_nco1.Name = "btn_nco1";
            this.btn_nco1.Size = new System.Drawing.Size(252, 60);
            this.btn_nco1.TabIndex = 3;
            // 
            // btn_erase1
            // 
            this.btn_erase1.BackColor = System.Drawing.Color.Transparent;
            this.btn_erase1.ForeColor = System.Drawing.Color.Yellow;
            this.btn_erase1.Location = new System.Drawing.Point(201, 628);
            this.btn_erase1.Name = "btn_erase1";
            this.btn_erase1.setFontColor = System.Drawing.Color.Yellow;
            this.btn_erase1.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_erase1.setOFFimage")));
            this.btn_erase1.setON = false;
            this.btn_erase1.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_erase1.setONimage")));
            this.btn_erase1.setText = "내용 지우기";
            this.btn_erase1.setToggle = false;
            this.btn_erase1.Size = new System.Drawing.Size(120, 60);
            this.btn_erase1.TabIndex = 126;
            this.btn_erase1.TabStop = false;
            this.btn_erase1.Tag = "2";
            this.btn_erase1.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_erase1.Click += new System.EventHandler(this.btn_erase1_Click);
            // 
            // panel_zone
            // 
            this.panel_zone.AutoScroll = true;
            this.panel_zone.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.panel_zone.Location = new System.Drawing.Point(349, 32);
            this.panel_zone.Name = "panel_zone";
            this.panel_zone.Size = new System.Drawing.Size(996, 735);
            this.panel_zone.TabIndex = 1;
            // 
            // pg1_menu6
            // 
            this.pg1_menu6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.pg1_menu6.Controls.Add(this.BGM_cancel);
            this.pg1_menu6.Controls.Add(this.BGM5);
            this.pg1_menu6.Controls.Add(this.CBGM5);
            this.pg1_menu6.Controls.Add(this.BGM2);
            this.pg1_menu6.Controls.Add(this.CBGM4);
            this.pg1_menu6.Controls.Add(this.CBGM2);
            this.pg1_menu6.Controls.Add(this.BGM4);
            this.pg1_menu6.Controls.Add(this.BGM1);
            this.pg1_menu6.Controls.Add(this.CBGM3);
            this.pg1_menu6.Controls.Add(this.CBGM1);
            this.pg1_menu6.Controls.Add(this.BGM3);
            this.pg1_menu6.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.pg1_menu6.ForeColor = System.Drawing.Color.White;
            this.pg1_menu6.Location = new System.Drawing.Point(702, 773);
            this.pg1_menu6.Name = "pg1_menu6";
            this.pg1_menu6.Size = new System.Drawing.Size(346, 169);
            this.pg1_menu6.TabIndex = 121;
            this.pg1_menu6.TabStop = false;
            this.pg1_menu6.Text = "BGM";
            // 
            // BGM_cancel
            // 
            this.BGM_cancel.BackColor = System.Drawing.Color.Silver;
            this.BGM_cancel.FlatAppearance.BorderSize = 0;
            this.BGM_cancel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.BGM_cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BGM_cancel.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.BGM_cancel.ForeColor = System.Drawing.Color.Black;
            this.BGM_cancel.Location = new System.Drawing.Point(209, 117);
            this.BGM_cancel.Name = "BGM_cancel";
            this.BGM_cancel.Size = new System.Drawing.Size(127, 39);
            this.BGM_cancel.TabIndex = 116;
            this.BGM_cancel.Tag = "6";
            this.BGM_cancel.Text = "취소";
            this.BGM_cancel.UseVisualStyleBackColor = false;
            this.BGM_cancel.Click += new System.EventHandler(this.BGM_cancel_Click);
            // 
            // BGM5
            // 
            this.BGM5.BackColor = System.Drawing.Color.Silver;
            this.BGM5.FlatAppearance.BorderSize = 0;
            this.BGM5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.BGM5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BGM5.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.BGM5.ForeColor = System.Drawing.Color.Black;
            this.BGM5.Location = new System.Drawing.Point(45, 117);
            this.BGM5.Name = "BGM5";
            this.BGM5.Size = new System.Drawing.Size(126, 39);
            this.BGM5.TabIndex = 112;
            this.BGM5.Tag = "5";
            this.BGM5.UseVisualStyleBackColor = false;
            // 
            // CBGM5
            // 
            this.CBGM5.BackColor = System.Drawing.Color.LightBlue;
            this.CBGM5.FlatAppearance.BorderSize = 0;
            this.CBGM5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CBGM5.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CBGM5.ForeColor = System.Drawing.Color.Black;
            this.CBGM5.Location = new System.Drawing.Point(12, 117);
            this.CBGM5.Name = "CBGM5";
            this.CBGM5.Size = new System.Drawing.Size(30, 39);
            this.CBGM5.TabIndex = 113;
            this.CBGM5.Text = "5";
            this.CBGM5.UseVisualStyleBackColor = false;
            // 
            // BGM2
            // 
            this.BGM2.BackColor = System.Drawing.Color.Silver;
            this.BGM2.FlatAppearance.BorderSize = 0;
            this.BGM2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.BGM2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BGM2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.BGM2.ForeColor = System.Drawing.Color.Black;
            this.BGM2.Location = new System.Drawing.Point(210, 22);
            this.BGM2.Name = "BGM2";
            this.BGM2.Size = new System.Drawing.Size(126, 39);
            this.BGM2.TabIndex = 108;
            this.BGM2.Tag = "2";
            this.BGM2.Text = "전관방송 G.4";
            this.BGM2.UseVisualStyleBackColor = false;
            // 
            // CBGM4
            // 
            this.CBGM4.BackColor = System.Drawing.Color.LightBlue;
            this.CBGM4.FlatAppearance.BorderSize = 0;
            this.CBGM4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CBGM4.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CBGM4.ForeColor = System.Drawing.Color.Black;
            this.CBGM4.Location = new System.Drawing.Point(177, 70);
            this.CBGM4.Name = "CBGM4";
            this.CBGM4.Size = new System.Drawing.Size(30, 39);
            this.CBGM4.TabIndex = 111;
            this.CBGM4.Text = "4";
            this.CBGM4.UseVisualStyleBackColor = false;
            // 
            // CBGM2
            // 
            this.CBGM2.BackColor = System.Drawing.Color.LightBlue;
            this.CBGM2.FlatAppearance.BorderSize = 0;
            this.CBGM2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CBGM2.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CBGM2.ForeColor = System.Drawing.Color.Black;
            this.CBGM2.Location = new System.Drawing.Point(177, 22);
            this.CBGM2.Name = "CBGM2";
            this.CBGM2.Size = new System.Drawing.Size(30, 39);
            this.CBGM2.TabIndex = 109;
            this.CBGM2.Text = "2";
            this.CBGM2.UseVisualStyleBackColor = false;
            // 
            // BGM4
            // 
            this.BGM4.BackColor = System.Drawing.Color.Silver;
            this.BGM4.FlatAppearance.BorderSize = 0;
            this.BGM4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.BGM4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BGM4.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.BGM4.ForeColor = System.Drawing.Color.Black;
            this.BGM4.Location = new System.Drawing.Point(210, 70);
            this.BGM4.Name = "BGM4";
            this.BGM4.Size = new System.Drawing.Size(126, 39);
            this.BGM4.TabIndex = 110;
            this.BGM4.Tag = "4";
            this.BGM4.UseVisualStyleBackColor = false;
            // 
            // BGM1
            // 
            this.BGM1.BackColor = System.Drawing.Color.Silver;
            this.BGM1.FlatAppearance.BorderSize = 0;
            this.BGM1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.BGM1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BGM1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.BGM1.ForeColor = System.Drawing.Color.Black;
            this.BGM1.Location = new System.Drawing.Point(45, 22);
            this.BGM1.Name = "BGM1";
            this.BGM1.Size = new System.Drawing.Size(126, 39);
            this.BGM1.TabIndex = 104;
            this.BGM1.Tag = "1";
            this.BGM1.Text = "전관방송 G.3";
            this.BGM1.UseVisualStyleBackColor = false;
            // 
            // CBGM3
            // 
            this.CBGM3.BackColor = System.Drawing.Color.LightBlue;
            this.CBGM3.FlatAppearance.BorderSize = 0;
            this.CBGM3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CBGM3.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CBGM3.ForeColor = System.Drawing.Color.Black;
            this.CBGM3.Location = new System.Drawing.Point(12, 70);
            this.CBGM3.Name = "CBGM3";
            this.CBGM3.Size = new System.Drawing.Size(30, 39);
            this.CBGM3.TabIndex = 107;
            this.CBGM3.Text = "3";
            this.CBGM3.UseVisualStyleBackColor = false;
            // 
            // CBGM1
            // 
            this.CBGM1.BackColor = System.Drawing.Color.LightBlue;
            this.CBGM1.FlatAppearance.BorderSize = 0;
            this.CBGM1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CBGM1.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.CBGM1.ForeColor = System.Drawing.Color.Black;
            this.CBGM1.Location = new System.Drawing.Point(12, 22);
            this.CBGM1.Name = "CBGM1";
            this.CBGM1.Size = new System.Drawing.Size(30, 39);
            this.CBGM1.TabIndex = 105;
            this.CBGM1.Text = "1";
            this.CBGM1.UseVisualStyleBackColor = false;
            // 
            // BGM3
            // 
            this.BGM3.BackColor = System.Drawing.Color.Silver;
            this.BGM3.FlatAppearance.BorderSize = 0;
            this.BGM3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.BGM3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BGM3.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.BGM3.ForeColor = System.Drawing.Color.Black;
            this.BGM3.Location = new System.Drawing.Point(45, 70);
            this.BGM3.Name = "BGM3";
            this.BGM3.Size = new System.Drawing.Size(126, 39);
            this.BGM3.TabIndex = 106;
            this.BGM3.Tag = "3";
            this.BGM3.Text = "BGM(MP3)";
            this.BGM3.UseVisualStyleBackColor = false;
            // 
            // btn_Alloff
            // 
            this.btn_Alloff.BackColor = System.Drawing.Color.Transparent;
            this.btn_Alloff.ForeColor = System.Drawing.Color.Yellow;
            this.btn_Alloff.Location = new System.Drawing.Point(1225, -15);
            this.btn_Alloff.Name = "btn_Alloff";
            this.btn_Alloff.setFontColor = System.Drawing.Color.Yellow;
            this.btn_Alloff.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_Alloff.setOFFimage")));
            this.btn_Alloff.setON = false;
            this.btn_Alloff.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_Alloff.setONimage")));
            this.btn_Alloff.setText = "전체 취소";
            this.btn_Alloff.setToggle = false;
            this.btn_Alloff.Size = new System.Drawing.Size(120, 60);
            this.btn_Alloff.TabIndex = 123;
            this.btn_Alloff.TabStop = false;
            this.btn_Alloff.Tag = "2";
            this.btn_Alloff.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Alloff.Click += new System.EventHandler(this.btn_Alloff_Click);
            // 
            // btn_Allon
            // 
            this.btn_Allon.BackColor = System.Drawing.Color.Transparent;
            this.btn_Allon.ForeColor = System.Drawing.Color.Yellow;
            this.btn_Allon.Location = new System.Drawing.Point(1106, -15);
            this.btn_Allon.Name = "btn_Allon";
            this.btn_Allon.setFontColor = System.Drawing.Color.Yellow;
            this.btn_Allon.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_Allon.setOFFimage")));
            this.btn_Allon.setON = false;
            this.btn_Allon.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_Allon.setONimage")));
            this.btn_Allon.setText = "전체 선택";
            this.btn_Allon.setToggle = false;
            this.btn_Allon.Size = new System.Drawing.Size(120, 60);
            this.btn_Allon.TabIndex = 124;
            this.btn_Allon.TabStop = false;
            this.btn_Allon.Tag = "2";
            this.btn_Allon.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Allon.Click += new System.EventHandler(this.btn_Allon_Click);
            // 
            // groupBox_mp3
            // 
            this.groupBox_mp3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.groupBox_mp3.Controls.Add(this.panel_music);
            this.groupBox_mp3.Controls.Add(this.avPlayer);
            this.groupBox_mp3.Controls.Add(this.btn_music);
            this.groupBox_mp3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox_mp3.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox_mp3.ForeColor = System.Drawing.Color.White;
            this.groupBox_mp3.Location = new System.Drawing.Point(1351, 617);
            this.groupBox_mp3.Name = "groupBox_mp3";
            this.groupBox_mp3.Size = new System.Drawing.Size(557, 324);
            this.groupBox_mp3.TabIndex = 517;
            this.groupBox_mp3.TabStop = false;
            this.groupBox_mp3.Text = "방송 음원";
            // 
            // panel_music
            // 
            this.panel_music.AutoScroll = true;
            this.panel_music.BackColor = System.Drawing.Color.Gray;
            this.panel_music.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.panel_music.ForeColor = System.Drawing.Color.Black;
            this.panel_music.Location = new System.Drawing.Point(12, 24);
            this.panel_music.Name = "panel_music";
            this.panel_music.Size = new System.Drawing.Size(478, 240);
            this.panel_music.TabIndex = 520;
            // 
            // avPlayer
            // 
            this.avPlayer.Enabled = true;
            this.avPlayer.Location = new System.Drawing.Point(12, 262);
            this.avPlayer.Name = "avPlayer";
            this.avPlayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("avPlayer.OcxState")));
            this.avPlayer.Size = new System.Drawing.Size(539, 49);
            this.avPlayer.TabIndex = 519;
            // 
            // btn_music
            // 
            this.btn_music.ForeColor = System.Drawing.Color.Black;
            this.btn_music.Location = new System.Drawing.Point(496, 24);
            this.btn_music.Name = "btn_music";
            this.btn_music.Size = new System.Drawing.Size(55, 131);
            this.btn_music.TabIndex = 518;
            this.btn_music.Text = "음원\r\n\r\n폴더";
            this.btn_music.UseVisualStyleBackColor = true;
            this.btn_music.Click += new System.EventHandler(this.btn_music_Click);
            // 
            // panel_tts
            // 
            this.panel_tts.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.panel_tts.Location = new System.Drawing.Point(1568, 34);
            this.panel_tts.Name = "panel_tts";
            this.panel_tts.Size = new System.Drawing.Size(341, 577);
            this.panel_tts.TabIndex = 520;
            // 
            // rhBbutton3
            // 
            this.rhBbutton3.BackColor = System.Drawing.Color.Transparent;
            this.rhBbutton3.ForeColor = System.Drawing.Color.Yellow;
            this.rhBbutton3.Location = new System.Drawing.Point(1789, -15);
            this.rhBbutton3.Name = "rhBbutton3";
            this.rhBbutton3.setFontColor = System.Drawing.Color.Yellow;
            this.rhBbutton3.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton3.setOFFimage")));
            this.rhBbutton3.setON = false;
            this.rhBbutton3.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton3.setONimage")));
            this.rhBbutton3.setText = "TTS";
            this.rhBbutton3.setToggle = false;
            this.rhBbutton3.Size = new System.Drawing.Size(120, 60);
            this.rhBbutton3.TabIndex = 521;
            this.rhBbutton3.TabStop = false;
            this.rhBbutton3.Tag = "2";
            this.rhBbutton3.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel_preset
            // 
            this.panel_preset.AutoScroll = true;
            this.panel_preset.BackColor = System.Drawing.Color.Black;
            this.panel_preset.Location = new System.Drawing.Point(1352, 32);
            this.panel_preset.Name = "panel_preset";
            this.panel_preset.Size = new System.Drawing.Size(210, 390);
            this.panel_preset.TabIndex = 522;
            // 
            // btn_preAdd
            // 
            this.btn_preAdd.BackColor = System.Drawing.Color.Transparent;
            this.btn_preAdd.ForeColor = System.Drawing.Color.Yellow;
            this.btn_preAdd.Location = new System.Drawing.Point(1441, -15);
            this.btn_preAdd.Name = "btn_preAdd";
            this.btn_preAdd.setFontColor = System.Drawing.Color.Yellow;
            this.btn_preAdd.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_preAdd.setOFFimage")));
            this.btn_preAdd.setON = false;
            this.btn_preAdd.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_preAdd.setONimage")));
            this.btn_preAdd.setText = "방송그룹 추가";
            this.btn_preAdd.setToggle = false;
            this.btn_preAdd.Size = new System.Drawing.Size(120, 60);
            this.btn_preAdd.TabIndex = 523;
            this.btn_preAdd.TabStop = false;
            this.btn_preAdd.Tag = "2";
            this.btn_preAdd.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_preAdd.Click += new System.EventHandler(this.btn_preAdd_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.groupBox4.Controls.Add(this.btn_callCancel);
            this.groupBox4.Controls.Add(this.btn_call5);
            this.groupBox4.Controls.Add(this.Ccall5);
            this.groupBox4.Controls.Add(this.btn_call2);
            this.groupBox4.Controls.Add(this.Ccall4);
            this.groupBox4.Controls.Add(this.Ccall2);
            this.groupBox4.Controls.Add(this.btn_call4);
            this.groupBox4.Controls.Add(this.btn_call1);
            this.groupBox4.Controls.Add(this.Ccall3);
            this.groupBox4.Controls.Add(this.Ccall1);
            this.groupBox4.Controls.Add(this.btn_call3);
            this.groupBox4.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox4.ForeColor = System.Drawing.Color.White;
            this.groupBox4.Location = new System.Drawing.Point(352, 773);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(344, 169);
            this.groupBox4.TabIndex = 524;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Call";
            // 
            // btn_callCancel
            // 
            this.btn_callCancel.BackColor = System.Drawing.Color.Silver;
            this.btn_callCancel.FlatAppearance.BorderSize = 0;
            this.btn_callCancel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.btn_callCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_callCancel.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_callCancel.ForeColor = System.Drawing.Color.Black;
            this.btn_callCancel.Location = new System.Drawing.Point(207, 117);
            this.btn_callCancel.Name = "btn_callCancel";
            this.btn_callCancel.Size = new System.Drawing.Size(127, 39);
            this.btn_callCancel.TabIndex = 116;
            this.btn_callCancel.Tag = "6";
            this.btn_callCancel.Text = "취소";
            this.btn_callCancel.UseVisualStyleBackColor = false;
            this.btn_callCancel.Click += new System.EventHandler(this.btn_callCancel_Click);
            // 
            // btn_call5
            // 
            this.btn_call5.BackColor = System.Drawing.Color.Silver;
            this.btn_call5.FlatAppearance.BorderSize = 0;
            this.btn_call5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.btn_call5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_call5.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_call5.ForeColor = System.Drawing.Color.Black;
            this.btn_call5.Location = new System.Drawing.Point(45, 117);
            this.btn_call5.Name = "btn_call5";
            this.btn_call5.Size = new System.Drawing.Size(126, 39);
            this.btn_call5.TabIndex = 112;
            this.btn_call5.Tag = "5";
            this.btn_call5.UseVisualStyleBackColor = false;
            // 
            // Ccall5
            // 
            this.Ccall5.BackColor = System.Drawing.Color.LightBlue;
            this.Ccall5.FlatAppearance.BorderSize = 0;
            this.Ccall5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Ccall5.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Ccall5.ForeColor = System.Drawing.Color.Black;
            this.Ccall5.Location = new System.Drawing.Point(12, 117);
            this.Ccall5.Name = "Ccall5";
            this.Ccall5.Size = new System.Drawing.Size(30, 39);
            this.Ccall5.TabIndex = 113;
            this.Ccall5.Text = "5";
            this.Ccall5.UseVisualStyleBackColor = false;
            // 
            // btn_call2
            // 
            this.btn_call2.BackColor = System.Drawing.Color.Silver;
            this.btn_call2.FlatAppearance.BorderSize = 0;
            this.btn_call2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.btn_call2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_call2.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_call2.ForeColor = System.Drawing.Color.Black;
            this.btn_call2.Location = new System.Drawing.Point(208, 22);
            this.btn_call2.Name = "btn_call2";
            this.btn_call2.Size = new System.Drawing.Size(126, 39);
            this.btn_call2.TabIndex = 108;
            this.btn_call2.Tag = "2";
            this.btn_call2.Text = "전관방송 G.4";
            this.btn_call2.UseVisualStyleBackColor = false;
            // 
            // Ccall4
            // 
            this.Ccall4.BackColor = System.Drawing.Color.LightBlue;
            this.Ccall4.FlatAppearance.BorderSize = 0;
            this.Ccall4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Ccall4.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Ccall4.ForeColor = System.Drawing.Color.Black;
            this.Ccall4.Location = new System.Drawing.Point(175, 70);
            this.Ccall4.Name = "Ccall4";
            this.Ccall4.Size = new System.Drawing.Size(30, 39);
            this.Ccall4.TabIndex = 111;
            this.Ccall4.Text = "4";
            this.Ccall4.UseVisualStyleBackColor = false;
            // 
            // Ccall2
            // 
            this.Ccall2.BackColor = System.Drawing.Color.LightBlue;
            this.Ccall2.FlatAppearance.BorderSize = 0;
            this.Ccall2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Ccall2.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Ccall2.ForeColor = System.Drawing.Color.Black;
            this.Ccall2.Location = new System.Drawing.Point(175, 22);
            this.Ccall2.Name = "Ccall2";
            this.Ccall2.Size = new System.Drawing.Size(30, 39);
            this.Ccall2.TabIndex = 109;
            this.Ccall2.Text = "2";
            this.Ccall2.UseVisualStyleBackColor = false;
            // 
            // btn_call4
            // 
            this.btn_call4.BackColor = System.Drawing.Color.Silver;
            this.btn_call4.FlatAppearance.BorderSize = 0;
            this.btn_call4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.btn_call4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_call4.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_call4.ForeColor = System.Drawing.Color.Black;
            this.btn_call4.Location = new System.Drawing.Point(208, 70);
            this.btn_call4.Name = "btn_call4";
            this.btn_call4.Size = new System.Drawing.Size(126, 39);
            this.btn_call4.TabIndex = 110;
            this.btn_call4.Tag = "4";
            this.btn_call4.UseVisualStyleBackColor = false;
            // 
            // btn_call1
            // 
            this.btn_call1.BackColor = System.Drawing.Color.Silver;
            this.btn_call1.FlatAppearance.BorderSize = 0;
            this.btn_call1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.btn_call1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_call1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_call1.ForeColor = System.Drawing.Color.Black;
            this.btn_call1.Location = new System.Drawing.Point(45, 22);
            this.btn_call1.Name = "btn_call1";
            this.btn_call1.Size = new System.Drawing.Size(126, 39);
            this.btn_call1.TabIndex = 104;
            this.btn_call1.Tag = "1";
            this.btn_call1.Text = "전관방송 G.3";
            this.btn_call1.UseVisualStyleBackColor = false;
            // 
            // Ccall3
            // 
            this.Ccall3.BackColor = System.Drawing.Color.LightBlue;
            this.Ccall3.FlatAppearance.BorderSize = 0;
            this.Ccall3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Ccall3.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Ccall3.ForeColor = System.Drawing.Color.Black;
            this.Ccall3.Location = new System.Drawing.Point(12, 70);
            this.Ccall3.Name = "Ccall3";
            this.Ccall3.Size = new System.Drawing.Size(30, 39);
            this.Ccall3.TabIndex = 107;
            this.Ccall3.Text = "3";
            this.Ccall3.UseVisualStyleBackColor = false;
            // 
            // Ccall1
            // 
            this.Ccall1.BackColor = System.Drawing.Color.LightBlue;
            this.Ccall1.FlatAppearance.BorderSize = 0;
            this.Ccall1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Ccall1.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Ccall1.ForeColor = System.Drawing.Color.Black;
            this.Ccall1.Location = new System.Drawing.Point(12, 22);
            this.Ccall1.Name = "Ccall1";
            this.Ccall1.Size = new System.Drawing.Size(30, 39);
            this.Ccall1.TabIndex = 105;
            this.Ccall1.Text = "1";
            this.Ccall1.UseVisualStyleBackColor = false;
            // 
            // btn_call3
            // 
            this.btn_call3.BackColor = System.Drawing.Color.Silver;
            this.btn_call3.FlatAppearance.BorderSize = 0;
            this.btn_call3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.btn_call3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_call3.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_call3.ForeColor = System.Drawing.Color.Black;
            this.btn_call3.Location = new System.Drawing.Point(45, 70);
            this.btn_call3.Name = "btn_call3";
            this.btn_call3.Size = new System.Drawing.Size(126, 39);
            this.btn_call3.TabIndex = 106;
            this.btn_call3.Tag = "3";
            this.btn_call3.Text = "BGM(MP3)";
            this.btn_call3.UseVisualStyleBackColor = false;
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.groupBox5.Controls.Add(this.richTextBox_scLog);
            this.groupBox5.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox5.ForeColor = System.Drawing.Color.White;
            this.groupBox5.Location = new System.Drawing.Point(1353, 428);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(208, 183);
            this.groupBox5.TabIndex = 525;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "스케쥴 동작 상태";
            // 
            // richTextBox_scLog
            // 
            this.richTextBox_scLog.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.richTextBox_scLog.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.richTextBox_scLog.Location = new System.Drawing.Point(6, 24);
            this.richTextBox_scLog.Name = "richTextBox_scLog";
            this.richTextBox_scLog.Size = new System.Drawing.Size(196, 153);
            this.richTextBox_scLog.TabIndex = 0;
            this.richTextBox_scLog.Text = "";
            // 
            // timer_reConnet
            // 
            this.timer_reConnet.Interval = 3000;
            this.timer_reConnet.Tick += new System.EventHandler(this.timer_reConnet_Tick);
            // 
            // btn_preErase
            // 
            this.btn_preErase.BackColor = System.Drawing.Color.Transparent;
            this.btn_preErase.ForeColor = System.Drawing.Color.Yellow;
            this.btn_preErase.Location = new System.Drawing.Point(1353, -15);
            this.btn_preErase.Name = "btn_preErase";
            this.btn_preErase.setFontColor = System.Drawing.Color.Yellow;
            this.btn_preErase.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_preErase.setOFFimage")));
            this.btn_preErase.setON = false;
            this.btn_preErase.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_preErase.setONimage")));
            this.btn_preErase.setText = "삭제";
            this.btn_preErase.setToggle = false;
            this.btn_preErase.Size = new System.Drawing.Size(87, 60);
            this.btn_preErase.TabIndex = 526;
            this.btn_preErase.TabStop = false;
            this.btn_preErase.Tag = "2";
            this.btn_preErase.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.groupBox6.Controls.Add(this.btn_music4);
            this.groupBox6.Controls.Add(this.btn_music3);
            this.groupBox6.Controls.Add(this.btn_music2);
            this.groupBox6.Controls.Add(this.btn_music1);
            this.groupBox6.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox6.ForeColor = System.Drawing.Color.White;
            this.groupBox6.Location = new System.Drawing.Point(1054, 773);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(291, 169);
            this.groupBox6.TabIndex = 528;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "즐겨찾기 음원";
            // 
            // btn_music4
            // 
            this.btn_music4.BackColor = System.Drawing.Color.Silver;
            this.btn_music4.FlatAppearance.BorderSize = 0;
            this.btn_music4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.btn_music4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_music4.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_music4.ForeColor = System.Drawing.Color.Black;
            this.btn_music4.Location = new System.Drawing.Point(12, 128);
            this.btn_music4.Name = "btn_music4";
            this.btn_music4.Size = new System.Drawing.Size(267, 32);
            this.btn_music4.TabIndex = 112;
            this.btn_music4.Tag = "2";
            this.btn_music4.Text = "전관방송 G.4";
            this.btn_music4.UseVisualStyleBackColor = false;
            // 
            // btn_music3
            // 
            this.btn_music3.BackColor = System.Drawing.Color.Silver;
            this.btn_music3.FlatAppearance.BorderSize = 0;
            this.btn_music3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.btn_music3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_music3.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_music3.ForeColor = System.Drawing.Color.Black;
            this.btn_music3.Location = new System.Drawing.Point(12, 92);
            this.btn_music3.Name = "btn_music3";
            this.btn_music3.Size = new System.Drawing.Size(267, 32);
            this.btn_music3.TabIndex = 111;
            this.btn_music3.Tag = "2";
            this.btn_music3.Text = "전관방송 G.4";
            this.btn_music3.UseVisualStyleBackColor = false;
            // 
            // btn_music2
            // 
            this.btn_music2.BackColor = System.Drawing.Color.Silver;
            this.btn_music2.FlatAppearance.BorderSize = 0;
            this.btn_music2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.btn_music2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_music2.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_music2.ForeColor = System.Drawing.Color.Black;
            this.btn_music2.Location = new System.Drawing.Point(12, 56);
            this.btn_music2.Name = "btn_music2";
            this.btn_music2.Size = new System.Drawing.Size(267, 32);
            this.btn_music2.TabIndex = 110;
            this.btn_music2.Tag = "2";
            this.btn_music2.Text = "전관방송 G.4";
            this.btn_music2.UseVisualStyleBackColor = false;
            // 
            // btn_music1
            // 
            this.btn_music1.BackColor = System.Drawing.Color.Silver;
            this.btn_music1.FlatAppearance.BorderSize = 0;
            this.btn_music1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.btn_music1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_music1.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_music1.ForeColor = System.Drawing.Color.Black;
            this.btn_music1.Location = new System.Drawing.Point(12, 20);
            this.btn_music1.Name = "btn_music1";
            this.btn_music1.Size = new System.Drawing.Size(267, 32);
            this.btn_music1.TabIndex = 109;
            this.btn_music1.Tag = "2";
            this.btn_music1.Text = "전관방송 G.4";
            this.btn_music1.UseVisualStyleBackColor = false;
            // 
            // frmBroadcast
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.ClientSize = new System.Drawing.Size(1920, 947);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.panel_preset);
            this.Controls.Add(this.panel_tts);
            this.Controls.Add(this.groupBox_mp3);
            this.Controls.Add(this.pg1_menu6);
            this.Controls.Add(this.panel_zone);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btn_Alloff);
            this.Controls.Add(this.btn_Allon);
            this.Controls.Add(this.rhBbutton3);
            this.Controls.Add(this.btn_preAdd);
            this.Controls.Add(this.btn_preErase);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmBroadcast";
            this.Text = "jh";
            this.Load += new System.EventHandler(this.frmBroadcast_Load);
            this.panel1.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.pg1_menu6.ResumeLayout(false);
            this.groupBox_mp3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.avPlayer)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel_zone;
        private System.Windows.Forms.GroupBox pg1_menu6;
        private System.Windows.Forms.Button BGM_cancel;
        private System.Windows.Forms.Button BGM5;
        private System.Windows.Forms.Button CBGM5;
        private System.Windows.Forms.Button BGM2;
        private System.Windows.Forms.Button CBGM4;
        private System.Windows.Forms.Button CBGM2;
        private System.Windows.Forms.Button BGM4;
        private System.Windows.Forms.Button BGM1;
        private System.Windows.Forms.Button CBGM3;
        private System.Windows.Forms.Button CBGM1;
        private System.Windows.Forms.Button BGM3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private RHBform.RHBbutton btn_Alloff;
        private System.Windows.Forms.GroupBox groupBox3;
        private RHBform.RHBbutton btn_Allon;
        private System.Windows.Forms.GroupBox groupBox_mp3;
        private AxWMPLib.AxWindowsMediaPlayer avPlayer;
        private System.Windows.Forms.Button btn_music;
        private System.Windows.Forms.Panel panel_tts;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private RHBform.RHBbutton rhBbutton3;
        private System.Windows.Forms.Panel panel_preset;
        private RHBform.RHBbutton btn_preAdd;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btn_callCancel;
        private System.Windows.Forms.Button btn_call5;
        private System.Windows.Forms.Button Ccall5;
        private System.Windows.Forms.Button btn_call2;
        private System.Windows.Forms.Button Ccall4;
        private System.Windows.Forms.Button Ccall2;
        private System.Windows.Forms.Button btn_call4;
        private System.Windows.Forms.Button btn_call1;
        private System.Windows.Forms.Button Ccall3;
        private System.Windows.Forms.Button Ccall1;
        private System.Windows.Forms.Button btn_call3;
        private RHBform.RHBbutton btn_erase1;
        private System.Windows.Forms.Panel panel_music;
        private System.Windows.Forms.GroupBox groupBox5;
        private usrNCOst btn_nco1;
        private usrNCOst btn_nco3;
        private usrNCOst btn_nco2;
        private System.Windows.Forms.Panel panel_NET;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.Timer timer_reConnet;
        private RHBform.RHBbutton btn_preErase;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button btn_music4;
        private System.Windows.Forms.Button btn_music3;
        private System.Windows.Forms.Button btn_music2;
        private System.Windows.Forms.Button btn_music1;
        private System.Windows.Forms.RichTextBox richTextBox_scLog;
    }
}