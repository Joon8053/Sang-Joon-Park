﻿namespace NCO_App
{
    partial class frmZone
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_title = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_title
            // 
            this.btn_title.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn_title.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_title.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_title.ForeColor = System.Drawing.Color.Black;
            this.btn_title.Location = new System.Drawing.Point(0, 0);
            this.btn_title.Name = "btn_title";
            this.btn_title.Size = new System.Drawing.Size(990, 33);
            this.btn_title.TabIndex = 2;
            this.btn_title.Text = "본관동 (NCO1)";
            this.btn_title.UseVisualStyleBackColor = false;
            this.btn_title.Click += new System.EventHandler(this.btn_title_Click);
            // 
            // frmZone
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(990, 36);
            this.Controls.Add(this.btn_title);
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmZone";
            this.Text = "frmZone";
            this.Load += new System.EventHandler(this.frmZone_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_title;
    }
}