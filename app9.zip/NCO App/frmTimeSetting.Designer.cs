﻿namespace NCO_App
{
    partial class frmTimeSetting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gr_End = new System.Windows.Forms.GroupBox();
            this.txt_End = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txt_Start = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_save = new System.Windows.Forms.Button();
            this.gr_End.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gr_End
            // 
            this.gr_End.Controls.Add(this.txt_End);
            this.gr_End.ForeColor = System.Drawing.Color.White;
            this.gr_End.Location = new System.Drawing.Point(14, 172);
            this.gr_End.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gr_End.Name = "gr_End";
            this.gr_End.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gr_End.Size = new System.Drawing.Size(291, 132);
            this.gr_End.TabIndex = 13;
            this.gr_End.TabStop = false;
            this.gr_End.Text = "종료 시간";
            // 
            // txt_End
            // 
            this.txt_End.ForeColor = System.Drawing.Color.Black;
            this.txt_End.Location = new System.Drawing.Point(32, 56);
            this.txt_End.Name = "txt_End";
            this.txt_End.Size = new System.Drawing.Size(220, 25);
            this.txt_End.TabIndex = 5;
            this.txt_End.Text = "00:00:00";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txt_Start);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(14, 15);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Size = new System.Drawing.Size(291, 132);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "시작 시간";
            // 
            // txt_Start
            // 
            this.txt_Start.ForeColor = System.Drawing.Color.Black;
            this.txt_Start.Location = new System.Drawing.Point(32, 69);
            this.txt_Start.Name = "txt_Start";
            this.txt_Start.Size = new System.Drawing.Size(220, 25);
            this.txt_Start.TabIndex = 4;
            this.txt_Start.Text = "00:00:00";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Yellow;
            this.label1.Location = new System.Drawing.Point(29, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(198, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "입력 형식 (24시간 23:00:00)";
            // 
            // btn_save
            // 
            this.btn_save.Location = new System.Drawing.Point(161, 328);
            this.btn_save.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(144, 44);
            this.btn_save.TabIndex = 11;
            this.btn_save.Text = "저장";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // frmTimeSetting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.ClientSize = new System.Drawing.Size(328, 400);
            this.Controls.Add(this.gr_End);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btn_save);
            this.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frmTimeSetting";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "시간 설정";
            this.Load += new System.EventHandler(this.frmTimeSetting_Load);
            this.gr_End.ResumeLayout(false);
            this.gr_End.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gr_End;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.TextBox txt_End;
        private System.Windows.Forms.TextBox txt_Start;
    }
}