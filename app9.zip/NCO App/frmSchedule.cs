﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;
using static System.Windows.Forms.AxHost;

namespace NCO_App
{
    public partial class frmSchedule : Form
    {

        frmMain app;
        public frmSchedule(frmMain main)
        {
            InitializeComponent();
            app = main;
        }

        bool flg_change = false;

        private void frmSchedule_Load(object sender, EventArgs e)
        {
            customCalendar1.goToToday();
            customCalendar1.onDayClick += CustomCalendar1_onDayClick;
            LoadData_Week();
            UpdateDyaGR();


            System.Timers.Timer timer = new System.Timers.Timer(3000); // 3초
            timer.Elapsed += Timer_Elapsed;
            timer.AutoReset = false;
            timer.Enabled = true;
        }

        private  void Timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            Invoke(new Action(() =>
            {

            }));
        }

        private void btn_nextMonth_Click(object sender, EventArgs e)
        {
            flg_change = true;
            customCalendar1.goToNextMonth();
        }

        private void btn_preMonth_Click(object sender, EventArgs e)
        {
            flg_change = true;
            customCalendar1.goToPreMonth();
        }

        private void btn_home_Click(object sender, EventArgs e)
        {
            flg_change = true;
            customCalendar1.goToToday();
        }

        private void customCalendar1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(customCalendar1.SelectedDate.ToString());
        }



        private void customCalendar1_MouseDown(object sender, MouseEventArgs e)
        {
            MessageBox.Show(customCalendar1.SelectedDate.ToString());
        }


        DateTime SetDate= DateTime.Now;
        private void CustomCalendar1_onDayClick(DateTime dt)
        {
            label_date.Text = dt.ToString("yyyy-MM-dd");
            SetDate = dt;
            UpdateDyaGR();
            if (flg_change == false)
            {
                DateTime today = DateTime.Now.Date;
                if (dt >= today)
                {
                    //  MessageBox.Show(dt.ToString());
                    ContextMenu m = new ContextMenu(); //메뉴에 들어갈 아이템을 만듭니다
                    MenuItem[] sub = new MenuItem[2];
                    for (int i = 0; i < 2; i++)
                    {
                        sub[i] = new MenuItem();
                        sub[i].Tag = i + 1;
                        sub[i].Click += btnDelMenu_Click;
                    }
                    sub[0].Text = "일정 추가";
                    sub[1].Text = "나기기";
                    m.MenuItems.Add(sub[0]);
                    m.MenuItems.Add(sub[1]);

                    Point position = Cursor.Position;
                    m.Show((Control)this, new Point(position.X, position.Y - 100));//현재 마우스가 위치한 장소에 메뉴를 띄워줍니다  
                }

            }
            flg_change = false;
            // grid view

        }

        public void UpdateDyaGR()
        {
            dg_day.Rows.Clear();
            LoadDay(SetDate);
            try
            {
                Key_Index.Clear();
                if (DaySCtmp.Count > 0)
                {
                    List<int> nDay = new List<int>();
                    List<string> nSchedule = new List<string>();
                    foreach (clsMonthScadule tmp in DaySCtmp)
                    {
                        nDay.Add(tmp.Day);
                        nSchedule.Add(tmp.Name);
                    }

                    Dictionary<int, string> dict = new Dictionary<int, string>();
                    for (int i = 0; i < nDay.Count; i++)
                    {
                        int key = nDay[i];
                        if (!dict.ContainsKey(key))
                        {
                            dict.Add(key, "*" + nSchedule[i]);
                        }
                        else
                        {
                            dict[key] += "\r*" + nSchedule[i];
                        }
                    }

                    int[] newA = dict.Keys.ToArray();
                    string[] newB = dict.Values.ToArray();
                    customCalendar1.SetSchedual(newA, newB, SetDate);

                    // data grid..
                    try
                    {
                        int cnt = 0;
                        for (int no = 0; no < DaySCtmp.Count; no++)
                        {
                            clsMonthScadule tmp = DaySCtmp[no];
                            if (tmp.Day == SetDate.Day)
                            {
                                dg_day.Rows.Add("", "00:00",true, "삭제");      // 데이터 그리드 행 추가
                                dg_day.Rows[cnt].Cells[0].Value = tmp.Name;
                                dg_day.Rows[cnt].Cells[2].Value = tmp.Auto;
                                dg_day.Rows[cnt++].Cells[1].Value = tmp.getStartTime();
                                Key_Index.Add(no);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                }
                else
                {
                    customCalendar1.SetSchedual(null, null, SetDate);
                }
                LockGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        List<int> Key_Index = new List<int>();
        private void Erase_DaySC(int index)
        {
            DaySCtmp.RemoveAt(Key_Index[index]);
            SaveDay(SetDate);
            UpdateDyaGR();
        }

        private void btnDelMenu_Click(object sender, EventArgs e)
        {
            int btn = Convert.ToInt16(((MenuItem)sender).Tag);
            if (btn == 1)
            {
                frmSCadd dlg = new frmSCadd(app, false,0,SetDate);
                dlg.ShowDialog();

            }
        }

        private void btn_DaySC_Click(object sender, EventArgs e)
        {
            frmSCadd dlg = new frmSCadd(app,true,0,SetDate);
            dlg.ShowDialog();
        }

        private void LockGrid()
        {
            for (int i = 0; i < dg_day.Rows.Count; i++)
            {
                dg_day.Rows[i].ReadOnly = true;
            }
            for (int i = 0; i < dg_week.Rows.Count; i++)
            {
                dg_week.Rows[i].ReadOnly = true;
            }
            //정렬안되게 하기.
            foreach (DataGridViewColumn col in dg_day.Columns)
            {
                col.SortMode = DataGridViewColumnSortMode.NotSortable;
            }
            foreach (DataGridViewColumn col in dg_week.Columns)
            {
                col.SortMode = DataGridViewColumnSortMode.NotSortable;
            }
        }


        private void ADD_Text(RichTextBox box, string text, Color color)
        {
            if (text == null)
                text = "";
            box.SelectionStart = box.TextLength;
            box.SelectionLength = 0;
            box.SelectionColor = color;
            box.AppendText(text);
            box.AppendText(" \r\n");  // line feed
            box.SelectionColor = box.ForeColor;
            box.SelectionStart = box.Text.Length;
            box.ScrollToCaret();

            if (box.TextLength > 100000)
                box.Text = "";
        }

        private void Add_log(string text, Color cl)
        {
            ADD_Text(richTextBox_log, text, cl);
            app.Brodcast_Log(text, cl); 
        }

        List<TimerTask> DaySchedule = new List<TimerTask>();

        private void AddDay_schedule(TimerTask task)
        {
            task.ID = DaySchedule.Count;
            DaySchedule.Add(task);
        }

        private void EraeDay_schedule()
        {
            DaySchedule.Clear();
        }

        private void LogClear()
        {
            richTextBox_log.Text = "";
            app.Brocast_LogClear();
        }
        private void LogUpdate()
        {
            LogClear();

            DaySchedule.Sort((s1, s2) => s1.Time.CompareTo(s2.Time));
/*            List<TimerTask> mSC = new List<TimerTask>();

            foreach (TimerTask tt in DaySchedule)
            {
                mSC.Add(tt);
            }
            DaySchedule = mSC;*/
            foreach (TimerTask task in DaySchedule)
            {
                Color cl = Color.Lime;
                string ss = task.Time.ToString(@"hh\:mm\:ss");
                string result = task.Finish ? "(완료)" : "(대기중)";
                if (task.Finish) cl = Color.White;
                ss = string.Format(" {0} {1}", ss, task.Name);
                if (task.Eror != "")
                {
                    ss += "--\r" + task.Eror;
                    cl = Color.Red;
                }
                else
                {
                    ss += result;
                }
                Add_log(ss, cl);

            }
        }


        public void LoadData_Week()
        {
            EraeDay_schedule();
            dg_week.AllowUserToAddRows = false;          //데이타 그리드뷰 마지막 빈줄 삭제
            dg_day.AllowUserToAddRows = false;
            dg_week.Rows.Clear();
            LoadWeek();
            dg_week.EnableHeadersVisualStyles = false; // 이 부분 추가
            dg_day.EnableHeadersVisualStyles = false; // 이 부분 추가
                                                      // 헤더 스타일 직접 설정
            dg_week.ColumnHeadersDefaultCellStyle.BackColor = Color.Silver;
            dg_day.ColumnHeadersDefaultCellStyle.BackColor = Color.Silver;

            try
            {
                int dayOfWeekIndex = (int)DateTime.Now.DayOfWeek;
                if (weekSC.Count > 0)
                {
                    for (int no = 0; no < weekSC.Count; no++)
                    {
                        dg_week.Rows.Add("", false, false, false, false, false, false, false, false, "00:00", "-", "", "", "삭제");      // 데이터 그리드 행 추가

                        clsMonthScadule tmp = weekSC[no];

                        for (int i = 0; i < tmp.EnWeek.Length; i++)
                        {
                            dg_week.Rows[no].Cells[i + 1].Value = tmp.EnWeek[i];
                        }
                        if (tmp.EnWeek[dayOfWeekIndex]==true)  // 오늘 일정이 있는경우.
                        {
                            TimerTask mTask = new TimerTask();
                            if (tmp.Auto)
                            {
                                mTask.Name = tmp.Name;
                                mTask.FunctionType = TimerTask.FncType.WeekFnc;
                                mTask.FuncitonIndex = no;
                                mTask.Time = TimeSpan.FromSeconds(tmp.startTime);
                                AddDay_schedule(mTask);
                            }
                            else
                            {
                                mTask.Name = tmp.Name+"(시작)";
                                mTask.FunctionType = TimerTask.FncType.WeekFnc;
                                mTask.FuncitonIndex = no;
                                mTask.Time = TimeSpan.FromSeconds(tmp.startTime);
                                AddDay_schedule(mTask);
                                TimerTask mTask2 = new TimerTask();
                                mTask2.Name = tmp.Name + "(종료)";
                                mTask2.FunctionType = TimerTask.FncType.WeekFnc_End;
                                mTask2.FuncitonIndex = no;
                                mTask2.Time = TimeSpan.FromSeconds(tmp.endTime);
                                AddDay_schedule(mTask2);
                            }
                        }

                        dg_week.Rows[no].Cells[0].Value = tmp.Name;
                        dg_week.Rows[no].Cells[8].Value = tmp.Auto;
                        dg_week.Rows[no].Cells[9].Value = tmp.getStartTime();
                        if (tmp.Auto == false)
                        {
                            dg_week.Rows[no].Cells[10].Value = tmp.getEndtTime();
                        }

                        dg_week.Rows[no].Cells[11].Value = app.defBGMs[tmp.input].Name;
                        dg_week.Rows[no].Cells[12].Value = tmp.getMusicFile();
                    }
                }
                LockGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

            LoadDay();
            try
            {
                if (DaySC.Count > 0)
                {
                    DateTime dt = DateTime.Now;
                    int cnt = 0;
                    for (int no = 0; no < DaySC.Count; no++)
                    {
                        clsMonthScadule tmp = DaySC[no];
                        if (tmp.Day == dt.Day)
                        {
                            TimerTask mTask = new TimerTask();
                            if (tmp.Auto)
                            {
                                mTask.Name = tmp.Name;
                                mTask.FunctionType = TimerTask.FncType.DayFnc;
                                mTask.FuncitonIndex = no;
                                mTask.Time = TimeSpan.FromSeconds(tmp.startTime);
                                AddDay_schedule(mTask);
                            }
                            else
                            {
                                mTask.Name = tmp.Name + "(시작)";
                                mTask.FunctionType = TimerTask.FncType.DayFnc;
                                mTask.FuncitonIndex = no;
                                mTask.Time = TimeSpan.FromSeconds(tmp.startTime);
                                AddDay_schedule(mTask);
                                TimerTask mTask2 = new TimerTask();
                                mTask2.Name = tmp.Name + "(종료)";
                                mTask2.FunctionType = TimerTask.FncType.DayFnc_End;
                                mTask2.FuncitonIndex = no;
                                mTask2.Time = TimeSpan.FromSeconds(tmp.endTime);
                                AddDay_schedule(mTask2);
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            LogUpdate();
        }



        List<clsMonthScadule> weekSC = new List<clsMonthScadule>();
        List<clsMonthScadule> DaySC = new List<clsMonthScadule>();
        List<clsMonthScadule> DaySCtmp = new List<clsMonthScadule>();
        private void LoadWeek()
        {
            string file = Application.StartupPath + "\\schedule\\week";
            if (File.Exists(file) == true)
            {
                using (StreamReader reader = File.OpenText(file))
                {
                    string ss = reader.ReadToEnd();
                    try
                    {
                        weekSC = JsonConvert.DeserializeObject<List<clsMonthScadule>>(ss);
                    }
                    catch
                    {

                    }
                }
            }
        }

        public void SaveWeek()
        {
            string file = Application.StartupPath + "\\schedule\\week";
            string jdata = JsonConvert.SerializeObject(weekSC);

            using (StreamWriter writer = File.CreateText(file))
            {
                writer.WriteLine(jdata);
            }
            app.UpdateWeekSC();
        }

        public void SaveDay(DateTime setDate)
        {
            string file = Application.StartupPath + "\\schedule\\" + setDate.ToString("yyyy-MM");

            string jdata = JsonConvert.SerializeObject(DaySCtmp);

            using (StreamWriter writer = File.CreateText(file))
            {
                writer.WriteLine(jdata);
            }
        }
        private void LoadDay()
        {
            string file = Application.StartupPath + "\\schedule\\" + DateTime.Now.ToString("yyyy-MM");
            if (File.Exists(file) == true)
            {
                using (StreamReader reader = File.OpenText(file))
                {
                    string ss = reader.ReadToEnd();
                    try
                    {
                        DaySC = JsonConvert.DeserializeObject<List<clsMonthScadule>>(ss);
                    }
                    catch
                    {

                    }
                }
            }
        }

        private void LoadDay(DateTime selTime)
        {
            string file = Application.StartupPath + "\\schedule\\" + selTime.ToString("yyyy-MM");
            if (File.Exists(file) == true)
            {
                using (StreamReader reader = File.OpenText(file))
                {
                    string ss = reader.ReadToEnd();
                    try
                    {
                        DaySCtmp = JsonConvert.DeserializeObject<List<clsMonthScadule>>(ss);
                    }
                    catch
                    {

                    }
                }
            }
            else
            {
                DaySCtmp.Clear();
            }
        }

        private void dg_day_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int row_value;
            int column_value;

            column_value = Convert.ToInt16(e.ColumnIndex);                                                                  //열의 값을 가져옴
            row_value = Convert.ToInt16(e.RowIndex);                                                                       //행의 값을 가져옴

            if ((e.ColumnIndex == 3) && (row_value > -1))
            {
                DateTime currentDate = DateTime.Now;
                DateTime oneDayBefore = currentDate.AddDays(-1);  // 하루전보다 클경우 삭제 가능(당일 삭제 가능) 1루전 날짜를 가져옴
                if (SetDate > oneDayBefore)
                {
                    DialogResult result = MessageBox.Show("해당 스케쥴을 삭제 하시겠습니까?", "사용자 확인", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        Erase_DaySC(row_value);
                    }
                }
            }
        }

        int week_Index = 0;
        private void dg_week_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int row_value;
            int column_value;

            column_value = Convert.ToInt16(e.ColumnIndex);                                                                  //열의 값을 가져옴
            row_value = Convert.ToInt16(e.RowIndex);                                                                       //행의 값을 가져옴

            if ((e.ColumnIndex == 13) && (row_value > -1))
            {
                //gr_weekEdit.Visible = true;
                week_Index = row_value;


                DialogResult result = MessageBox.Show("해당 스케쥴을 삭제 하시겠습니까?", "사용자 확인", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    weekSC.RemoveAt(week_Index);
                    SaveWeek();
                    Schedule_Start(false);
                }
            }
        }

        private void btn_weekDel_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("해당 스케쥴을 삭제 하시겠습니까?", "사용자 확인", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                weekSC.RemoveAt(week_Index);
                SaveWeek();
                Thread.Sleep(10);
                Schedule_Start(false);
            }

            gr_weekEdit.Visible = false;
        }

        private void btn_weekEdit_Click(object sender, EventArgs e)
        {
            gr_weekEdit.Visible = false;
        }

        private void btn_weekCancel_Click(object sender, EventArgs e)
        {
            gr_weekEdit.Visible = false;
        }


        public void SaveFinish(DateTime setDate)
        {
            string file = Application.StartupPath + "\\schedule\\Finish";

            string jdata = JsonConvert.SerializeObject(DaySCtmp);

            using (StreamWriter writer = File.CreateText(file))
            {
                writer.WriteLine(jdata);
            }
        }
        private void LoadFinish()
        {
            string file = Application.StartupPath + "\\schedule\\Finish";
            if (File.Exists(file) == true)
            {
                using (StreamReader reader = File.OpenText(file))
                {
                    string ss = reader.ReadToEnd();
                    try
                    {
                        play_Finish = JsonConvert.DeserializeObject< FinshSchedule> (ss);
                    }
                    catch
                    {

                    }
                }
            }
        }

        // schedule log display


        // schedule file check..  프로그램이 재 실행되는경우. 이전 스케쥴이 진행되었는지 확인.


        public class FinshSchedule
        {
            public List<int> finish_id = new List<int>();
            public int today_count = 0;
        }

        FinshSchedule play_Finish = new FinshSchedule();
        public void Schedule_Start(bool NexDay)
        {
            app.Add_Log(frmMain.LogTag.schedule,Color.Yellow, "스케쥴 파일 불러오기");
            if (NexDay == true)
            {
                //  LoadFinish();   // 0 hour next day
                LoadData_Week();
                UpdateScheduleWithNewData(GetDailySchedule);

            }
            else
            {
                // LoadFinish();    // program start.
                LoadData_Week();
                UpdateScheduleWithNewData(GetDailySchedule);
            }
        }

        private List<TimerTask> GetDailySchedule()  // 예상 기존 값이 바뀌면 타이머에 영향을 주무르 복사해서 넣고, 변경되면 다시 업데이트 되도록 수정
        {
            List<TimerTask> copiedDaySchedule1 = new List<TimerTask>(DaySchedule);
            return copiedDaySchedule1;
        }

        private Dictionary<int, System.Timers.Timer> timerDictionary = new Dictionary<int, System.Timers.Timer>();
        private Dictionary<int, TimerTask> timerTaskDictionary = new Dictionary<int, TimerTask>();

        public void UpdateScheduleWithNewData(Func<List<TimerTask>> getNewScheduleMethod)
        {
            if (getNewScheduleMethod != null)
            {
                foreach (var timer in timerDictionary.Values)
                {
                    timer.Stop();
                }
                timerDictionary.Clear();
                timerTaskDictionary.Clear();

                List<TimerTask> timerTasks = getNewScheduleMethod();
                SetTasksToTimers(timerTasks);
            }
        }

        private void setFinish(int id,string msg)
        {
            foreach (TimerTask tt in DaySchedule)
            {
                if (tt.ID == id)
                {
                    tt.Eror = msg;
                    tt.Finish = true;

                }
            }
        }

        int Active_ID = 0;
        TimerTask.FncType Active_Fnc = TimerTask.FncType.WeekFnc;
        private void Action_Schedule(int id)
        {
            foreach (TimerTask tt in DaySchedule)
            {
                if (tt.ID == id)
                {
                    Active_Fnc = tt.FunctionType;
                    Active_ID = tt.FuncitonIndex;
                    // select zone?
                    if (tt.FunctionType == TimerTask.FncType.WeekFnc)
                    {
                        app.RemoteZoneSelect(weekSC[Active_ID].Zone);
                        Thread.Sleep(10);
                        app.RemoteBGMclick((weekSC[Active_ID].input));
                        // play function..
                        if (weekSC[Active_ID].Auto)
                        {
                            if (weekSC[Active_ID].MusicFile.Count > 0)
                            {
                                app.AddPlayList(weekSC[Active_ID].MusicFile);
                            }
                        }
                        else
                        {
                            if (weekSC[Active_ID].MusicFile.Count > 0)
                            {
                                app.AddPlayList_Loop(weekSC[Active_ID].MusicFile);
                            }
                        }
                    }
                    else if (tt.FunctionType == TimerTask.FncType.DayFnc)
                    {
                        app.RemoteZoneSelect(DaySC[Active_ID].Zone);
                        Thread.Sleep(10);
                        app.RemoteBGMclick((DaySC[Active_ID].input));
                        // play function..
                        if (DaySC[Active_ID].Auto)
                        {
                            if (DaySC[Active_ID].MusicFile.Count > 0)
                            {
                                app.AddPlayList(DaySC[Active_ID].MusicFile);
                            }
                        }
                        else
                        {
                            if (DaySC[Active_ID].MusicFile.Count > 0)
                            {
                                app.AddPlayList_Loop(DaySC[Active_ID].MusicFile);
                            }
                        }
                    }
                    else if (tt.FunctionType == TimerTask.FncType.WeekFnc_End)
                    {
                        app.Add_Log(frmMain.LogTag.schedule, Color.Yellow, tt.Name + " (방송 종료 되었습니다.)");
                        app.RemoteZoneSelect(weekSC[Active_ID].Zone);
                        Thread.Sleep(10);
                        app.RemoteBGMcancel();
                        app.MusicStop();
                    }
                    else if (tt.FunctionType == TimerTask.FncType.DayFnc_End)
                    {
                        app.Add_Log(frmMain.LogTag.schedule, Color.Yellow, tt.Name + " (방송 종료 되었습니다.)");
                        app.RemoteZoneSelect(DaySC[Active_ID].Zone);
                        Thread.Sleep(10);
                        app.RemoteBGMcancel();
                        app.MusicStop();
                    }
                }
            }
        }

        public void MusicAutoStop()
        {
            if (Active_Fnc == TimerTask.FncType.WeekFnc)
            {
                app.Add_Log(frmMain.LogTag.schedule, Color.Yellow, weekSC[Active_ID].Name + " (방송이 자동 종료 되었습니다.)");
                app.RemoteZoneSelect(weekSC[Active_ID].Zone);
                Thread.Sleep(10);
                app.RemoteBGMcancel();
            }
            else
            {
                app.Add_Log(frmMain.LogTag.schedule, Color.Yellow, DaySC[Active_ID].Name + " (방송이 자동 종료 되었습니다.)");
                app.RemoteZoneSelect(DaySC[Active_ID].Zone);
                Thread.Sleep(10);
                app.RemoteBGMcancel();
            }
        }

        private void SetTasksToTimers(List<TimerTask> timerTasks)
        {
            foreach (var task in timerTasks)
            {
                int id = (int)task.Time.TotalMilliseconds;

                if (DateTime.Now.TimeOfDay > task.Time)
                {
                    //지난 스케쥴 체크
                    app.Add_Log(frmMain.LogTag.schedule, Color.Red, task.Name + " (프로그램 실행보다 이전 방송)");
                    setFinish(task.ID, "시간이 지남");

                    LogUpdate();
                    //scheduleLog.Add($"Time: {task.Time}, Name: {task.Name}, FunctionCode: {task.FunctionCode} - This task is expired.");
                }
                else
                {
                    System.Timers.Timer timer = new System.Timers.Timer((task.Time - DateTime.Now.TimeOfDay).TotalMilliseconds);
                    timer.Elapsed += (sender, e) => Timer_Elapsed(sender, e, id);
                    timer.AutoReset = false;
                    timer.Start();

                    timerDictionary[id] = timer;
                    timerTaskDictionary[id] = task;
                }
            }
        }

        private void Timer_Elapsed(object sender, ElapsedEventArgs e, int id)
        {
            if (timerDictionary.ContainsKey(id) && timerTaskDictionary.ContainsKey(id))
            {
                TimerTask task = timerTaskDictionary[id];
                this.Invoke((Action)(() =>
                {
                    // 동작 스케쥴.
                    app.Add_Log(frmMain.LogTag.schedule, Color.Yellow, task.Name + " (방송 시작)");
                    //MessageBox.Show($"Time: {task.Time}, Name: {task.Name}, FunctionCode: {task.FuncitonIndex}", "Scheduled Task");
                    Action_Schedule(task.ID);
                    setFinish(task.ID, "");
                    LogUpdate();
                }));

                timerDictionary[id].Stop();
                timerDictionary.Remove(id);
                timerTaskDictionary.Remove(id);
            }
        }
    }
}
