﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NCO_App
{
    public partial class frmTimeSetting : Form
    {
        bool flg_EndTime;
        public frmTimeSetting(bool endTime)
        {
            InitializeComponent();

            flg_EndTime = endTime;
            if(flg_EndTime)
            {
                gr_End.Visible = false;
                int pos = btn_save.Top - gr_End.Top;
                this.Size = new Size(this.Width, this.Height-pos);
                btn_save.Top = gr_End.Top;
            }
            _width = this.Width;
            _height = this.Height;
            this.MinimumSize = new Size(_width, _height);
            this.MaximumSize = new Size(_width, _height);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.Resize += Form1_Resize;
        }

        private int _width;
        private int _height;

        private void Form1_Resize(object sender, EventArgs e)
        {
            this.Width = _width;
            this.Height = _height;
        }

        private void frmTimeSetting_Load(object sender, EventArgs e)
        {
            this.TopMost = true;
        }

        public event Action<DateTime, DateTime> OnUpdate;
        private void btn_save_Click(object sender, EventArgs e)
        {
            if (flg_EndTime)
            {
                try
                {

                    DateTime stime = DateTime.ParseExact(txt_Start.Text, "HH:mm:ss", CultureInfo.InvariantCulture);
                    DateTime etime = DateTime.ParseExact(txt_Start.Text, "HH:mm:ss", CultureInfo.InvariantCulture);
                    OnUpdate?.Invoke(stime, etime);
                }
                catch
                {
                    txt_Start.Text = "";
                    txt_End.Text = "";
                    MessageBox.Show("시간 형식을 맞추어 입력하세요..");
                    return;
                }
            }
            else
            {
                try
                {

                    DateTime stime = DateTime.ParseExact(txt_Start.Text, "HH:mm:ss", CultureInfo.InvariantCulture);
                    DateTime etime = DateTime.ParseExact(txt_End.Text, "HH:mm:ss", CultureInfo.InvariantCulture);

                    if (stime >= etime)
                    {
                        MessageBox.Show("시작시간이 종료시간과 같거나 큽니다!!");
                        return;
                    }
                    OnUpdate?.Invoke(stime, etime);
                }
                catch
                {
                    txt_Start.Text = "";
                    txt_End.Text = "";
                    MessageBox.Show("시간 형식을 맞추어 입력하세요..");
                    return;
                }
            }
            this.Close();
        }
    }
}
