﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NCO_App
{
    public partial class usrNCO : Component
    {
        public usrNCO()
        {
            InitializeComponent();
        }

        public usrNCO(IContainer container)
        {
            container.Add(this);

            InitializeComponent();
        }
    }
}
