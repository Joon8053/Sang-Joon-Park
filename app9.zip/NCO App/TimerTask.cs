﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NCO_App
{
    public class TimerTask
    {
        public enum FncType { WeekFnc,DayFnc, WeekFnc_End, DayFnc_End }
        public TimeSpan Time { get; set; }
        public string Name { get; set; }
        public FncType FunctionType { get; set; }
        public int FuncitonIndex { get; set; }
        public bool Finish { set; get; } = false;
        public string Eror = "";
        public int ID;
    }
}
