﻿namespace NCO_App
{
    partial class frmMain
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.panel_head = new System.Windows.Forms.Panel();
            this.btn_log = new RHBform.RHBbutton();
            this.btn_FaultClear = new RHBform.RHBbutton();
            this.btn_fireClear = new RHBform.RHBbutton();
            this.label_t = new System.Windows.Forms.Label();
            this.label_title = new System.Windows.Forms.Label();
            this.pictureBox_logo = new System.Windows.Forms.PictureBox();
            this.btn_mini = new System.Windows.Forms.Button();
            this.btn_close = new System.Windows.Forms.Button();
            this.btn_menu1 = new RHBform.RHBbutton();
            this.btn_menu2 = new RHBform.RHBbutton();
            this.panel_base = new System.Windows.Forms.Panel();
            this.btn_menu3 = new RHBform.RHBbutton();
            this.btn_menu4 = new RHBform.RHBbutton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label_time = new System.Windows.Forms.Label();
            this.label_date = new System.Windows.Forms.Label();
            this.pictureBox_bg = new System.Windows.Forms.PictureBox();
            this.timer_rTime = new System.Windows.Forms.Timer(this.components);
            this.timer_start = new System.Windows.Forms.Timer(this.components);
            this.timer_Reconnect = new System.Windows.Forms.Timer(this.components);
            this.panel_head.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_logo)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_bg)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_head
            // 
            this.panel_head.BackColor = System.Drawing.Color.Black;
            this.panel_head.Controls.Add(this.btn_log);
            this.panel_head.Controls.Add(this.btn_FaultClear);
            this.panel_head.Controls.Add(this.btn_fireClear);
            this.panel_head.Controls.Add(this.label_t);
            this.panel_head.Controls.Add(this.label_title);
            this.panel_head.Controls.Add(this.pictureBox_logo);
            this.panel_head.Controls.Add(this.btn_mini);
            this.panel_head.Controls.Add(this.btn_close);
            this.panel_head.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_head.ForeColor = System.Drawing.Color.White;
            this.panel_head.Location = new System.Drawing.Point(0, 0);
            this.panel_head.Name = "panel_head";
            this.panel_head.Size = new System.Drawing.Size(1904, 38);
            this.panel_head.TabIndex = 3;
            // 
            // btn_log
            // 
            this.btn_log.BackColor = System.Drawing.Color.Gray;
            this.btn_log.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_log.ForeColor = System.Drawing.Color.Yellow;
            this.btn_log.Location = new System.Drawing.Point(1573, -17);
            this.btn_log.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_log.Name = "btn_log";
            this.btn_log.setFontColor = System.Drawing.Color.Yellow;
            this.btn_log.setOFFimage = null;
            this.btn_log.setON = false;
            this.btn_log.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_log.setONimage")));
            this.btn_log.setText = "로그 보기";
            this.btn_log.setToggle = false;
            this.btn_log.Size = new System.Drawing.Size(162, 75);
            this.btn_log.TabIndex = 469;
            this.btn_log.TabStop = false;
            this.btn_log.Tag = "4";
            this.btn_log.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_log.Click += new System.EventHandler(this.btn_log_Click);
            // 
            // btn_FaultClear
            // 
            this.btn_FaultClear.BackColor = System.Drawing.Color.Navy;
            this.btn_FaultClear.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_FaultClear.ForeColor = System.Drawing.Color.Yellow;
            this.btn_FaultClear.Location = new System.Drawing.Point(1407, -17);
            this.btn_FaultClear.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_FaultClear.Name = "btn_FaultClear";
            this.btn_FaultClear.setFontColor = System.Drawing.Color.Yellow;
            this.btn_FaultClear.setOFFimage = null;
            this.btn_FaultClear.setON = false;
            this.btn_FaultClear.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_FaultClear.setONimage")));
            this.btn_FaultClear.setText = "에러 복구";
            this.btn_FaultClear.setToggle = false;
            this.btn_FaultClear.Size = new System.Drawing.Size(162, 75);
            this.btn_FaultClear.TabIndex = 468;
            this.btn_FaultClear.TabStop = false;
            this.btn_FaultClear.Tag = "4";
            this.btn_FaultClear.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_FaultClear.Click += new System.EventHandler(this.btn_FaultClear_Click);
            // 
            // btn_fireClear
            // 
            this.btn_fireClear.BackColor = System.Drawing.Color.Navy;
            this.btn_fireClear.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_fireClear.ForeColor = System.Drawing.Color.Yellow;
            this.btn_fireClear.Location = new System.Drawing.Point(1241, -18);
            this.btn_fireClear.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_fireClear.Name = "btn_fireClear";
            this.btn_fireClear.setFontColor = System.Drawing.Color.Yellow;
            this.btn_fireClear.setOFFimage = null;
            this.btn_fireClear.setON = false;
            this.btn_fireClear.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_fireClear.setONimage")));
            this.btn_fireClear.setText = "화재 복구";
            this.btn_fireClear.setToggle = false;
            this.btn_fireClear.Size = new System.Drawing.Size(162, 75);
            this.btn_fireClear.TabIndex = 467;
            this.btn_fireClear.TabStop = false;
            this.btn_fireClear.Tag = "4";
            this.btn_fireClear.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_fireClear.Click += new System.EventHandler(this.btn_fireClear_Click);
            // 
            // label_t
            // 
            this.label_t.AutoSize = true;
            this.label_t.BackColor = System.Drawing.Color.Transparent;
            this.label_t.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_t.ForeColor = System.Drawing.Color.White;
            this.label_t.Location = new System.Drawing.Point(215, 7);
            this.label_t.Name = "label_t";
            this.label_t.Size = new System.Drawing.Size(228, 24);
            this.label_t.TabIndex = 465;
            this.label_t.Text = "방송 제어 프로그램";
            // 
            // label_title
            // 
            this.label_title.AutoSize = true;
            this.label_title.Location = new System.Drawing.Point(1829, 17);
            this.label_title.Name = "label_title";
            this.label_title.Size = new System.Drawing.Size(71, 12);
            this.label_title.TabIndex = 464;
            this.label_title.Text = "sn(2307223)";
            // 
            // pictureBox_logo
            // 
            this.pictureBox_logo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox_logo.BackgroundImage")));
            this.pictureBox_logo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox_logo.Location = new System.Drawing.Point(4, 2);
            this.pictureBox_logo.Name = "pictureBox_logo";
            this.pictureBox_logo.Size = new System.Drawing.Size(158, 34);
            this.pictureBox_logo.TabIndex = 463;
            this.pictureBox_logo.TabStop = false;
            // 
            // btn_mini
            // 
            this.btn_mini.BackColor = System.Drawing.Color.White;
            this.btn_mini.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btn_mini.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.btn_mini.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_mini.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_mini.ForeColor = System.Drawing.Color.Black;
            this.btn_mini.Location = new System.Drawing.Point(1036, 4);
            this.btn_mini.Name = "btn_mini";
            this.btn_mini.Size = new System.Drawing.Size(44, 27);
            this.btn_mini.TabIndex = 462;
            this.btn_mini.Text = "_";
            this.btn_mini.UseVisualStyleBackColor = false;
            this.btn_mini.Visible = false;
            // 
            // btn_close
            // 
            this.btn_close.BackColor = System.Drawing.Color.White;
            this.btn_close.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btn_close.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.btn_close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_close.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_close.ForeColor = System.Drawing.Color.Black;
            this.btn_close.Location = new System.Drawing.Point(1086, 4);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(44, 27);
            this.btn_close.TabIndex = 461;
            this.btn_close.Text = "X";
            this.btn_close.UseVisualStyleBackColor = false;
            this.btn_close.Visible = false;
            // 
            // btn_menu1
            // 
            this.btn_menu1.BackColor = System.Drawing.Color.Transparent;
            this.btn_menu1.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_menu1.ForeColor = System.Drawing.Color.Yellow;
            this.btn_menu1.Location = new System.Drawing.Point(1, 22);
            this.btn_menu1.Name = "btn_menu1";
            this.btn_menu1.setFontColor = System.Drawing.Color.Yellow;
            this.btn_menu1.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_menu1.setOFFimage")));
            this.btn_menu1.setON = false;
            this.btn_menu1.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_menu1.setONimage")));
            this.btn_menu1.setText = "방송 제어";
            this.btn_menu1.setToggle = false;
            this.btn_menu1.Size = new System.Drawing.Size(142, 60);
            this.btn_menu1.TabIndex = 23;
            this.btn_menu1.TabStop = false;
            this.btn_menu1.Tag = "1";
            this.btn_menu1.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_menu1.Click += new System.EventHandler(this.btn_menu1_Click);
            // 
            // btn_menu2
            // 
            this.btn_menu2.BackColor = System.Drawing.Color.Transparent;
            this.btn_menu2.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_menu2.ForeColor = System.Drawing.Color.Yellow;
            this.btn_menu2.Location = new System.Drawing.Point(143, 22);
            this.btn_menu2.Name = "btn_menu2";
            this.btn_menu2.setFontColor = System.Drawing.Color.Yellow;
            this.btn_menu2.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_menu2.setOFFimage")));
            this.btn_menu2.setON = false;
            this.btn_menu2.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_menu2.setONimage")));
            this.btn_menu2.setText = "예약 방송";
            this.btn_menu2.setToggle = false;
            this.btn_menu2.Size = new System.Drawing.Size(142, 60);
            this.btn_menu2.TabIndex = 24;
            this.btn_menu2.TabStop = false;
            this.btn_menu2.Tag = "2";
            this.btn_menu2.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_menu2.Click += new System.EventHandler(this.btn_menu1_Click);
            // 
            // panel_base
            // 
            this.panel_base.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.panel_base.Location = new System.Drawing.Point(0, 66);
            this.panel_base.Name = "panel_base";
            this.panel_base.Size = new System.Drawing.Size(1920, 947);
            this.panel_base.TabIndex = 25;
            // 
            // btn_menu3
            // 
            this.btn_menu3.BackColor = System.Drawing.Color.Transparent;
            this.btn_menu3.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_menu3.ForeColor = System.Drawing.Color.Yellow;
            this.btn_menu3.Location = new System.Drawing.Point(285, 22);
            this.btn_menu3.Name = "btn_menu3";
            this.btn_menu3.setFontColor = System.Drawing.Color.Yellow;
            this.btn_menu3.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_menu3.setOFFimage")));
            this.btn_menu3.setON = false;
            this.btn_menu3.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_menu3.setONimage")));
            this.btn_menu3.setText = "환경설정";
            this.btn_menu3.setToggle = false;
            this.btn_menu3.Size = new System.Drawing.Size(142, 60);
            this.btn_menu3.TabIndex = 26;
            this.btn_menu3.TabStop = false;
            this.btn_menu3.Tag = "3";
            this.btn_menu3.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_menu3.Click += new System.EventHandler(this.btn_menu1_Click);
            // 
            // btn_menu4
            // 
            this.btn_menu4.BackColor = System.Drawing.Color.Transparent;
            this.btn_menu4.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_menu4.ForeColor = System.Drawing.Color.Yellow;
            this.btn_menu4.Location = new System.Drawing.Point(427, 22);
            this.btn_menu4.Name = "btn_menu4";
            this.btn_menu4.setFontColor = System.Drawing.Color.Yellow;
            this.btn_menu4.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_menu4.setOFFimage")));
            this.btn_menu4.setON = false;
            this.btn_menu4.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_menu4.setONimage")));
            this.btn_menu4.setText = "NCO설정";
            this.btn_menu4.setToggle = false;
            this.btn_menu4.Size = new System.Drawing.Size(142, 60);
            this.btn_menu4.TabIndex = 28;
            this.btn_menu4.TabStop = false;
            this.btn_menu4.Tag = "4";
            this.btn_menu4.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_menu4.Click += new System.EventHandler(this.btn_menu1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Controls.Add(this.label_time);
            this.panel2.Controls.Add(this.label_date);
            this.panel2.Location = new System.Drawing.Point(1649, 37);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(269, 29);
            this.panel2.TabIndex = 29;
            // 
            // label_time
            // 
            this.label_time.AutoSize = true;
            this.label_time.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_time.ForeColor = System.Drawing.Color.Lime;
            this.label_time.Location = new System.Drawing.Point(136, 7);
            this.label_time.Name = "label_time";
            this.label_time.Size = new System.Drawing.Size(113, 16);
            this.label_time.TabIndex = 1;
            this.label_time.Text = "오전 08:00:00";
            // 
            // label_date
            // 
            this.label_date.AutoSize = true;
            this.label_date.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_date.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label_date.Location = new System.Drawing.Point(16, 9);
            this.label_date.Name = "label_date";
            this.label_date.Size = new System.Drawing.Size(87, 13);
            this.label_date.TabIndex = 0;
            this.label_date.Text = "2023-05-19";
            // 
            // pictureBox_bg
            // 
            this.pictureBox_bg.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox_bg.BackgroundImage")));
            this.pictureBox_bg.Location = new System.Drawing.Point(1068, 43);
            this.pictureBox_bg.Name = "pictureBox_bg";
            this.pictureBox_bg.Size = new System.Drawing.Size(149, 16);
            this.pictureBox_bg.TabIndex = 30;
            this.pictureBox_bg.TabStop = false;
            this.pictureBox_bg.Click += new System.EventHandler(this.pictureBox_bg_Click);
            // 
            // timer_rTime
            // 
            this.timer_rTime.Interval = 1000;
            this.timer_rTime.Tick += new System.EventHandler(this.timer_rTime_Tick);
            // 
            // timer_start
            // 
            this.timer_start.Tick += new System.EventHandler(this.timer_start_Tick);
            // 
            // timer_Reconnect
            // 
            this.timer_Reconnect.Enabled = true;
            this.timer_Reconnect.Interval = 3000;
            this.timer_Reconnect.Tick += new System.EventHandler(this.timer_Reconnect_Tick);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1904, 1011);
            this.Controls.Add(this.pictureBox_bg);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel_base);
            this.Controls.Add(this.panel_head);
            this.Controls.Add(this.btn_menu1);
            this.Controls.Add(this.btn_menu2);
            this.Controls.Add(this.btn_menu4);
            this.Controls.Add(this.btn_menu3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "방송 제어 프로그램";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.panel_head.ResumeLayout(false);
            this.panel_head.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_logo)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_bg)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_head;
        private System.Windows.Forms.Label label_t;
        private System.Windows.Forms.Label label_title;
        private System.Windows.Forms.PictureBox pictureBox_logo;
        private System.Windows.Forms.Button btn_mini;
        private System.Windows.Forms.Button btn_close;
        private RHBform.RHBbutton btn_menu1;
        private RHBform.RHBbutton btn_menu2;
        private System.Windows.Forms.Panel panel_base;
        private RHBform.RHBbutton btn_menu3;
        private RHBform.RHBbutton btn_menu4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label_time;
        private System.Windows.Forms.Label label_date;
        private System.Windows.Forms.PictureBox pictureBox_bg;
        private System.Windows.Forms.Timer timer_rTime;
        private System.Windows.Forms.Timer timer_start;
        private RHBform.RHBbutton btn_FaultClear;
        private RHBform.RHBbutton btn_fireClear;
        private System.Windows.Forms.Timer timer_Reconnect;
        private RHBform.RHBbutton btn_log;
    }
}

