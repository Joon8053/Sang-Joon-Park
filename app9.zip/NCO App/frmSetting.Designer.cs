﻿namespace NCO_App
{
    partial class frmSetting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.setting_tab = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btn_setNco = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btn_zone4 = new System.Windows.Forms.Button();
            this.btn_zone3 = new System.Windows.Forms.Button();
            this.btn_zone2 = new System.Windows.Forms.Button();
            this.btn_zone1 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btn_nco3 = new System.Windows.Forms.Button();
            this.btn_nco2 = new System.Windows.Forms.Button();
            this.btn_nco1 = new System.Windows.Forms.Button();
            this.pg2_menu4 = new System.Windows.Forms.GroupBox();
            this.txt_NCO_Password = new System.Windows.Forms.TextBox();
            this.pg2_menu3 = new System.Windows.Forms.GroupBox();
            this.txt_NCO_ID = new System.Windows.Forms.TextBox();
            this.pg2_menu2 = new System.Windows.Forms.GroupBox();
            this.txt_NCO_IP = new System.Windows.Forms.TextBox();
            this.pg2_menu1 = new System.Windows.Forms.GroupBox();
            this.txt_NCO_Name = new System.Windows.Forms.TextBox();
            this.pg2_menu5 = new System.Windows.Forms.GroupBox();
            this.btn_erase = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            this.panel_zoneFrm = new System.Windows.Forms.Panel();
            this.btnSaveCancle = new System.Windows.Forms.Button();
            this.btnSaveZone = new System.Windows.Forms.Button();
            this.txt_GroupName = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.zone_setting_img = new System.Windows.Forms.PictureBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txt_Messages = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txt_bgms = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.sbtn_nco3 = new System.Windows.Forms.Button();
            this.sbtn_nco2 = new System.Windows.Forms.Button();
            this.sbtn_nco1 = new System.Windows.Forms.Button();
            this.gr_BGMname = new System.Windows.Forms.GroupBox();
            this.btn_change = new System.Windows.Forms.Button();
            this.txt_BGMname = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txt_BgmNCO5 = new System.Windows.Forms.TextBox();
            this.btn_bgmColor5 = new System.Windows.Forms.Button();
            this.btn_Bgm5 = new System.Windows.Forms.Button();
            this.txt_BgmNCO4 = new System.Windows.Forms.TextBox();
            this.bgm_save_cancle = new System.Windows.Forms.Button();
            this.btn_bgmColor4 = new System.Windows.Forms.Button();
            this.BGM_save = new System.Windows.Forms.Button();
            this.label58 = new System.Windows.Forms.Label();
            this.btn_Bgm4 = new System.Windows.Forms.Button();
            this.txt_BgmNCO3 = new System.Windows.Forms.TextBox();
            this.btn_bgmColor3 = new System.Windows.Forms.Button();
            this.btn_Bgm3 = new System.Windows.Forms.Button();
            this.txt_BgmNCO2 = new System.Windows.Forms.TextBox();
            this.txt_BgmNCO1 = new System.Windows.Forms.TextBox();
            this.btn_bgmColor2 = new System.Windows.Forms.Button();
            this.btn_Bgm2 = new System.Windows.Forms.Button();
            this.btn_bgmColor1 = new System.Windows.Forms.Button();
            this.btn_Bgm1 = new System.Windows.Forms.Button();
            this.groupBox_BGM = new System.Windows.Forms.GroupBox();
            this.btn_call5 = new System.Windows.Forms.Button();
            this.btn_call4 = new System.Windows.Forms.Button();
            this.btn_call3 = new System.Windows.Forms.Button();
            this.btn_call2 = new System.Windows.Forms.Button();
            this.btn_call1 = new System.Windows.Forms.Button();
            this.btn_callCancel = new System.Windows.Forms.Button();
            this.btn_callSave = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.tb_color = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_Name = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.tb_Priority = new System.Windows.Forms.TextBox();
            this.tb_StartChime = new System.Windows.Forms.TextBox();
            this.tb_Messages = new System.Windows.Forms.TextBox();
            this.tb_EndChime = new System.Windows.Forms.TextBox();
            this.tb_RepeatCnt = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_PingTime = new System.Windows.Forms.TextBox();
            this.btn_addNet = new System.Windows.Forms.Button();
            this.txt_DevName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_devIP = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.panel_net = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.clrdlg_chk = new System.Windows.Forms.ColorDialog();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.btn_music1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.btn_music2 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.btn_music3 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.btn_music4 = new System.Windows.Forms.Button();
            this.setting_tab.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.pg2_menu4.SuspendLayout();
            this.pg2_menu3.SuspendLayout();
            this.pg2_menu2.SuspendLayout();
            this.pg2_menu1.SuspendLayout();
            this.pg2_menu5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.zone_setting_img)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.gr_BGMname.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox_BGM.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.SuspendLayout();
            // 
            // setting_tab
            // 
            this.setting_tab.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.setting_tab.Controls.Add(this.tabPage1);
            this.setting_tab.Controls.Add(this.tabPage2);
            this.setting_tab.Controls.Add(this.tabPage3);
            this.setting_tab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.setting_tab.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.setting_tab.ItemSize = new System.Drawing.Size(101, 40);
            this.setting_tab.Location = new System.Drawing.Point(0, 0);
            this.setting_tab.Name = "setting_tab";
            this.setting_tab.SelectedIndex = 0;
            this.setting_tab.Size = new System.Drawing.Size(1920, 947);
            this.setting_tab.TabIndex = 1;
            this.setting_tab.SelectedIndexChanged += new System.EventHandler(this.setting_tab_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.tabPage1.Controls.Add(this.btn_setNco);
            this.tabPage1.Controls.Add(this.groupBox6);
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Controls.Add(this.pg2_menu4);
            this.tabPage1.Controls.Add(this.pg2_menu3);
            this.tabPage1.Controls.Add(this.pg2_menu2);
            this.tabPage1.Controls.Add(this.pg2_menu1);
            this.tabPage1.Controls.Add(this.pg2_menu5);
            this.tabPage1.Controls.Add(this.zone_setting_img);
            this.tabPage1.Location = new System.Drawing.Point(4, 44);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1912, 899);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Zone 설정";
            // 
            // btn_setNco
            // 
            this.btn_setNco.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btn_setNco.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_setNco.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_setNco.FlatAppearance.BorderSize = 2;
            this.btn_setNco.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.btn_setNco.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_setNco.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_setNco.ForeColor = System.Drawing.Color.Black;
            this.btn_setNco.Location = new System.Drawing.Point(1274, 28);
            this.btn_setNco.Name = "btn_setNco";
            this.btn_setNco.Size = new System.Drawing.Size(116, 48);
            this.btn_setNco.TabIndex = 504;
            this.btn_setNco.Text = "변경";
            this.btn_setNco.UseVisualStyleBackColor = false;
            this.btn_setNco.Click += new System.EventHandler(this.btn_setNco_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox6.Controls.Add(this.btn_zone4);
            this.groupBox6.Controls.Add(this.btn_zone3);
            this.groupBox6.Controls.Add(this.btn_zone2);
            this.groupBox6.Controls.Add(this.btn_zone1);
            this.groupBox6.ForeColor = System.Drawing.Color.White;
            this.groupBox6.Location = new System.Drawing.Point(17, 243);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(241, 527);
            this.groupBox6.TabIndex = 503;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = " Zone List ";
            // 
            // btn_zone4
            // 
            this.btn_zone4.ForeColor = System.Drawing.Color.Black;
            this.btn_zone4.Location = new System.Drawing.Point(16, 197);
            this.btn_zone4.Name = "btn_zone4";
            this.btn_zone4.Size = new System.Drawing.Size(208, 48);
            this.btn_zone4.TabIndex = 6;
            this.btn_zone4.Tag = "4";
            this.btn_zone4.Text = "4";
            this.btn_zone4.UseVisualStyleBackColor = true;
            this.btn_zone4.Click += new System.EventHandler(this.btn_zone1_Click);
            // 
            // btn_zone3
            // 
            this.btn_zone3.ForeColor = System.Drawing.Color.Black;
            this.btn_zone3.Location = new System.Drawing.Point(16, 143);
            this.btn_zone3.Name = "btn_zone3";
            this.btn_zone3.Size = new System.Drawing.Size(208, 48);
            this.btn_zone3.TabIndex = 5;
            this.btn_zone3.Tag = "3";
            this.btn_zone3.Text = "3";
            this.btn_zone3.UseVisualStyleBackColor = true;
            this.btn_zone3.Click += new System.EventHandler(this.btn_zone1_Click);
            // 
            // btn_zone2
            // 
            this.btn_zone2.ForeColor = System.Drawing.Color.Black;
            this.btn_zone2.Location = new System.Drawing.Point(16, 89);
            this.btn_zone2.Name = "btn_zone2";
            this.btn_zone2.Size = new System.Drawing.Size(208, 48);
            this.btn_zone2.TabIndex = 4;
            this.btn_zone2.Tag = "2";
            this.btn_zone2.Text = "2";
            this.btn_zone2.UseVisualStyleBackColor = true;
            this.btn_zone2.Click += new System.EventHandler(this.btn_zone1_Click);
            // 
            // btn_zone1
            // 
            this.btn_zone1.ForeColor = System.Drawing.Color.Black;
            this.btn_zone1.Location = new System.Drawing.Point(16, 32);
            this.btn_zone1.Name = "btn_zone1";
            this.btn_zone1.Size = new System.Drawing.Size(208, 48);
            this.btn_zone1.TabIndex = 3;
            this.btn_zone1.Tag = "1";
            this.btn_zone1.Text = "1";
            this.btn_zone1.UseVisualStyleBackColor = true;
            this.btn_zone1.Click += new System.EventHandler(this.btn_zone1_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox4.Controls.Add(this.btn_nco3);
            this.groupBox4.Controls.Add(this.btn_nco2);
            this.groupBox4.Controls.Add(this.btn_nco1);
            this.groupBox4.ForeColor = System.Drawing.Color.White;
            this.groupBox4.Location = new System.Drawing.Point(17, 25);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(241, 203);
            this.groupBox4.TabIndex = 502;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = " NCO List ";
            // 
            // btn_nco3
            // 
            this.btn_nco3.ForeColor = System.Drawing.Color.Black;
            this.btn_nco3.Location = new System.Drawing.Point(16, 142);
            this.btn_nco3.Name = "btn_nco3";
            this.btn_nco3.Size = new System.Drawing.Size(208, 48);
            this.btn_nco3.TabIndex = 2;
            this.btn_nco3.Tag = "3";
            this.btn_nco3.Text = "NCO3";
            this.btn_nco3.UseVisualStyleBackColor = true;
            this.btn_nco3.Click += new System.EventHandler(this.btn_nco1_Click);
            // 
            // btn_nco2
            // 
            this.btn_nco2.ForeColor = System.Drawing.Color.Black;
            this.btn_nco2.Location = new System.Drawing.Point(16, 88);
            this.btn_nco2.Name = "btn_nco2";
            this.btn_nco2.Size = new System.Drawing.Size(208, 48);
            this.btn_nco2.TabIndex = 1;
            this.btn_nco2.Tag = "2";
            this.btn_nco2.Text = "NCO2";
            this.btn_nco2.UseVisualStyleBackColor = true;
            this.btn_nco2.Click += new System.EventHandler(this.btn_nco1_Click);
            // 
            // btn_nco1
            // 
            this.btn_nco1.ForeColor = System.Drawing.Color.Black;
            this.btn_nco1.Location = new System.Drawing.Point(16, 31);
            this.btn_nco1.Name = "btn_nco1";
            this.btn_nco1.Size = new System.Drawing.Size(208, 48);
            this.btn_nco1.TabIndex = 0;
            this.btn_nco1.Tag = "1";
            this.btn_nco1.Text = "NCO1";
            this.btn_nco1.UseVisualStyleBackColor = true;
            this.btn_nco1.Click += new System.EventHandler(this.btn_nco1_Click);
            // 
            // pg2_menu4
            // 
            this.pg2_menu4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pg2_menu4.Controls.Add(this.txt_NCO_Password);
            this.pg2_menu4.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.pg2_menu4.ForeColor = System.Drawing.Color.White;
            this.pg2_menu4.Location = new System.Drawing.Point(1040, 25);
            this.pg2_menu4.Name = "pg2_menu4";
            this.pg2_menu4.Size = new System.Drawing.Size(213, 51);
            this.pg2_menu4.TabIndex = 499;
            this.pg2_menu4.TabStop = false;
            this.pg2_menu4.Text = "Password";
            // 
            // txt_NCO_Password
            // 
            this.txt_NCO_Password.ForeColor = System.Drawing.Color.Blue;
            this.txt_NCO_Password.Location = new System.Drawing.Point(11, 19);
            this.txt_NCO_Password.Name = "txt_NCO_Password";
            this.txt_NCO_Password.Size = new System.Drawing.Size(196, 26);
            this.txt_NCO_Password.TabIndex = 433;
            // 
            // pg2_menu3
            // 
            this.pg2_menu3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pg2_menu3.Controls.Add(this.txt_NCO_ID);
            this.pg2_menu3.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.pg2_menu3.ForeColor = System.Drawing.Color.White;
            this.pg2_menu3.Location = new System.Drawing.Point(841, 25);
            this.pg2_menu3.Name = "pg2_menu3";
            this.pg2_menu3.Size = new System.Drawing.Size(193, 51);
            this.pg2_menu3.TabIndex = 498;
            this.pg2_menu3.TabStop = false;
            this.pg2_menu3.Text = "ID";
            // 
            // txt_NCO_ID
            // 
            this.txt_NCO_ID.ForeColor = System.Drawing.Color.Blue;
            this.txt_NCO_ID.Location = new System.Drawing.Point(11, 19);
            this.txt_NCO_ID.Name = "txt_NCO_ID";
            this.txt_NCO_ID.Size = new System.Drawing.Size(170, 26);
            this.txt_NCO_ID.TabIndex = 433;
            // 
            // pg2_menu2
            // 
            this.pg2_menu2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pg2_menu2.Controls.Add(this.txt_NCO_IP);
            this.pg2_menu2.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.pg2_menu2.ForeColor = System.Drawing.Color.White;
            this.pg2_menu2.Location = new System.Drawing.Point(563, 25);
            this.pg2_menu2.Name = "pg2_menu2";
            this.pg2_menu2.Size = new System.Drawing.Size(263, 51);
            this.pg2_menu2.TabIndex = 497;
            this.pg2_menu2.TabStop = false;
            this.pg2_menu2.Text = "NCO IP ADDRESS";
            // 
            // txt_NCO_IP
            // 
            this.txt_NCO_IP.ForeColor = System.Drawing.Color.Blue;
            this.txt_NCO_IP.Location = new System.Drawing.Point(17, 19);
            this.txt_NCO_IP.Name = "txt_NCO_IP";
            this.txt_NCO_IP.Size = new System.Drawing.Size(226, 26);
            this.txt_NCO_IP.TabIndex = 433;
            // 
            // pg2_menu1
            // 
            this.pg2_menu1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pg2_menu1.Controls.Add(this.txt_NCO_Name);
            this.pg2_menu1.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.pg2_menu1.ForeColor = System.Drawing.Color.White;
            this.pg2_menu1.Location = new System.Drawing.Point(286, 25);
            this.pg2_menu1.Name = "pg2_menu1";
            this.pg2_menu1.Size = new System.Drawing.Size(263, 51);
            this.pg2_menu1.TabIndex = 496;
            this.pg2_menu1.TabStop = false;
            this.pg2_menu1.Text = "NCO 이름";
            // 
            // txt_NCO_Name
            // 
            this.txt_NCO_Name.ForeColor = System.Drawing.Color.Blue;
            this.txt_NCO_Name.Location = new System.Drawing.Point(19, 19);
            this.txt_NCO_Name.Name = "txt_NCO_Name";
            this.txt_NCO_Name.Size = new System.Drawing.Size(226, 26);
            this.txt_NCO_Name.TabIndex = 432;
            // 
            // pg2_menu5
            // 
            this.pg2_menu5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pg2_menu5.Controls.Add(this.btn_erase);
            this.pg2_menu5.Controls.Add(this.btn_add);
            this.pg2_menu5.Controls.Add(this.panel_zoneFrm);
            this.pg2_menu5.Controls.Add(this.btnSaveCancle);
            this.pg2_menu5.Controls.Add(this.btnSaveZone);
            this.pg2_menu5.Controls.Add(this.txt_GroupName);
            this.pg2_menu5.Controls.Add(this.label55);
            this.pg2_menu5.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.pg2_menu5.ForeColor = System.Drawing.Color.White;
            this.pg2_menu5.Location = new System.Drawing.Point(286, 103);
            this.pg2_menu5.Name = "pg2_menu5";
            this.pg2_menu5.Size = new System.Drawing.Size(1104, 667);
            this.pg2_menu5.TabIndex = 495;
            this.pg2_menu5.TabStop = false;
            this.pg2_menu5.Text = "Zone 설정";
            // 
            // btn_erase
            // 
            this.btn_erase.ForeColor = System.Drawing.Color.Black;
            this.btn_erase.Location = new System.Drawing.Point(973, 25);
            this.btn_erase.Name = "btn_erase";
            this.btn_erase.Size = new System.Drawing.Size(98, 35);
            this.btn_erase.TabIndex = 503;
            this.btn_erase.Text = "삭제";
            this.btn_erase.UseVisualStyleBackColor = true;
            this.btn_erase.Click += new System.EventHandler(this.btn_erase_Click);
            // 
            // btn_add
            // 
            this.btn_add.ForeColor = System.Drawing.Color.Black;
            this.btn_add.Location = new System.Drawing.Point(869, 25);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(98, 35);
            this.btn_add.TabIndex = 502;
            this.btn_add.Text = "추가";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // panel_zoneFrm
            // 
            this.panel_zoneFrm.AutoScroll = true;
            this.panel_zoneFrm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.panel_zoneFrm.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.panel_zoneFrm.ForeColor = System.Drawing.Color.Black;
            this.panel_zoneFrm.Location = new System.Drawing.Point(39, 64);
            this.panel_zoneFrm.Name = "panel_zoneFrm";
            this.panel_zoneFrm.Size = new System.Drawing.Size(1032, 533);
            this.panel_zoneFrm.TabIndex = 432;
            // 
            // btnSaveCancle
            // 
            this.btnSaveCancle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnSaveCancle.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnSaveCancle.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnSaveCancle.FlatAppearance.BorderSize = 2;
            this.btnSaveCancle.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.btnSaveCancle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaveCancle.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnSaveCancle.ForeColor = System.Drawing.Color.Black;
            this.btnSaveCancle.Location = new System.Drawing.Point(955, 603);
            this.btnSaveCancle.Name = "btnSaveCancle";
            this.btnSaveCancle.Size = new System.Drawing.Size(116, 48);
            this.btnSaveCancle.TabIndex = 500;
            this.btnSaveCancle.Text = "취소";
            this.btnSaveCancle.UseVisualStyleBackColor = false;
            this.btnSaveCancle.Click += new System.EventHandler(this.btnSaveCancle_Click);
            // 
            // btnSaveZone
            // 
            this.btnSaveZone.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnSaveZone.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnSaveZone.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnSaveZone.FlatAppearance.BorderSize = 2;
            this.btnSaveZone.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.btnSaveZone.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaveZone.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnSaveZone.ForeColor = System.Drawing.Color.Black;
            this.btnSaveZone.Location = new System.Drawing.Point(833, 603);
            this.btnSaveZone.Name = "btnSaveZone";
            this.btnSaveZone.Size = new System.Drawing.Size(116, 48);
            this.btnSaveZone.TabIndex = 501;
            this.btnSaveZone.Text = "저장";
            this.btnSaveZone.UseVisualStyleBackColor = false;
            this.btnSaveZone.Click += new System.EventHandler(this.btnSaveZone_Click);
            // 
            // txt_GroupName
            // 
            this.txt_GroupName.ForeColor = System.Drawing.Color.Blue;
            this.txt_GroupName.Location = new System.Drawing.Point(129, 25);
            this.txt_GroupName.Name = "txt_GroupName";
            this.txt_GroupName.Size = new System.Drawing.Size(232, 26);
            this.txt_GroupName.TabIndex = 431;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(45, 33);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(58, 16);
            this.label55.TabIndex = 430;
            this.label55.Text = "타이틀";
            // 
            // zone_setting_img
            // 
            this.zone_setting_img.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.zone_setting_img.Dock = System.Windows.Forms.DockStyle.Fill;
            this.zone_setting_img.Location = new System.Drawing.Point(3, 3);
            this.zone_setting_img.Name = "zone_setting_img";
            this.zone_setting_img.Size = new System.Drawing.Size(1906, 893);
            this.zone_setting_img.TabIndex = 494;
            this.zone_setting_img.TabStop = false;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.tabPage2.Controls.Add(this.groupBox5);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Controls.Add(this.gr_BGMname);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.groupBox_BGM);
            this.tabPage2.Location = new System.Drawing.Point(4, 44);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1912, 899);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Call설정/비밀번호";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.txt_Messages);
            this.groupBox5.ForeColor = System.Drawing.Color.White;
            this.groupBox5.Location = new System.Drawing.Point(643, 48);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(286, 544);
            this.groupBox5.TabIndex = 590;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Message List";
            // 
            // txt_Messages
            // 
            this.txt_Messages.Location = new System.Drawing.Point(29, 27);
            this.txt_Messages.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_Messages.Multiline = true;
            this.txt_Messages.Name = "txt_Messages";
            this.txt_Messages.Size = new System.Drawing.Size(229, 491);
            this.txt_Messages.TabIndex = 1;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txt_bgms);
            this.groupBox3.ForeColor = System.Drawing.Color.White;
            this.groupBox3.Location = new System.Drawing.Point(334, 48);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(286, 544);
            this.groupBox3.TabIndex = 589;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "BGM List";
            // 
            // txt_bgms
            // 
            this.txt_bgms.Location = new System.Drawing.Point(26, 26);
            this.txt_bgms.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_bgms.Multiline = true;
            this.txt_bgms.Name = "txt_bgms";
            this.txt_bgms.Size = new System.Drawing.Size(229, 491);
            this.txt_bgms.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox1.Controls.Add(this.sbtn_nco3);
            this.groupBox1.Controls.Add(this.sbtn_nco2);
            this.groupBox1.Controls.Add(this.sbtn_nco1);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(43, 48);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(241, 203);
            this.groupBox1.TabIndex = 588;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = " NCO List ";
            // 
            // sbtn_nco3
            // 
            this.sbtn_nco3.ForeColor = System.Drawing.Color.Black;
            this.sbtn_nco3.Location = new System.Drawing.Point(16, 142);
            this.sbtn_nco3.Name = "sbtn_nco3";
            this.sbtn_nco3.Size = new System.Drawing.Size(208, 48);
            this.sbtn_nco3.TabIndex = 2;
            this.sbtn_nco3.Tag = "3";
            this.sbtn_nco3.Text = "NCO3";
            this.sbtn_nco3.UseVisualStyleBackColor = true;
            this.sbtn_nco3.Click += new System.EventHandler(this.sBtn_NCOs_Click);
            // 
            // sbtn_nco2
            // 
            this.sbtn_nco2.ForeColor = System.Drawing.Color.Black;
            this.sbtn_nco2.Location = new System.Drawing.Point(16, 88);
            this.sbtn_nco2.Name = "sbtn_nco2";
            this.sbtn_nco2.Size = new System.Drawing.Size(208, 48);
            this.sbtn_nco2.TabIndex = 1;
            this.sbtn_nco2.Tag = "2";
            this.sbtn_nco2.Text = "NCO2";
            this.sbtn_nco2.UseVisualStyleBackColor = true;
            this.sbtn_nco2.Click += new System.EventHandler(this.sBtn_NCOs_Click);
            // 
            // sbtn_nco1
            // 
            this.sbtn_nco1.ForeColor = System.Drawing.Color.Black;
            this.sbtn_nco1.Location = new System.Drawing.Point(16, 31);
            this.sbtn_nco1.Name = "sbtn_nco1";
            this.sbtn_nco1.Size = new System.Drawing.Size(208, 48);
            this.sbtn_nco1.TabIndex = 0;
            this.sbtn_nco1.Tag = "1";
            this.sbtn_nco1.Text = "NCO1";
            this.sbtn_nco1.UseVisualStyleBackColor = true;
            this.sbtn_nco1.Click += new System.EventHandler(this.sBtn_NCOs_Click);
            // 
            // gr_BGMname
            // 
            this.gr_BGMname.BackColor = System.Drawing.Color.Black;
            this.gr_BGMname.Controls.Add(this.btn_change);
            this.gr_BGMname.Controls.Add(this.txt_BGMname);
            this.gr_BGMname.ForeColor = System.Drawing.Color.White;
            this.gr_BGMname.Location = new System.Drawing.Point(1445, 401);
            this.gr_BGMname.Name = "gr_BGMname";
            this.gr_BGMname.Size = new System.Drawing.Size(311, 100);
            this.gr_BGMname.TabIndex = 587;
            this.gr_BGMname.TabStop = false;
            this.gr_BGMname.Text = "BGM 표시 이름";
            this.gr_BGMname.Visible = false;
            // 
            // btn_change
            // 
            this.btn_change.BackColor = System.Drawing.Color.LightBlue;
            this.btn_change.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_change.ForeColor = System.Drawing.Color.Black;
            this.btn_change.Location = new System.Drawing.Point(195, 29);
            this.btn_change.Name = "btn_change";
            this.btn_change.Size = new System.Drawing.Size(99, 42);
            this.btn_change.TabIndex = 555;
            this.btn_change.Text = "변경";
            this.btn_change.UseVisualStyleBackColor = false;
            this.btn_change.Click += new System.EventHandler(this.btn_change_Click);
            // 
            // txt_BGMname
            // 
            this.txt_BGMname.Location = new System.Drawing.Point(18, 42);
            this.txt_BGMname.Name = "txt_BGMname";
            this.txt_BGMname.Size = new System.Drawing.Size(161, 22);
            this.txt_BGMname.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txt_BgmNCO5);
            this.groupBox2.Controls.Add(this.btn_bgmColor5);
            this.groupBox2.Controls.Add(this.btn_Bgm5);
            this.groupBox2.Controls.Add(this.txt_BgmNCO4);
            this.groupBox2.Controls.Add(this.bgm_save_cancle);
            this.groupBox2.Controls.Add(this.btn_bgmColor4);
            this.groupBox2.Controls.Add(this.BGM_save);
            this.groupBox2.Controls.Add(this.label58);
            this.groupBox2.Controls.Add(this.btn_Bgm4);
            this.groupBox2.Controls.Add(this.txt_BgmNCO3);
            this.groupBox2.Controls.Add(this.btn_bgmColor3);
            this.groupBox2.Controls.Add(this.btn_Bgm3);
            this.groupBox2.Controls.Add(this.txt_BgmNCO2);
            this.groupBox2.Controls.Add(this.txt_BgmNCO1);
            this.groupBox2.Controls.Add(this.btn_bgmColor2);
            this.groupBox2.Controls.Add(this.btn_Bgm2);
            this.groupBox2.Controls.Add(this.btn_bgmColor1);
            this.groupBox2.Controls.Add(this.btn_Bgm1);
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(1081, 493);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(615, 307);
            this.groupBox2.TabIndex = 586;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "BGM 설정";
            // 
            // txt_BgmNCO5
            // 
            this.txt_BgmNCO5.ForeColor = System.Drawing.Color.Black;
            this.txt_BgmNCO5.Location = new System.Drawing.Point(325, 212);
            this.txt_BgmNCO5.Name = "txt_BgmNCO5";
            this.txt_BgmNCO5.Size = new System.Drawing.Size(181, 22);
            this.txt_BgmNCO5.TabIndex = 16;
            // 
            // btn_bgmColor5
            // 
            this.btn_bgmColor5.ForeColor = System.Drawing.Color.Black;
            this.btn_bgmColor5.Location = new System.Drawing.Point(91, 212);
            this.btn_bgmColor5.Name = "btn_bgmColor5";
            this.btn_bgmColor5.Size = new System.Drawing.Size(28, 24);
            this.btn_bgmColor5.TabIndex = 15;
            this.btn_bgmColor5.Text = "5";
            this.btn_bgmColor5.UseVisualStyleBackColor = true;
            // 
            // btn_Bgm5
            // 
            this.btn_Bgm5.ForeColor = System.Drawing.Color.Black;
            this.btn_Bgm5.Location = new System.Drawing.Point(125, 212);
            this.btn_Bgm5.Name = "btn_Bgm5";
            this.btn_Bgm5.Size = new System.Drawing.Size(191, 24);
            this.btn_Bgm5.TabIndex = 14;
            this.btn_Bgm5.Text = "button11";
            this.btn_Bgm5.UseVisualStyleBackColor = true;
            // 
            // txt_BgmNCO4
            // 
            this.txt_BgmNCO4.ForeColor = System.Drawing.Color.Black;
            this.txt_BgmNCO4.Location = new System.Drawing.Point(325, 168);
            this.txt_BgmNCO4.Name = "txt_BgmNCO4";
            this.txt_BgmNCO4.Size = new System.Drawing.Size(181, 22);
            this.txt_BgmNCO4.TabIndex = 13;
            // 
            // bgm_save_cancle
            // 
            this.bgm_save_cancle.BackColor = System.Drawing.Color.LightBlue;
            this.bgm_save_cancle.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.bgm_save_cancle.ForeColor = System.Drawing.Color.Black;
            this.bgm_save_cancle.Location = new System.Drawing.Point(407, 248);
            this.bgm_save_cancle.Name = "bgm_save_cancle";
            this.bgm_save_cancle.Size = new System.Drawing.Size(99, 42);
            this.bgm_save_cancle.TabIndex = 555;
            this.bgm_save_cancle.Text = "취소";
            this.bgm_save_cancle.UseVisualStyleBackColor = false;
            // 
            // btn_bgmColor4
            // 
            this.btn_bgmColor4.ForeColor = System.Drawing.Color.Black;
            this.btn_bgmColor4.Location = new System.Drawing.Point(91, 168);
            this.btn_bgmColor4.Name = "btn_bgmColor4";
            this.btn_bgmColor4.Size = new System.Drawing.Size(28, 24);
            this.btn_bgmColor4.TabIndex = 12;
            this.btn_bgmColor4.Text = "4";
            this.btn_bgmColor4.UseVisualStyleBackColor = true;
            // 
            // BGM_save
            // 
            this.BGM_save.BackColor = System.Drawing.Color.LightBlue;
            this.BGM_save.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.BGM_save.ForeColor = System.Drawing.Color.Black;
            this.BGM_save.Location = new System.Drawing.Point(288, 248);
            this.BGM_save.Name = "BGM_save";
            this.BGM_save.Size = new System.Drawing.Size(99, 42);
            this.BGM_save.TabIndex = 554;
            this.BGM_save.Text = "저장";
            this.BGM_save.UseVisualStyleBackColor = false;
            this.BGM_save.Click += new System.EventHandler(this.BGM_save_Click);
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(322, 18);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(65, 13);
            this.label58.TabIndex = 468;
            this.label58.Text = "NCO 설정";
            // 
            // btn_Bgm4
            // 
            this.btn_Bgm4.ForeColor = System.Drawing.Color.Black;
            this.btn_Bgm4.Location = new System.Drawing.Point(125, 168);
            this.btn_Bgm4.Name = "btn_Bgm4";
            this.btn_Bgm4.Size = new System.Drawing.Size(191, 24);
            this.btn_Bgm4.TabIndex = 11;
            this.btn_Bgm4.Text = "button9";
            this.btn_Bgm4.UseVisualStyleBackColor = true;
            // 
            // txt_BgmNCO3
            // 
            this.txt_BgmNCO3.ForeColor = System.Drawing.Color.Black;
            this.txt_BgmNCO3.Location = new System.Drawing.Point(325, 130);
            this.txt_BgmNCO3.Name = "txt_BgmNCO3";
            this.txt_BgmNCO3.Size = new System.Drawing.Size(181, 22);
            this.txt_BgmNCO3.TabIndex = 10;
            // 
            // btn_bgmColor3
            // 
            this.btn_bgmColor3.ForeColor = System.Drawing.Color.Black;
            this.btn_bgmColor3.Location = new System.Drawing.Point(91, 130);
            this.btn_bgmColor3.Name = "btn_bgmColor3";
            this.btn_bgmColor3.Size = new System.Drawing.Size(28, 24);
            this.btn_bgmColor3.TabIndex = 9;
            this.btn_bgmColor3.Text = "3";
            this.btn_bgmColor3.UseVisualStyleBackColor = true;
            // 
            // btn_Bgm3
            // 
            this.btn_Bgm3.ForeColor = System.Drawing.Color.Black;
            this.btn_Bgm3.Location = new System.Drawing.Point(125, 130);
            this.btn_Bgm3.Name = "btn_Bgm3";
            this.btn_Bgm3.Size = new System.Drawing.Size(191, 24);
            this.btn_Bgm3.TabIndex = 8;
            this.btn_Bgm3.Text = "button7";
            this.btn_Bgm3.UseVisualStyleBackColor = true;
            // 
            // txt_BgmNCO2
            // 
            this.txt_BgmNCO2.ForeColor = System.Drawing.Color.Black;
            this.txt_BgmNCO2.Location = new System.Drawing.Point(325, 89);
            this.txt_BgmNCO2.Name = "txt_BgmNCO2";
            this.txt_BgmNCO2.Size = new System.Drawing.Size(181, 22);
            this.txt_BgmNCO2.TabIndex = 7;
            // 
            // txt_BgmNCO1
            // 
            this.txt_BgmNCO1.ForeColor = System.Drawing.Color.Black;
            this.txt_BgmNCO1.Location = new System.Drawing.Point(325, 48);
            this.txt_BgmNCO1.Name = "txt_BgmNCO1";
            this.txt_BgmNCO1.Size = new System.Drawing.Size(181, 22);
            this.txt_BgmNCO1.TabIndex = 6;
            // 
            // btn_bgmColor2
            // 
            this.btn_bgmColor2.ForeColor = System.Drawing.Color.Black;
            this.btn_bgmColor2.Location = new System.Drawing.Point(91, 89);
            this.btn_bgmColor2.Name = "btn_bgmColor2";
            this.btn_bgmColor2.Size = new System.Drawing.Size(28, 24);
            this.btn_bgmColor2.TabIndex = 5;
            this.btn_bgmColor2.Text = "2";
            this.btn_bgmColor2.UseVisualStyleBackColor = true;
            // 
            // btn_Bgm2
            // 
            this.btn_Bgm2.ForeColor = System.Drawing.Color.Black;
            this.btn_Bgm2.Location = new System.Drawing.Point(125, 89);
            this.btn_Bgm2.Name = "btn_Bgm2";
            this.btn_Bgm2.Size = new System.Drawing.Size(191, 24);
            this.btn_Bgm2.TabIndex = 3;
            this.btn_Bgm2.Text = "button5";
            this.btn_Bgm2.UseVisualStyleBackColor = true;
            // 
            // btn_bgmColor1
            // 
            this.btn_bgmColor1.ForeColor = System.Drawing.Color.Black;
            this.btn_bgmColor1.Location = new System.Drawing.Point(91, 48);
            this.btn_bgmColor1.Name = "btn_bgmColor1";
            this.btn_bgmColor1.Size = new System.Drawing.Size(28, 24);
            this.btn_bgmColor1.TabIndex = 2;
            this.btn_bgmColor1.Text = "1";
            this.btn_bgmColor1.UseVisualStyleBackColor = true;
            // 
            // btn_Bgm1
            // 
            this.btn_Bgm1.ForeColor = System.Drawing.Color.Black;
            this.btn_Bgm1.Location = new System.Drawing.Point(125, 48);
            this.btn_Bgm1.Name = "btn_Bgm1";
            this.btn_Bgm1.Size = new System.Drawing.Size(191, 24);
            this.btn_Bgm1.TabIndex = 0;
            this.btn_Bgm1.Text = "button2";
            this.btn_Bgm1.UseVisualStyleBackColor = true;
            // 
            // groupBox_BGM
            // 
            this.groupBox_BGM.Controls.Add(this.btn_call5);
            this.groupBox_BGM.Controls.Add(this.btn_call4);
            this.groupBox_BGM.Controls.Add(this.btn_call3);
            this.groupBox_BGM.Controls.Add(this.btn_call2);
            this.groupBox_BGM.Controls.Add(this.btn_call1);
            this.groupBox_BGM.Controls.Add(this.btn_callCancel);
            this.groupBox_BGM.Controls.Add(this.btn_callSave);
            this.groupBox_BGM.Controls.Add(this.button1);
            this.groupBox_BGM.Controls.Add(this.label27);
            this.groupBox_BGM.Controls.Add(this.tb_color);
            this.groupBox_BGM.Controls.Add(this.label2);
            this.groupBox_BGM.Controls.Add(this.label1);
            this.groupBox_BGM.Controls.Add(this.tb_Name);
            this.groupBox_BGM.Controls.Add(this.label4);
            this.groupBox_BGM.Controls.Add(this.label57);
            this.groupBox_BGM.Controls.Add(this.label17);
            this.groupBox_BGM.Controls.Add(this.label18);
            this.groupBox_BGM.Controls.Add(this.label20);
            this.groupBox_BGM.Controls.Add(this.label21);
            this.groupBox_BGM.Controls.Add(this.tb_Priority);
            this.groupBox_BGM.Controls.Add(this.tb_StartChime);
            this.groupBox_BGM.Controls.Add(this.tb_Messages);
            this.groupBox_BGM.Controls.Add(this.tb_EndChime);
            this.groupBox_BGM.Controls.Add(this.tb_RepeatCnt);
            this.groupBox_BGM.ForeColor = System.Drawing.Color.White;
            this.groupBox_BGM.Location = new System.Drawing.Point(1081, 48);
            this.groupBox_BGM.Name = "groupBox_BGM";
            this.groupBox_BGM.Size = new System.Drawing.Size(615, 417);
            this.groupBox_BGM.TabIndex = 580;
            this.groupBox_BGM.TabStop = false;
            this.groupBox_BGM.Text = "Call 설정";
            // 
            // btn_call5
            // 
            this.btn_call5.ForeColor = System.Drawing.Color.Black;
            this.btn_call5.Location = new System.Drawing.Point(370, 202);
            this.btn_call5.Name = "btn_call5";
            this.btn_call5.Size = new System.Drawing.Size(202, 25);
            this.btn_call5.TabIndex = 581;
            this.btn_call5.Text = "button2";
            this.btn_call5.UseVisualStyleBackColor = true;
            // 
            // btn_call4
            // 
            this.btn_call4.ForeColor = System.Drawing.Color.Black;
            this.btn_call4.Location = new System.Drawing.Point(370, 165);
            this.btn_call4.Name = "btn_call4";
            this.btn_call4.Size = new System.Drawing.Size(202, 25);
            this.btn_call4.TabIndex = 580;
            this.btn_call4.Text = "button2";
            this.btn_call4.UseVisualStyleBackColor = true;
            // 
            // btn_call3
            // 
            this.btn_call3.ForeColor = System.Drawing.Color.Black;
            this.btn_call3.Location = new System.Drawing.Point(370, 128);
            this.btn_call3.Name = "btn_call3";
            this.btn_call3.Size = new System.Drawing.Size(202, 25);
            this.btn_call3.TabIndex = 579;
            this.btn_call3.Text = "button2";
            this.btn_call3.UseVisualStyleBackColor = true;
            // 
            // btn_call2
            // 
            this.btn_call2.ForeColor = System.Drawing.Color.Black;
            this.btn_call2.Location = new System.Drawing.Point(370, 94);
            this.btn_call2.Name = "btn_call2";
            this.btn_call2.Size = new System.Drawing.Size(202, 25);
            this.btn_call2.TabIndex = 578;
            this.btn_call2.Text = "button2";
            this.btn_call2.UseVisualStyleBackColor = true;
            // 
            // btn_call1
            // 
            this.btn_call1.ForeColor = System.Drawing.Color.Black;
            this.btn_call1.Location = new System.Drawing.Point(370, 55);
            this.btn_call1.Name = "btn_call1";
            this.btn_call1.Size = new System.Drawing.Size(202, 25);
            this.btn_call1.TabIndex = 577;
            this.btn_call1.Text = "button2";
            this.btn_call1.UseVisualStyleBackColor = true;
            // 
            // btn_callCancel
            // 
            this.btn_callCancel.BackColor = System.Drawing.Color.LightBlue;
            this.btn_callCancel.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_callCancel.ForeColor = System.Drawing.Color.Black;
            this.btn_callCancel.Location = new System.Drawing.Point(475, 274);
            this.btn_callCancel.Name = "btn_callCancel";
            this.btn_callCancel.Size = new System.Drawing.Size(99, 42);
            this.btn_callCancel.TabIndex = 576;
            this.btn_callCancel.Text = "취소";
            this.btn_callCancel.UseVisualStyleBackColor = false;
            this.btn_callCancel.Click += new System.EventHandler(this.btn_callCancel_Click);
            // 
            // btn_callSave
            // 
            this.btn_callSave.BackColor = System.Drawing.Color.LightBlue;
            this.btn_callSave.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_callSave.ForeColor = System.Drawing.Color.Black;
            this.btn_callSave.Location = new System.Drawing.Point(370, 274);
            this.btn_callSave.Name = "btn_callSave";
            this.btn_callSave.Size = new System.Drawing.Size(99, 42);
            this.btn_callSave.TabIndex = 575;
            this.btn_callSave.Text = "저장";
            this.btn_callSave.UseVisualStyleBackColor = false;
            this.btn_callSave.Click += new System.EventHandler(this.btn_callSave_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Red;
            this.button1.Location = new System.Drawing.Point(291, 368);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(48, 38);
            this.button1.TabIndex = 573;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label27.ForeColor = System.Drawing.Color.Red;
            this.label27.Location = new System.Drawing.Point(26, 368);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(259, 32);
            this.label27.TabIndex = 574;
            this.label27.Text = "화재 방송은 240~250번으로 설정됨\r\n색상은 적색으로 고정";
            // 
            // tb_color
            // 
            this.tb_color.ForeColor = System.Drawing.Color.Black;
            this.tb_color.Location = new System.Drawing.Point(110, 326);
            this.tb_color.Name = "tb_color";
            this.tb_color.Size = new System.Drawing.Size(68, 24);
            this.tb_color.TabIndex = 475;
            this.tb_color.UseVisualStyleBackColor = true;
            this.tb_color.Click += new System.EventHandler(this.tb_color_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 332);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 13);
            this.label2.TabIndex = 474;
            this.label2.Text = "Color :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 472;
            this.label1.Text = "이름:";
            // 
            // tb_Name
            // 
            this.tb_Name.Location = new System.Drawing.Point(110, 58);
            this.tb_Name.Name = "tb_Name";
            this.tb_Name.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tb_Name.Size = new System.Drawing.Size(217, 22);
            this.tb_Name.TabIndex = 473;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 97);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 13);
            this.label4.TabIndex = 19;
            this.label4.Text = "Priority:";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(367, 29);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(119, 13);
            this.label57.TabIndex = 467;
            this.label57.Text = "선택후 설정 하세요";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(23, 134);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(82, 13);
            this.label17.TabIndex = 21;
            this.label17.Text = "Start Chime:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(22, 171);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(78, 13);
            this.label18.TabIndex = 22;
            this.label18.Text = "Messages:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(22, 246);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(78, 13);
            this.label20.TabIndex = 24;
            this.label20.Text = "End Chime:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(22, 290);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(79, 13);
            this.label21.TabIndex = 25;
            this.label21.Text = "Repeat Cnt:";
            // 
            // tb_Priority
            // 
            this.tb_Priority.Location = new System.Drawing.Point(110, 94);
            this.tb_Priority.Name = "tb_Priority";
            this.tb_Priority.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tb_Priority.Size = new System.Drawing.Size(217, 22);
            this.tb_Priority.TabIndex = 26;
            // 
            // tb_StartChime
            // 
            this.tb_StartChime.Location = new System.Drawing.Point(110, 131);
            this.tb_StartChime.Name = "tb_StartChime";
            this.tb_StartChime.Size = new System.Drawing.Size(217, 22);
            this.tb_StartChime.TabIndex = 28;
            // 
            // tb_Messages
            // 
            this.tb_Messages.Location = new System.Drawing.Point(110, 168);
            this.tb_Messages.Name = "tb_Messages";
            this.tb_Messages.Size = new System.Drawing.Size(217, 22);
            this.tb_Messages.TabIndex = 29;
            // 
            // tb_EndChime
            // 
            this.tb_EndChime.Location = new System.Drawing.Point(110, 243);
            this.tb_EndChime.Name = "tb_EndChime";
            this.tb_EndChime.Size = new System.Drawing.Size(217, 22);
            this.tb_EndChime.TabIndex = 31;
            // 
            // tb_RepeatCnt
            // 
            this.tb_RepeatCnt.Location = new System.Drawing.Point(110, 285);
            this.tb_RepeatCnt.Name = "tb_RepeatCnt";
            this.tb_RepeatCnt.Size = new System.Drawing.Size(217, 22);
            this.tb_RepeatCnt.TabIndex = 32;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.tabPage3.Controls.Add(this.groupBox9);
            this.tabPage3.Controls.Add(this.groupBox8);
            this.tabPage3.Controls.Add(this.groupBox7);
            this.tabPage3.ForeColor = System.Drawing.Color.White;
            this.tabPage3.Location = new System.Drawing.Point(4, 44);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1912, 899);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "네트웍 장비 / 음원 등록";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.label7);
            this.groupBox8.Controls.Add(this.txt_PingTime);
            this.groupBox8.Controls.Add(this.btn_addNet);
            this.groupBox8.Controls.Add(this.txt_DevName);
            this.groupBox8.Controls.Add(this.label5);
            this.groupBox8.Controls.Add(this.txt_devIP);
            this.groupBox8.Controls.Add(this.label3);
            this.groupBox8.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox8.ForeColor = System.Drawing.Color.White;
            this.groupBox8.Location = new System.Drawing.Point(382, 114);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(468, 254);
            this.groupBox8.TabIndex = 1;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "네트웍 장비 목록";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(23, 149);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 30);
            this.label7.TabIndex = 557;
            this.label7.Text = "전체 장비\r\nPing 주기(초)";
            // 
            // txt_PingTime
            // 
            this.txt_PingTime.Location = new System.Drawing.Point(133, 154);
            this.txt_PingTime.Name = "txt_PingTime";
            this.txt_PingTime.Size = new System.Drawing.Size(174, 25);
            this.txt_PingTime.TabIndex = 556;
            this.txt_PingTime.Text = "3";
            this.txt_PingTime.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_PingTime_KeyPress);
            // 
            // btn_addNet
            // 
            this.btn_addNet.BackColor = System.Drawing.Color.LightBlue;
            this.btn_addNet.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_addNet.ForeColor = System.Drawing.Color.Black;
            this.btn_addNet.Location = new System.Drawing.Point(329, 143);
            this.btn_addNet.Name = "btn_addNet";
            this.btn_addNet.Size = new System.Drawing.Size(99, 42);
            this.btn_addNet.TabIndex = 555;
            this.btn_addNet.Text = "장비 추가";
            this.btn_addNet.UseVisualStyleBackColor = false;
            this.btn_addNet.Click += new System.EventHandler(this.btn_addNet_Click);
            // 
            // txt_DevName
            // 
            this.txt_DevName.Location = new System.Drawing.Point(133, 98);
            this.txt_DevName.Name = "txt_DevName";
            this.txt_DevName.Size = new System.Drawing.Size(293, 25);
            this.txt_DevName.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(23, 101);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 15);
            this.label5.TabIndex = 2;
            this.label5.Text = "장비 이름";
            // 
            // txt_devIP
            // 
            this.txt_devIP.Location = new System.Drawing.Point(133, 47);
            this.txt_devIP.Name = "txt_devIP";
            this.txt_devIP.Size = new System.Drawing.Size(293, 25);
            this.txt_devIP.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 15);
            this.label3.TabIndex = 0;
            this.label3.Text = "IP Address";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.panel_net);
            this.groupBox7.Controls.Add(this.label6);
            this.groupBox7.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox7.ForeColor = System.Drawing.Color.White;
            this.groupBox7.Location = new System.Drawing.Point(66, 114);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(274, 594);
            this.groupBox7.TabIndex = 0;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "네트웍 장비 목록";
            // 
            // panel_net
            // 
            this.panel_net.AutoScroll = true;
            this.panel_net.Location = new System.Drawing.Point(17, 71);
            this.panel_net.Name = "panel_net";
            this.panel_net.Size = new System.Drawing.Size(242, 508);
            this.panel_net.TabIndex = 557;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(36, 28);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(222, 30);
            this.label6.TabIndex = 556;
            this.label6.Text = "삭제 하려면 마우스를 클릭하고 \r\n메뉴에서 삭제 합니다. ";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.button8);
            this.groupBox9.Controls.Add(this.btn_music4);
            this.groupBox9.Controls.Add(this.button6);
            this.groupBox9.Controls.Add(this.btn_music3);
            this.groupBox9.Controls.Add(this.button4);
            this.groupBox9.Controls.Add(this.btn_music2);
            this.groupBox9.Controls.Add(this.button3);
            this.groupBox9.Controls.Add(this.btn_music1);
            this.groupBox9.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox9.ForeColor = System.Drawing.Color.White;
            this.groupBox9.Location = new System.Drawing.Point(911, 114);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(433, 389);
            this.groupBox9.TabIndex = 2;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "음원등록";
            // 
            // btn_music1
            // 
            this.btn_music1.ForeColor = System.Drawing.Color.Black;
            this.btn_music1.Location = new System.Drawing.Point(98, 47);
            this.btn_music1.Name = "btn_music1";
            this.btn_music1.Size = new System.Drawing.Size(299, 58);
            this.btn_music1.TabIndex = 3;
            this.btn_music1.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button3.ForeColor = System.Drawing.Color.Black;
            this.button3.Location = new System.Drawing.Point(39, 47);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(60, 58);
            this.button3.TabIndex = 4;
            this.button3.Text = "1";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button4.ForeColor = System.Drawing.Color.Black;
            this.button4.Location = new System.Drawing.Point(39, 127);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(60, 58);
            this.button4.TabIndex = 6;
            this.button4.Text = "2";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // btn_music2
            // 
            this.btn_music2.ForeColor = System.Drawing.Color.Black;
            this.btn_music2.Location = new System.Drawing.Point(98, 127);
            this.btn_music2.Name = "btn_music2";
            this.btn_music2.Size = new System.Drawing.Size(299, 58);
            this.btn_music2.TabIndex = 5;
            this.btn_music2.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button6.ForeColor = System.Drawing.Color.Black;
            this.button6.Location = new System.Drawing.Point(39, 210);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(60, 58);
            this.button6.TabIndex = 8;
            this.button6.Text = "3";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // btn_music3
            // 
            this.btn_music3.ForeColor = System.Drawing.Color.Black;
            this.btn_music3.Location = new System.Drawing.Point(98, 210);
            this.btn_music3.Name = "btn_music3";
            this.btn_music3.Size = new System.Drawing.Size(299, 58);
            this.btn_music3.TabIndex = 7;
            this.btn_music3.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button8.ForeColor = System.Drawing.Color.Black;
            this.button8.Location = new System.Drawing.Point(39, 294);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(60, 58);
            this.button8.TabIndex = 10;
            this.button8.Text = "4";
            this.button8.UseVisualStyleBackColor = false;
            // 
            // btn_music4
            // 
            this.btn_music4.ForeColor = System.Drawing.Color.Black;
            this.btn_music4.Location = new System.Drawing.Point(98, 294);
            this.btn_music4.Name = "btn_music4";
            this.btn_music4.Size = new System.Drawing.Size(299, 58);
            this.btn_music4.TabIndex = 9;
            this.btn_music4.UseVisualStyleBackColor = true;
            // 
            // frmSetting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.ClientSize = new System.Drawing.Size(1920, 947);
            this.Controls.Add(this.setting_tab);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmSetting";
            this.Text = "frmSetting";
            this.Load += new System.EventHandler(this.frmSetting_Load);
            this.setting_tab.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.pg2_menu4.ResumeLayout(false);
            this.pg2_menu4.PerformLayout();
            this.pg2_menu3.ResumeLayout(false);
            this.pg2_menu3.PerformLayout();
            this.pg2_menu2.ResumeLayout(false);
            this.pg2_menu2.PerformLayout();
            this.pg2_menu1.ResumeLayout(false);
            this.pg2_menu1.PerformLayout();
            this.pg2_menu5.ResumeLayout(false);
            this.pg2_menu5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.zone_setting_img)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.gr_BGMname.ResumeLayout(false);
            this.gr_BGMname.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox_BGM.ResumeLayout(false);
            this.groupBox_BGM.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl setting_tab;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button btnSaveCancle;
        private System.Windows.Forms.GroupBox pg2_menu4;
        private System.Windows.Forms.TextBox txt_NCO_Password;
        private System.Windows.Forms.GroupBox pg2_menu3;
        private System.Windows.Forms.TextBox txt_NCO_ID;
        private System.Windows.Forms.GroupBox pg2_menu2;
        private System.Windows.Forms.TextBox txt_NCO_IP;
        private System.Windows.Forms.GroupBox pg2_menu1;
        private System.Windows.Forms.TextBox txt_NCO_Name;
        private System.Windows.Forms.GroupBox pg2_menu5;
        private System.Windows.Forms.TextBox txt_GroupName;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.PictureBox zone_setting_img;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox_BGM;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Button bgm_save_cancle;
        private System.Windows.Forms.Button BGM_save;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox tb_Priority;
        private System.Windows.Forms.TextBox tb_StartChime;
        private System.Windows.Forms.TextBox tb_Messages;
        private System.Windows.Forms.TextBox tb_EndChime;
        private System.Windows.Forms.TextBox tb_RepeatCnt;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btn_nco3;
        private System.Windows.Forms.Button btn_nco2;
        private System.Windows.Forms.Button btn_nco1;
        private System.Windows.Forms.Panel panel_zoneFrm;
        private System.Windows.Forms.Button btn_erase;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button btn_zone3;
        private System.Windows.Forms.Button btn_zone2;
        private System.Windows.Forms.Button btn_zone1;
        private System.Windows.Forms.Button btn_zone4;
        private System.Windows.Forms.Button btn_setNco;
        private System.Windows.Forms.Button btnSaveZone;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txt_BgmNCO5;
        private System.Windows.Forms.Button btn_bgmColor5;
        private System.Windows.Forms.Button btn_Bgm5;
        private System.Windows.Forms.TextBox txt_BgmNCO4;
        private System.Windows.Forms.Button btn_bgmColor4;
        private System.Windows.Forms.Button btn_Bgm4;
        private System.Windows.Forms.TextBox txt_BgmNCO3;
        private System.Windows.Forms.Button btn_bgmColor3;
        private System.Windows.Forms.Button btn_Bgm3;
        private System.Windows.Forms.TextBox txt_BgmNCO2;
        private System.Windows.Forms.TextBox txt_BgmNCO1;
        private System.Windows.Forms.Button btn_bgmColor2;
        private System.Windows.Forms.Button btn_Bgm2;
        private System.Windows.Forms.Button btn_bgmColor1;
        private System.Windows.Forms.Button btn_Bgm1;
        private System.Windows.Forms.Button tb_color;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ColorDialog clrdlg_chk;
        private System.Windows.Forms.GroupBox gr_BGMname;
        private System.Windows.Forms.Button btn_change;
        private System.Windows.Forms.TextBox txt_BGMname;
        private System.Windows.Forms.Button btn_call5;
        private System.Windows.Forms.Button btn_call4;
        private System.Windows.Forms.Button btn_call3;
        private System.Windows.Forms.Button btn_call2;
        private System.Windows.Forms.Button btn_call1;
        private System.Windows.Forms.Button btn_callCancel;
        private System.Windows.Forms.Button btn_callSave;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_Name;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button sbtn_nco3;
        private System.Windows.Forms.Button sbtn_nco2;
        private System.Windows.Forms.Button sbtn_nco1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Button btn_addNet;
        private System.Windows.Forms.TextBox txt_DevName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_devIP;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_Messages;
        private System.Windows.Forms.TextBox txt_bgms;
        private System.Windows.Forms.Panel panel_net;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_PingTime;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btn_music1;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button btn_music4;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button btn_music3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button btn_music2;
    }
}