﻿namespace NCO_App
{
    partial class frmTTS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTTS));
            this.comboBoxSpeed = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonPTTS_PLAY = new RHBform.RHBbutton();
            this.btn_TxTsave = new RHBform.RHBbutton();
            this.btn_Open = new RHBform.RHBbutton();
            this.btn_SaveAndMakeFile = new RHBform.RHBbutton();
            this.textBoxPTTS_TEXT = new System.Windows.Forms.RichTextBox();
            this.SaveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.btn_stop = new RHBform.RHBbutton();
            this.SuspendLayout();
            // 
            // comboBoxSpeed
            // 
            this.comboBoxSpeed.ForeColor = System.Drawing.Color.Black;
            this.comboBoxSpeed.FormattingEnabled = true;
            this.comboBoxSpeed.Items.AddRange(new object[] {
            "느리게",
            "보통",
            "빠르게",
            "2배 빠르게"});
            this.comboBoxSpeed.Location = new System.Drawing.Point(21, 546);
            this.comboBoxSpeed.Name = "comboBoxSpeed";
            this.comboBoxSpeed.Size = new System.Drawing.Size(146, 20);
            this.comboBoxSpeed.TabIndex = 37;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(26, 523);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 13);
            this.label1.TabIndex = 532;
            this.label1.Text = "재생 속도";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // buttonPTTS_PLAY
            // 
            this.buttonPTTS_PLAY.BackColor = System.Drawing.Color.Transparent;
            this.buttonPTTS_PLAY.ForeColor = System.Drawing.Color.Yellow;
            this.buttonPTTS_PLAY.Location = new System.Drawing.Point(19, 470);
            this.buttonPTTS_PLAY.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttonPTTS_PLAY.Name = "buttonPTTS_PLAY";
            this.buttonPTTS_PLAY.setFontColor = System.Drawing.Color.Yellow;
            this.buttonPTTS_PLAY.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("buttonPTTS_PLAY.setOFFimage")));
            this.buttonPTTS_PLAY.setON = false;
            this.buttonPTTS_PLAY.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("buttonPTTS_PLAY.setONimage")));
            this.buttonPTTS_PLAY.setText = "재생";
            this.buttonPTTS_PLAY.setToggle = false;
            this.buttonPTTS_PLAY.Size = new System.Drawing.Size(152, 42);
            this.buttonPTTS_PLAY.TabIndex = 531;
            this.buttonPTTS_PLAY.TabStop = false;
            this.buttonPTTS_PLAY.Tag = "2";
            this.buttonPTTS_PLAY.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.buttonPTTS_PLAY.Click += new System.EventHandler(this.buttonPTTS_PLAY_Click);
            // 
            // btn_TxTsave
            // 
            this.btn_TxTsave.BackColor = System.Drawing.Color.Transparent;
            this.btn_TxTsave.ForeColor = System.Drawing.Color.Yellow;
            this.btn_TxTsave.Location = new System.Drawing.Point(177, 422);
            this.btn_TxTsave.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_TxTsave.Name = "btn_TxTsave";
            this.btn_TxTsave.setFontColor = System.Drawing.Color.Yellow;
            this.btn_TxTsave.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_TxTsave.setOFFimage")));
            this.btn_TxTsave.setON = false;
            this.btn_TxTsave.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_TxTsave.setONimage")));
            this.btn_TxTsave.setText = "텍스트 저장";
            this.btn_TxTsave.setToggle = false;
            this.btn_TxTsave.Size = new System.Drawing.Size(152, 42);
            this.btn_TxTsave.TabIndex = 530;
            this.btn_TxTsave.TabStop = false;
            this.btn_TxTsave.Tag = "2";
            this.btn_TxTsave.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_TxTsave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btn_Open
            // 
            this.btn_Open.BackColor = System.Drawing.Color.Transparent;
            this.btn_Open.ForeColor = System.Drawing.Color.Yellow;
            this.btn_Open.Location = new System.Drawing.Point(19, 422);
            this.btn_Open.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Open.Name = "btn_Open";
            this.btn_Open.setFontColor = System.Drawing.Color.Yellow;
            this.btn_Open.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_Open.setOFFimage")));
            this.btn_Open.setON = false;
            this.btn_Open.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_Open.setONimage")));
            this.btn_Open.setText = "불러오기";
            this.btn_Open.setToggle = false;
            this.btn_Open.Size = new System.Drawing.Size(152, 42);
            this.btn_Open.TabIndex = 529;
            this.btn_Open.TabStop = false;
            this.btn_Open.Tag = "2";
            this.btn_Open.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Open.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // btn_SaveAndMakeFile
            // 
            this.btn_SaveAndMakeFile.BackColor = System.Drawing.Color.Transparent;
            this.btn_SaveAndMakeFile.ForeColor = System.Drawing.Color.Yellow;
            this.btn_SaveAndMakeFile.Location = new System.Drawing.Point(177, 525);
            this.btn_SaveAndMakeFile.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_SaveAndMakeFile.Name = "btn_SaveAndMakeFile";
            this.btn_SaveAndMakeFile.setFontColor = System.Drawing.Color.Yellow;
            this.btn_SaveAndMakeFile.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_SaveAndMakeFile.setOFFimage")));
            this.btn_SaveAndMakeFile.setON = false;
            this.btn_SaveAndMakeFile.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_SaveAndMakeFile.setONimage")));
            this.btn_SaveAndMakeFile.setText = "음성파일 생성";
            this.btn_SaveAndMakeFile.setToggle = false;
            this.btn_SaveAndMakeFile.Size = new System.Drawing.Size(152, 48);
            this.btn_SaveAndMakeFile.TabIndex = 528;
            this.btn_SaveAndMakeFile.TabStop = false;
            this.btn_SaveAndMakeFile.Tag = "2";
            this.btn_SaveAndMakeFile.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_SaveAndMakeFile.Click += new System.EventHandler(this.btn_SaveAndMakeFile_Click);
            // 
            // textBoxPTTS_TEXT
            // 
            this.textBoxPTTS_TEXT.BackColor = System.Drawing.Color.Black;
            this.textBoxPTTS_TEXT.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBoxPTTS_TEXT.ForeColor = System.Drawing.Color.White;
            this.textBoxPTTS_TEXT.Location = new System.Drawing.Point(12, 9);
            this.textBoxPTTS_TEXT.Name = "textBoxPTTS_TEXT";
            this.textBoxPTTS_TEXT.Size = new System.Drawing.Size(317, 406);
            this.textBoxPTTS_TEXT.TabIndex = 527;
            this.textBoxPTTS_TEXT.Text = "";
            // 
            // btn_stop
            // 
            this.btn_stop.BackColor = System.Drawing.Color.Transparent;
            this.btn_stop.ForeColor = System.Drawing.Color.Yellow;
            this.btn_stop.Location = new System.Drawing.Point(177, 470);
            this.btn_stop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_stop.Name = "btn_stop";
            this.btn_stop.setFontColor = System.Drawing.Color.Yellow;
            this.btn_stop.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_stop.setOFFimage")));
            this.btn_stop.setON = false;
            this.btn_stop.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_stop.setONimage")));
            this.btn_stop.setText = "정지";
            this.btn_stop.setToggle = false;
            this.btn_stop.Size = new System.Drawing.Size(152, 42);
            this.btn_stop.TabIndex = 533;
            this.btn_stop.TabStop = false;
            this.btn_stop.Tag = "2";
            this.btn_stop.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_stop.Click += new System.EventHandler(this.buttonPTTS_STOP_Click);
            // 
            // frmTTS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.ClientSize = new System.Drawing.Size(341, 577);
            this.Controls.Add(this.btn_stop);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonPTTS_PLAY);
            this.Controls.Add(this.btn_TxTsave);
            this.Controls.Add(this.btn_Open);
            this.Controls.Add(this.btn_SaveAndMakeFile);
            this.Controls.Add(this.textBoxPTTS_TEXT);
            this.Controls.Add(this.comboBoxSpeed);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmTTS";
            this.Text = "frmTTS";
            this.Load += new System.EventHandler(this.frmTTS_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox comboBoxSpeed;
        private System.Windows.Forms.Label label1;
        private RHBform.RHBbutton buttonPTTS_PLAY;
        private RHBform.RHBbutton btn_TxTsave;
        private RHBform.RHBbutton btn_Open;
        private RHBform.RHBbutton btn_SaveAndMakeFile;
        private System.Windows.Forms.RichTextBox textBoxPTTS_TEXT;
        private System.Windows.Forms.SaveFileDialog SaveFileDialog1;
        private RHBform.RHBbutton btn_stop;
    }
}