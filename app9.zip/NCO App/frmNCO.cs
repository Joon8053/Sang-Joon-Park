﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NCO_App
{
    public partial class frmNCO : Form
    {

        frmMain app;
        public frmNCO(frmMain main)
        {
            InitializeComponent();
            app = main;
        }
        private void CallUrl(string url)
        {
            string edgePath = @"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"; // 엣지 브라우저의 실행 경로

            try
            {
                // 엣지 브라우저 실행
                Process.Start(edgePath, url);
            }
            catch (Exception ex)
            {
                // 예외 처리
                Console.WriteLine("Error: " + ex.Message);
            }
        }

        private void btn_nco1_Click(object sender, EventArgs e)
        {
            int no = Convert.ToInt16(((Control)sender).Tag) - 1;
            CallUrl(app.NcoSite.NCO[no].ip);
        }

        private void initNcoText(Button[] btn)
        {
            for (int i = 0; i < btn.Length; i++)
            {
                btn[i].Text = app.NcoSite.NCO[i].Name;
            }
        }

        private void frmNCO_Load(object sender, EventArgs e)
        {
            btn_NCOs = new Button[] { btn_nco1, btn_nco2, btn_nco3 };
            initNcoText(btn_NCOs);
        }
        Button[] btn_NCOs;
    }
}
