﻿namespace NCO_App
{
    partial class frmSchedule
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSchedule));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dg_week = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn2 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn3 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn4 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn5 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn6 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn7 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewComboBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewButtonColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.btn_Allon = new RHBform.RHBbutton();
            this.btn_DaySC = new RHBform.RHBbutton();
            this.btn_nextMonth = new System.Windows.Forms.Button();
            this.btn_preMonth = new System.Windows.Forms.Button();
            this.btn_home = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.richTextBox_log = new System.Windows.Forms.RichTextBox();
            this.rhBbutton1 = new RHBform.RHBbutton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label_date = new System.Windows.Forms.Label();
            this.dg_day = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_weekDel = new System.Windows.Forms.Button();
            this.btn_weekCancel = new System.Windows.Forms.Button();
            this.gr_weekEdit = new System.Windows.Forms.GroupBox();
            this.btn_weekEdit = new System.Windows.Forms.Button();
            this.customCalendar1 = new exCalendar.CustomCalendar();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_week)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_day)).BeginInit();
            this.gr_weekEdit.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.panel1.Controls.Add(this.dg_week);
            this.panel1.Controls.Add(this.btn_Allon);
            this.panel1.Controls.Add(this.btn_DaySC);
            this.panel1.Location = new System.Drawing.Point(22, 673);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1037, 262);
            this.panel1.TabIndex = 24;
            // 
            // dg_week
            // 
            this.dg_week.BackgroundColor = System.Drawing.Color.Gainsboro;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dg_week.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dg_week.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_week.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewCheckBoxColumn1,
            this.dataGridViewCheckBoxColumn2,
            this.dataGridViewCheckBoxColumn3,
            this.dataGridViewCheckBoxColumn4,
            this.dataGridViewCheckBoxColumn5,
            this.dataGridViewCheckBoxColumn6,
            this.dataGridViewCheckBoxColumn7,
            this.Column16,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewComboBoxColumn1,
            this.dataGridViewButtonColumn3,
            this.Column2});
            this.dg_week.GridColor = System.Drawing.SystemColors.ActiveCaption;
            this.dg_week.Location = new System.Drawing.Point(3, 37);
            this.dg_week.Name = "dg_week";
            this.dg_week.RowTemplate.Height = 23;
            this.dg_week.Size = new System.Drawing.Size(1030, 219);
            this.dg_week.TabIndex = 22;
            this.dg_week.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dg_week_CellContentClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewTextBoxColumn1.HeaderText = "이름";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 200;
            // 
            // dataGridViewCheckBoxColumn1
            // 
            this.dataGridViewCheckBoxColumn1.HeaderText = "일";
            this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
            this.dataGridViewCheckBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCheckBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewCheckBoxColumn1.Width = 30;
            // 
            // dataGridViewCheckBoxColumn2
            // 
            this.dataGridViewCheckBoxColumn2.HeaderText = "월";
            this.dataGridViewCheckBoxColumn2.Name = "dataGridViewCheckBoxColumn2";
            this.dataGridViewCheckBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCheckBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewCheckBoxColumn2.Width = 30;
            // 
            // dataGridViewCheckBoxColumn3
            // 
            this.dataGridViewCheckBoxColumn3.HeaderText = "화";
            this.dataGridViewCheckBoxColumn3.Name = "dataGridViewCheckBoxColumn3";
            this.dataGridViewCheckBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCheckBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewCheckBoxColumn3.Width = 30;
            // 
            // dataGridViewCheckBoxColumn4
            // 
            this.dataGridViewCheckBoxColumn4.HeaderText = "수";
            this.dataGridViewCheckBoxColumn4.Name = "dataGridViewCheckBoxColumn4";
            this.dataGridViewCheckBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCheckBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewCheckBoxColumn4.Width = 30;
            // 
            // dataGridViewCheckBoxColumn5
            // 
            this.dataGridViewCheckBoxColumn5.HeaderText = "목";
            this.dataGridViewCheckBoxColumn5.Name = "dataGridViewCheckBoxColumn5";
            this.dataGridViewCheckBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCheckBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewCheckBoxColumn5.Width = 30;
            // 
            // dataGridViewCheckBoxColumn6
            // 
            this.dataGridViewCheckBoxColumn6.HeaderText = "금";
            this.dataGridViewCheckBoxColumn6.Name = "dataGridViewCheckBoxColumn6";
            this.dataGridViewCheckBoxColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCheckBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewCheckBoxColumn6.Width = 30;
            // 
            // dataGridViewCheckBoxColumn7
            // 
            this.dataGridViewCheckBoxColumn7.HeaderText = "토";
            this.dataGridViewCheckBoxColumn7.Name = "dataGridViewCheckBoxColumn7";
            this.dataGridViewCheckBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCheckBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewCheckBoxColumn7.Width = 30;
            // 
            // Column16
            // 
            this.Column16.HeaderText = "자동";
            this.Column16.Name = "Column16";
            this.Column16.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column16.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Column16.Width = 40;
            // 
            // dataGridViewTextBoxColumn2
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewTextBoxColumn2.HeaderText = "시작";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 80;
            // 
            // dataGridViewTextBoxColumn3
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewTextBoxColumn3.HeaderText = "종료";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 80;
            // 
            // dataGridViewComboBoxColumn1
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewComboBoxColumn1.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridViewComboBoxColumn1.HeaderText = "BGM입력";
            this.dataGridViewComboBoxColumn1.Name = "dataGridViewComboBoxColumn1";
            this.dataGridViewComboBoxColumn1.ReadOnly = true;
            this.dataGridViewComboBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewButtonColumn3
            // 
            this.dataGridViewButtonColumn3.HeaderText = "재생 파일";
            this.dataGridViewButtonColumn3.Name = "dataGridViewButtonColumn3";
            this.dataGridViewButtonColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewButtonColumn3.Width = 150;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "삭제";
            this.Column2.Name = "Column2";
            this.Column2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Column2.Width = 90;
            // 
            // btn_Allon
            // 
            this.btn_Allon.BackColor = System.Drawing.Color.Transparent;
            this.btn_Allon.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_Allon.ForeColor = System.Drawing.Color.Yellow;
            this.btn_Allon.Location = new System.Drawing.Point(3, -19);
            this.btn_Allon.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Allon.Name = "btn_Allon";
            this.btn_Allon.setFontColor = System.Drawing.Color.Yellow;
            this.btn_Allon.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_Allon.setOFFimage")));
            this.btn_Allon.setON = false;
            this.btn_Allon.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_Allon.setONimage")));
            this.btn_Allon.setText = "주중 스케쥴";
            this.btn_Allon.setToggle = false;
            this.btn_Allon.Size = new System.Drawing.Size(137, 75);
            this.btn_Allon.TabIndex = 125;
            this.btn_Allon.TabStop = false;
            this.btn_Allon.Tag = "2";
            this.btn_Allon.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btn_DaySC
            // 
            this.btn_DaySC.BackColor = System.Drawing.Color.Transparent;
            this.btn_DaySC.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_DaySC.ForeColor = System.Drawing.Color.Yellow;
            this.btn_DaySC.Location = new System.Drawing.Point(894, -18);
            this.btn_DaySC.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_DaySC.Name = "btn_DaySC";
            this.btn_DaySC.setFontColor = System.Drawing.Color.Yellow;
            this.btn_DaySC.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_DaySC.setOFFimage")));
            this.btn_DaySC.setON = false;
            this.btn_DaySC.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("btn_DaySC.setONimage")));
            this.btn_DaySC.setText = "추가";
            this.btn_DaySC.setToggle = false;
            this.btn_DaySC.Size = new System.Drawing.Size(137, 75);
            this.btn_DaySC.TabIndex = 126;
            this.btn_DaySC.TabStop = false;
            this.btn_DaySC.Tag = "2";
            this.btn_DaySC.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_DaySC.Click += new System.EventHandler(this.btn_DaySC_Click);
            // 
            // btn_nextMonth
            // 
            this.btn_nextMonth.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_nextMonth.BackColor = System.Drawing.Color.Silver;
            this.btn_nextMonth.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_nextMonth.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_nextMonth.ForeColor = System.Drawing.Color.Black;
            this.btn_nextMonth.Location = new System.Drawing.Point(1063, 23);
            this.btn_nextMonth.Name = "btn_nextMonth";
            this.btn_nextMonth.Size = new System.Drawing.Size(97, 50);
            this.btn_nextMonth.TabIndex = 25;
            this.btn_nextMonth.Text = "다음달 ->";
            this.btn_nextMonth.UseVisualStyleBackColor = false;
            this.btn_nextMonth.Click += new System.EventHandler(this.btn_nextMonth_Click);
            // 
            // btn_preMonth
            // 
            this.btn_preMonth.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_preMonth.BackColor = System.Drawing.Color.Silver;
            this.btn_preMonth.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_preMonth.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_preMonth.ForeColor = System.Drawing.Color.Black;
            this.btn_preMonth.Location = new System.Drawing.Point(741, 23);
            this.btn_preMonth.Name = "btn_preMonth";
            this.btn_preMonth.Size = new System.Drawing.Size(97, 50);
            this.btn_preMonth.TabIndex = 26;
            this.btn_preMonth.Text = "<- 이전달";
            this.btn_preMonth.UseVisualStyleBackColor = false;
            this.btn_preMonth.Click += new System.EventHandler(this.btn_preMonth_Click);
            // 
            // btn_home
            // 
            this.btn_home.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_home.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btn_home.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_home.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_home.ForeColor = System.Drawing.Color.Black;
            this.btn_home.Location = new System.Drawing.Point(625, 23);
            this.btn_home.Name = "btn_home";
            this.btn_home.Size = new System.Drawing.Size(97, 50);
            this.btn_home.TabIndex = 27;
            this.btn_home.Text = "현재 날짜";
            this.btn_home.UseVisualStyleBackColor = false;
            this.btn_home.Click += new System.EventHandler(this.btn_home_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.richTextBox_log);
            this.panel2.Controls.Add(this.rhBbutton1);
            this.panel2.Location = new System.Drawing.Point(1065, 673);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(349, 262);
            this.panel2.TabIndex = 28;
            // 
            // richTextBox_log
            // 
            this.richTextBox_log.BackColor = System.Drawing.Color.Black;
            this.richTextBox_log.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.richTextBox_log.Location = new System.Drawing.Point(5, 37);
            this.richTextBox_log.Name = "richTextBox_log";
            this.richTextBox_log.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.richTextBox_log.Size = new System.Drawing.Size(336, 219);
            this.richTextBox_log.TabIndex = 0;
            this.richTextBox_log.Text = "";
            // 
            // rhBbutton1
            // 
            this.rhBbutton1.BackColor = System.Drawing.Color.Transparent;
            this.rhBbutton1.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.rhBbutton1.ForeColor = System.Drawing.Color.Yellow;
            this.rhBbutton1.Location = new System.Drawing.Point(6, -16);
            this.rhBbutton1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rhBbutton1.Name = "rhBbutton1";
            this.rhBbutton1.setFontColor = System.Drawing.Color.Yellow;
            this.rhBbutton1.setOFFimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton1.setOFFimage")));
            this.rhBbutton1.setON = false;
            this.rhBbutton1.setONimage = ((System.Drawing.Bitmap)(resources.GetObject("rhBbutton1.setONimage")));
            this.rhBbutton1.setText = "오늘 일정";
            this.rhBbutton1.setToggle = false;
            this.rhBbutton1.Size = new System.Drawing.Size(137, 75);
            this.rhBbutton1.TabIndex = 127;
            this.rhBbutton1.TabStop = false;
            this.rhBbutton1.Tag = "2";
            this.rhBbutton1.TxtLayout = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label_date);
            this.panel3.Controls.Add(this.dg_day);
            this.panel3.Location = new System.Drawing.Point(1420, 673);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(463, 262);
            this.panel3.TabIndex = 29;
            // 
            // label_date
            // 
            this.label_date.AutoSize = true;
            this.label_date.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label_date.ForeColor = System.Drawing.Color.Yellow;
            this.label_date.Location = new System.Drawing.Point(16, 13);
            this.label_date.Name = "label_date";
            this.label_date.Size = new System.Drawing.Size(130, 15);
            this.label_date.TabIndex = 24;
            this.label_date.Text = "2023-000-00 일정";
            // 
            // dg_day
            // 
            this.dg_day.BackgroundColor = System.Drawing.Color.Gainsboro;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dg_day.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dg_day.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_day.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.Column3,
            this.Column1});
            this.dg_day.GridColor = System.Drawing.SystemColors.ActiveCaption;
            this.dg_day.Location = new System.Drawing.Point(7, 37);
            this.dg_day.Name = "dg_day";
            this.dg_day.RowTemplate.Height = 23;
            this.dg_day.Size = new System.Drawing.Size(448, 219);
            this.dg_day.TabIndex = 23;
            this.dg_day.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dg_day_CellContentClick);
            // 
            // dataGridViewTextBoxColumn4
            // 
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridViewTextBoxColumn4.HeaderText = "이름";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 200;
            // 
            // dataGridViewTextBoxColumn5
            // 
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridViewTextBoxColumn5.HeaderText = "시작";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 80;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "자동";
            this.Column3.Name = "Column3";
            this.Column3.Width = 60;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "삭제";
            this.Column1.Name = "Column1";
            this.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Column1.Width = 60;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "주중 스케쥴 편집";
            // 
            // btn_weekDel
            // 
            this.btn_weekDel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_weekDel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btn_weekDel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_weekDel.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_weekDel.ForeColor = System.Drawing.Color.Black;
            this.btn_weekDel.Location = new System.Drawing.Point(15, 66);
            this.btn_weekDel.Name = "btn_weekDel";
            this.btn_weekDel.Size = new System.Drawing.Size(119, 70);
            this.btn_weekDel.TabIndex = 28;
            this.btn_weekDel.Text = "삭제";
            this.btn_weekDel.UseVisualStyleBackColor = false;
            this.btn_weekDel.Click += new System.EventHandler(this.btn_weekDel_Click);
            // 
            // btn_weekCancel
            // 
            this.btn_weekCancel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_weekCancel.BackColor = System.Drawing.Color.White;
            this.btn_weekCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_weekCancel.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_weekCancel.ForeColor = System.Drawing.Color.Black;
            this.btn_weekCancel.Location = new System.Drawing.Point(285, 66);
            this.btn_weekCancel.Name = "btn_weekCancel";
            this.btn_weekCancel.Size = new System.Drawing.Size(119, 70);
            this.btn_weekCancel.TabIndex = 30;
            this.btn_weekCancel.Text = "취소";
            this.btn_weekCancel.UseVisualStyleBackColor = false;
            this.btn_weekCancel.Click += new System.EventHandler(this.btn_weekCancel_Click);
            // 
            // gr_weekEdit
            // 
            this.gr_weekEdit.Controls.Add(this.btn_weekCancel);
            this.gr_weekEdit.Controls.Add(this.btn_weekEdit);
            this.gr_weekEdit.Controls.Add(this.btn_weekDel);
            this.gr_weekEdit.Controls.Add(this.label1);
            this.gr_weekEdit.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.gr_weekEdit.ForeColor = System.Drawing.Color.White;
            this.gr_weekEdit.Location = new System.Drawing.Point(489, 483);
            this.gr_weekEdit.Name = "gr_weekEdit";
            this.gr_weekEdit.Size = new System.Drawing.Size(421, 184);
            this.gr_weekEdit.TabIndex = 30;
            this.gr_weekEdit.TabStop = false;
            this.gr_weekEdit.Visible = false;
            // 
            // btn_weekEdit
            // 
            this.btn_weekEdit.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_weekEdit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btn_weekEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_weekEdit.Font = new System.Drawing.Font("굴림", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_weekEdit.ForeColor = System.Drawing.Color.Black;
            this.btn_weekEdit.Location = new System.Drawing.Point(150, 66);
            this.btn_weekEdit.Name = "btn_weekEdit";
            this.btn_weekEdit.Size = new System.Drawing.Size(119, 70);
            this.btn_weekEdit.TabIndex = 29;
            this.btn_weekEdit.Text = "수정";
            this.btn_weekEdit.UseVisualStyleBackColor = false;
            this.btn_weekEdit.Click += new System.EventHandler(this.btn_weekEdit_Click);
            // 
            // customCalendar1
            // 
            this.customCalendar1.dutyFontSize = 0F;
            this.customCalendar1.Location = new System.Drawing.Point(22, 20);
            this.customCalendar1.MenuStrip = null;
            this.customCalendar1.Name = "customCalendar1";
            this.customCalendar1.schedulerFontSize = 0F;
            this.customCalendar1.SelectedDate = new System.DateTime(2023, 7, 1, 0, 0, 0, 0);
            this.customCalendar1.Size = new System.Drawing.Size(1861, 629);
            this.customCalendar1.TabIndex = 23;
            this.customCalendar1.UserGrade = ((long)(0));
            this.customCalendar1.UserName = null;
            this.customCalendar1.Click += new System.EventHandler(this.customCalendar1_Click);
            this.customCalendar1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.customCalendar1_MouseDown);
            // 
            // frmSchedule
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1920, 947);
            this.Controls.Add(this.gr_weekEdit);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btn_home);
            this.Controls.Add(this.btn_preMonth);
            this.Controls.Add(this.btn_nextMonth);
            this.Controls.Add(this.customCalendar1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmSchedule";
            this.Text = "frmSchedule";
            this.Load += new System.EventHandler(this.frmSchedule_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dg_week)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_day)).EndInit();
            this.gr_weekEdit.ResumeLayout(false);
            this.gr_weekEdit.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private exCalendar.CustomCalendar customCalendar1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_nextMonth;
        private System.Windows.Forms.Button btn_preMonth;
        private System.Windows.Forms.Button btn_home;
        private RHBform.RHBbutton btn_Allon;
        private RHBform.RHBbutton btn_DaySC;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView dg_week;
        private System.Windows.Forms.DataGridView dg_day;
        private System.Windows.Forms.RichTextBox richTextBox_log;
        private RHBform.RHBbutton rhBbutton1;
        private System.Windows.Forms.Label label_date;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_weekDel;
        private System.Windows.Forms.Button btn_weekCancel;
        private System.Windows.Forms.GroupBox gr_weekEdit;
        private System.Windows.Forms.Button btn_weekEdit;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn2;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn3;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn4;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn5;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn6;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn7;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewComboBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewButtonColumn3;
        private System.Windows.Forms.DataGridViewButtonColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column3;
        private System.Windows.Forms.DataGridViewButtonColumn Column1;
    }
}